function [lb, ub, dim, fobj, meta] = MLP_info(fun_name)
% MLP_info.m
%
% Problem-family router for MLP classification problems.
%
% M1 = XOR classification
% M2 = Cancer classification
%
% Fixed standard used here:
%   M1 (XOR):
%       - Inputs: 2
%       - Hidden nodes: 3
%       - Outputs: 2 (one-hot targets)
%       - Population size: 50
%       - Max_iter: 500
%       - Decision vector length:
%           2*3 + 3 + 3*2 + 2 = 17
%
%   M2 (Cancer):
%       - Dataset: MATLAB built-in cancer_dataset
%       - Inputs: 9
%       - Hidden nodes: 10
%       - Outputs: 2 (one-hot targets)
%       - Population size: 200
%       - Max_iter: 500
%       - Decision vector length:
%           9*10 + 10 + 10*2 + 2 = 122
%
% Objective:
%   Mean Squared Error (MSE)
%
% Notes:
%   - cancer_dataset is listed by MathWorks as a built-in shallow neural
%     network sample dataset.
%   - MATLAB pattern-recognition workflows use one-of-N target form.
%   - The patternnet documentation reports MSE as a performance measure.
%
% Returns:
%   lb, ub, dim, fobj, meta
%
% meta fields:
%   .name
%   .family
%   .N
%   .Max_iter
%   .metric_name
%   .plot_scale

    key = upper(strtrim(fun_name));

    switch key
        case 'M1'   % XOR classification
            n_in  = 2;
            n_hid = 3;
            n_out = 2;

            dim = n_in * n_hid + n_hid + n_hid * n_out + n_out;

            lb = -10 * ones(1, dim);
            ub =  10 * ones(1, dim);

            fobj = @(w) xor_mlp_objective(w, n_in, n_hid, n_out);

            meta = struct();
            meta.name        = 'XOR classification';
            meta.family      = 'MLP';
            meta.N           = 50;
            meta.Max_iter    = 500;
            meta.metric_name = 'Average MSE';
            meta.plot_scale  = 'logy';

        case 'M2'   % Cancer classification
            n_in  = 9;
            n_hid = 10;
            n_out = 2;

            dim = n_in * n_hid + n_hid + n_hid * n_out + n_out;

            lb = -10 * ones(1, dim);
            ub =  10 * ones(1, dim);

            fobj = @(w) cancer_mlp_objective(w, n_in, n_hid, n_out);

            meta = struct();
            meta.name        = 'Cancer classification';
            meta.family      = 'MLP';
            meta.N           = 200;
            meta.Max_iter    = 500;
            meta.metric_name = 'Average MSE';
            meta.plot_scale  = 'logy';

        otherwise
            error('MLP_info:UnknownProblem', ...
                'Unknown MLP problem label: %s', fun_name);
    end
end

% =========================================================
% XOR objective
% =========================================================
function y = xor_mlp_objective(w, n_in, n_hid, n_out)

    % XOR inputs: columns are samples
    X = [0 0 1 1;
         0 1 0 1];

    % One-hot targets:
    % class 1 for XOR output 0 -> [1;0]
    % class 2 for XOR output 1 -> [0;1]
    T = [1 0 0 1;
         0 1 1 0];

    y = mlp_mse_objective(w, X, T, n_in, n_hid, n_out);
end

% =========================================================
% Cancer objective
% =========================================================
function y = cancer_mlp_objective(w, n_in, n_hid, n_out)

    persistent Xc Tc is_loaded

    if isempty(is_loaded)
        if exist('cancer_dataset', 'file') ~= 2
            error(['MLP_info:cancer_dataset:NotFound', newline, ...
                   'The built-in MATLAB function cancer_dataset was not found. ', ...
                   'This usually requires the relevant neural network/deep learning dataset support.']);
        end

        [Xc, Tc] = cancer_dataset;

        % Defensive checks
        if size(Xc, 1) ~= n_in
            error('MLP_info:CancerInputDimMismatch', ...
                'Expected %d cancer inputs, but dataset returned %d.', n_in, size(Xc, 1));
        end

        if size(Tc, 1) ~= n_out
            error('MLP_info:CancerTargetDimMismatch', ...
                'Expected %d cancer target rows, but dataset returned %d.', n_out, size(Tc, 1));
        end

        % Ensure finite numeric data
        Xc = double(Xc);
        Tc = double(Tc);

        if any(~isfinite(Xc(:))) || any(~isfinite(Tc(:)))
            error('MLP_info:CancerDatasetNonFinite', ...
                'Cancer dataset contains non-finite values.');
        end

        is_loaded = true;
    end

    y = mlp_mse_objective(w, Xc, Tc, n_in, n_hid, n_out);
end

% =========================================================
% Shared MLP MSE objective
% =========================================================
function mse_val = mlp_mse_objective(w, X, T, n_in, n_hid, n_out)

    % Decode weight vector
    [W1, b1, W2, b2] = decode_mlp_weights(w, n_in, n_hid, n_out);

    % Forward pass
    Z1 = W1 * X + b1;
    A1 = tansig_local(Z1);

    Z2 = W2 * A1 + b2;
    Y  = logsig_local(Z2);

    % Mean squared error over all outputs and all samples
    E = Y - T;
    mse_val = mean(E(:).^2);

    % Numerical safety
    if ~isscalar(mse_val) || ~isfinite(mse_val)
        mse_val = realmax('double') / 1e100;
    end
end

% =========================================================
% Weight decoder
% =========================================================
function [W1, b1, W2, b2] = decode_mlp_weights(w, n_in, n_hid, n_out)

    w = double(w(:));
    expected_dim = n_in * n_hid + n_hid + n_hid * n_out + n_out;

    if numel(w) ~= expected_dim
        error('MLP_info:WeightLengthMismatch', ...
            'Expected weight vector length %d, but got %d.', expected_dim, numel(w));
    end

    idx = 1;

    W1 = reshape(w(idx : idx + n_in * n_hid - 1), n_hid, n_in);
    idx = idx + n_in * n_hid;

    b1 = reshape(w(idx : idx + n_hid - 1), n_hid, 1);
    idx = idx + n_hid;

    W2 = reshape(w(idx : idx + n_hid * n_out - 1), n_out, n_hid);
    idx = idx + n_hid * n_out;

    b2 = reshape(w(idx : idx + n_out - 1), n_out, 1);
end

% =========================================================
% Local activation functions
% =========================================================
function y = tansig_local(x)
    % Equivalent to MATLAB tansig
    y = 2 ./ (1 + exp(-2 * x)) - 1;
end

function y = logsig_local(x)
    % Equivalent to MATLAB logsig
    y = 1 ./ (1 + exp(-x));
end