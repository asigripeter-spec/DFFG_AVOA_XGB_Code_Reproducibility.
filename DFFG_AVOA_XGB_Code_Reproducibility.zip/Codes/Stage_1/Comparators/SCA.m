function [Best_score, Best_pos, Convergence_curve] = SCA(N, Max_iter, lb, ub, dim, fobj)
% SCA: Sine Cosine Algorithm
% Refactored for use in a generic benchmarking framework.
%
% Interface:
%   [Best_score, Best_pos, Convergence_curve] = SCA(N, Max_iter, lb, ub, dim, fobj)
%
% Inputs:
%   N        - Population size (number of search agents)
%   Max_iter - Maximum number of iterations
%   lb, ub   - Lower and upper bounds (scalar or 1-by-dim vectors)
%   dim      - Problem dimension
%   fobj     - Handle to objective function: f = fobj(x)
%
% Outputs:
%   Best_score        - Best objective value found
%   Best_pos          - Best solution vector
%   Convergence_curve - 1-by-Max_iter vector of best-so-far values
%
% Based on:
%   S. Mirjalili, "SCA: A Sine Cosine Algorithm for solving optimization
%   problems", Knowledge-Based Systems, 2016.

    % Map external iteration count to the original variable name
    Max_iteration = Max_iter;

    % Initialize the set of random solutions
    X = initialization(N, dim, ub, lb);

    Destination_position = zeros(1, dim);
    Destination_fitness  = inf;

    Convergence_curve = zeros(1, Max_iteration);
    Objective_values  = zeros(1, size(X, 1));

    % Calculate the fitness of the first set and find the initial best
    for i = 1:size(X, 1)
        Objective_values(1, i) = fobj(X(i, :));

        if i == 1
            Destination_position = X(i, :);
            Destination_fitness  = Objective_values(1, i);
        elseif Objective_values(1, i) < Destination_fitness
            Destination_position = X(i, :);
            Destination_fitness  = Objective_values(1, i);
        end
    end

    % Store initial best fitness
    Convergence_curve(1) = Destination_fitness;

    % Main loop
    t = 2; % start from the second iteration since the first was used for fitness evaluation
    while t <= Max_iteration

        % Parameter r1 decreases linearly from a to 0 (Eq. (3.4))
        a  = 2;
        r1 = a - t * (a / Max_iteration);

        % Update the position of solutions with respect to the destination
        for i = 1:size(X, 1)           % i-th solution
            for j = 1:size(X, 2)       % j-th dimension

                % Update r2, r3, and r4 for Eq. (3.3)
                r2 = (2 * pi) * rand();
                r3 = 2 * rand;
                r4 = rand();

                % Position update (Eqs. (3.1) and (3.2))
                if r4 < 0.5
                    % Eq. (3.1)
                    X(i, j) = X(i, j) + ...
                              r1 * sin(r2) * abs(r3 * Destination_position(j) - X(i, j));
                else
                    % Eq. (3.2)
                    X(i, j) = X(i, j) + ...
                              r1 * cos(r2) * abs(r3 * Destination_position(j) - X(i, j));
                end

            end
        end

        % Boundary handling and fitness evaluation
        for i = 1:size(X, 1)

            % Bring solutions back to the search space if they go out of bounds
            Flag4ub = X(i, :) > ub;
            Flag4lb = X(i, :) < lb;
            X(i, :) = (X(i, :) .* (~(Flag4ub + Flag4lb))) + ...
                      ub .* Flag4ub + lb .* Flag4lb;

            % Calculate objective value
            Objective_values(1, i) = fobj(X(i, :));

            % Update the destination if there is a better solution
            if Objective_values(1, i) < Destination_fitness
                Destination_position = X(i, :);
                Destination_fitness  = Objective_values(1, i);
            end
        end

        % Record best-so-far value
        Convergence_curve(t) = Destination_fitness;

        % Increase the iteration counter
        t = t + 1;
    end

    % Map to framework output names
    Best_score = Destination_fitness;
    Best_pos   = Destination_position;

end


% -------------------------------------------------------------------------
% Helper: initialization of the SCA population
% -------------------------------------------------------------------------
function X = initialization(SearchAgents_no, dim, ub, lb)
% initialization: create the first random population of search agents.
%
%   SearchAgents_no - number of search agents (N)
%   dim             - dimension of the search space
%   ub, lb          - upper and lower bounds; scalar or vector of length dim

    Boundary_no = size(ub, 2); % number of boundaries

    % If the boundaries of all variables are equal and user entered a single
    % number for both ub and lb
    if Boundary_no == 1
        X = rand(SearchAgents_no, dim) .* (ub - lb) + lb;
        return;
    end

    % If each variable has a different lb and ub
    X = zeros(SearchAgents_no, dim);
    if Boundary_no > 1
        for i = 1:dim
            ub_i    = ub(i);
            lb_i    = lb(i);
            X(:, i) = rand(SearchAgents_no, 1) .* (ub_i - lb_i) + lb_i;
        end
    end

end
