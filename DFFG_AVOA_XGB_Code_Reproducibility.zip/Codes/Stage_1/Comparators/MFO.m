function [Best_score, Best_pos, Convergence_curve] = MFO(N, Max_iter, lb, ub, dim, fobj)
%______________________________________________________________________________________________
%  Moth Flame Optimization Algorithm (MFO)
%  Source codes demo version 1.0
%
%  Refactored for use in a generic benchmarking framework:
%    - Uses N, Max_iter, lb, ub, dim, fobj from external main script
%    - No internal benchmark selection
%    - No plotting or console output
%
%  Original main reference:
%  S. Mirjalili, Moth Flame Optimization Algorithm: A Novel Nature-inspired
%  Heuristic Paradigm, Knowledge-Based Systems, 2015.
%______________________________________________________________________________________________

    % Map to original variable name used in the source code
    Max_iteration = Max_iter;

    % Initialize the positions of moths
    Moth_pos = mfo_initialization(N, dim, ub, lb);

    Convergence_curve = zeros(1, Max_iteration);

    Iteration = 1;

    % Main loop
    while Iteration < Max_iteration + 1

        % Number of flames, Eq. (3.14) in the paper
        Flame_no = round(N - Iteration * ((N - 1) / Max_iteration));

        % Evaluate fitness of moths
        for i = 1:size(Moth_pos, 1)

            % Boundary control
            Flag4ub = Moth_pos(i, :) > ub;
            Flag4lb = Moth_pos(i, :) < lb;
            Moth_pos(i, :) = (Moth_pos(i, :) .* (~(Flag4ub + Flag4lb))) + ...
                              ub .* Flag4ub + lb .* Flag4lb;

            % Calculate fitness of moths
            Moth_fitness(1, i) = fobj(Moth_pos(i, :));
        end

        if Iteration == 1
            % Sort the first population of moths
            [fitness_sorted, I] = sort(Moth_fitness);
            sorted_population   = Moth_pos(I, :);

            % Update flames
            best_flames        = sorted_population;
            best_flame_fitness = fitness_sorted;
        else
            % Sort the moths and previous best flames
            double_population = [previous_population; best_flames];
            double_fitness    = [previous_fitness best_flame_fitness];

            [double_fitness_sorted, I] = sort(double_fitness);
            double_sorted_population   = double_population(I, :);

            fitness_sorted   = double_fitness_sorted(1:N);
            sorted_population = double_sorted_population(1:N, :);

            % Update the flames
            best_flames        = sorted_population;
            best_flame_fitness = fitness_sorted;
        end

        % Update the position of the best flame obtained so far
        Best_flame_score = fitness_sorted(1);
        Best_flame_pos   = sorted_population(1, :);

        previous_population = Moth_pos;
        previous_fitness    = Moth_fitness;

        % a linearly decreases from -1 to -2 to calculate t in Eq. (3.12)
        a = -1 + Iteration * ((-1) / Max_iteration);

        % Position update
        for i = 1:size(Moth_pos, 1)
            for j = 1:size(Moth_pos, 2)
                if i <= Flame_no
                    % Update the position of the moth with respect to its corresponding flame

                    % Distance to flame, Eq. (3.13)
                    distance_to_flame = abs(sorted_population(i, j) - Moth_pos(i, j));
                    b = 1;
                    t = (a - 1) * rand + 1;

                    % Spiral equation, Eq. (3.12)
                    Moth_pos(i, j) = distance_to_flame * exp(b * t) * cos(t * 2 * pi) + ...
                                     sorted_population(i, j);
                else
                    % Update the position of the moth with respect to the last flame

                    distance_to_flame = abs(sorted_population(Flame_no, j) - Moth_pos(i, j));
                    b = 1;
                    t = (a - 1) * rand + 1;

                    % Spiral equation, Eq. (3.12)
                    Moth_pos(i, j) = distance_to_flame * exp(b * t) * cos(t * 2 * pi) + ...
                                     sorted_population(Flame_no, j);
                end
            end
        end

        % Record best score for this iteration
        Convergence_curve(Iteration) = Best_flame_score;

        Iteration = Iteration + 1;
    end

    % Map to framework output names
    Best_score = Best_flame_score;
    Best_pos   = Best_flame_pos;

end


%______________________________________________________________________________________________
%  Initialization function (inlined from initialization.m)
%______________________________________________________________________________________________
function X = mfo_initialization(SearchAgents_no, dim, ub, lb)
% mfo_initialization: initialize the population of moths within bounds.
%
%   SearchAgents_no - number of moths (N)
%   dim             - dimension of the search space
%   ub, lb          - upper and lower bounds; scalar or vector of length dim

    Boundary_no = size(ub, 2);  % number of boundaries

    % Preallocate
    X = zeros(SearchAgents_no, dim);

    % If the boundaries of all variables are equal and user entered a single
    % number for both ub and lb
    if Boundary_no == 1
        X = rand(SearchAgents_no, dim) .* (ub - lb) + lb;
    end

    % If each variable has a different lb and ub
    if Boundary_no > 1
        for i = 1:dim
            ub_i = ub(i);
            lb_i = lb(i);
            X(:, i) = rand(SearchAgents_no, 1) .* (ub_i - lb_i) + lb_i;
        end
    end

end
