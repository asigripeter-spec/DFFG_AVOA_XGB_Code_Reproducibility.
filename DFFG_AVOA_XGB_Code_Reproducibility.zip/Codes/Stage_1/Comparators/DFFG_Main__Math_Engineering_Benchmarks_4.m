%% DFFG_Main_Master.m
%
% Master comparative study driver for:
%   - Mathematical benchmark problems
%   - Engineering design problems
%   - MLP classification problems
%
% Supported families:
%   problem_family = 'Math' | 'Eng' | 'MLP' | 'Both' | 'All'
%
% Routing:
%   F* -> fun_info.m
%   E* -> GFD.m
%   M* -> MLP_info.m
%
% Outputs:
%   - Per-problem convergence figures (.png and .fig)
%   - Composite plots for Math / MLP / Both / All when enabled
%   - Per-problem Excel sheets
%   - Journal summary sheet
%   - Engineering_Best_Designs sheet
%   - Engineering_Stats sheet
%   - Plain-text log via diary
%   - Raw MATLAB results file (.mat) for Python/post-processing use
%
% Notes:
%   - Engineering mode disables composite plots by default
%   - Positive convergence curves use semilogy; nonpositive curves use a linear y-axis
%   - MLP problems can override N and Max_iter through MLP_info.m
%   - Engineering objective evaluation is wrapped for numerical safety
%   - AOA internal console spam is suppressed at the driver level only

clear; clc; close all;

%% 0. LOGGING SETUP

study_name   = 'IDFFG_Master_Study_Math_6New_Corrected';
log_filename = [study_name, '_Log.txt'];

if strcmpi(get(0, 'Diary'), 'on')
    diary off;
end

diary(log_filename);
diary on;

fprintf('======================================================================\n');
fprintf('DFFG_Main_Master experiment started at %s\n', datestr(now));
fprintf('Output Log (this file): %s\n', log_filename);
fprintf('======================================================================\n\n');

%% 1. CENTRAL CONFIGURATION

configurations = {
    %'DFF-AVOA',    {'call_DFF_AVOA',   {}};
    %'G1-AVOA',     {'call_G_AVOA',     {true,  false}};
    %'G2-AVOA',     {'call_G_AVOA',     {false, true }};
    %'G-AVOA',      {'call_G_AVOA',     {true,  true }};
    %'DFFG1-AVOA',  {'call_DFFG_AVOA',  {true,  false}};
    %'DFFG2-AVOA',  {'call_DFFG_AVOA',  {false, true }};
    'DFFG-AVOA',   {'call_DFFG_AVOA',  {true,  true}};
    'AVOA',        {'call_AVOA',       {}};
    %'IAVOA',       {'call_IAVOA',      {}};
    'IROAVOA',     {'call_IROAVOA',    {}};
    'GWO',         {'call_GWO',        {}};

    % PSO family
    %'PSO-base',    {'call_PSO',         {}};
    %'PSO-old',     {'call_PSO_old',     {}};
    %'PSO',         {'call_PSO_classic', {}};
    %'PSO',         {'call_PSO_avoa',    {}};

    'AOA',         {'call_AOA',        {}};
    'FPA',         {'call_FPA',        {}};
    %'GOA',         {'call_GOA',        {}};
    'MFO',         {'call_MFO',        {}};
    %'ARO',         {'call_ARO',        {}};
    %'RO',          {'call_RO',         {}};
    %'SSA',         {'call_SSA',        {}};
    'SCA',         {'call_SCA',        {}};
};

problem_family  = 'Math';    % 'Math', 'Eng', 'MLP', 'Both', or 'All'
experiment_mode = 'full';    % 'debug', 'sample', or 'full'

f_list = {};
e_list = {};
m_list = {};

% Mathematical Set Definition
if strcmpi(problem_family, 'Math') || strcmpi(problem_family, 'Both') || strcmpi(problem_family, 'All')
    switch experiment_mode
        case 'debug'
            f_list = {'F5'};
        case 'sample'
            f_list = {'F5','F8','F13','F14','F15','F16','F17','F18','F19','F20','F21','F22','F23'};
        case 'full'
            f_list = arrayfun(@(x) sprintf('F%d', x), 1:23, 'UniformOutput', false);
        otherwise
            error("Invalid 'experiment_mode'. Choose 'debug', 'sample', or 'full'.");
    end
end

% Engineering Set Definition
if strcmpi(problem_family, 'Eng') || strcmpi(problem_family, 'Both') || strcmpi(problem_family, 'All')
    switch experiment_mode
        case 'debug'
            e_list = {'E1'};
        case 'sample'
            e_list = {'E1','E2','E3','E4','E6','E11'};
        case 'full'
            e_list = arrayfun(@(x) sprintf('E%d', x), 1:11, 'UniformOutput', false);
        otherwise
            error("Invalid 'experiment_mode'. Choose 'debug', 'sample', or 'full'.");
    end
end

% MLP Set Definition
if strcmpi(problem_family, 'MLP') || strcmpi(problem_family, 'All')
    switch experiment_mode
        case 'debug'
            m_list = {'M1'};
        case 'sample'
            m_list = {'M1','M2'};
        case 'full'
            m_list = {'M1','M2'};
        otherwise
            error("Invalid 'experiment_mode'. Choose 'debug', 'sample', or 'full'.");
    end
end

benchmark_functions_names = [f_list, e_list, m_list];

% True optima for classical benchmarks
global_optima_definitions = { ...
    'F1',0; 'F2',0; 'F3',0; 'F4',0; 'F5',0; 'F6',0; 'F7',0; ...
    'F8',-418.9829*30; 'F9',0; 'F10',0; 'F11',0; 'F12',0; 'F13',0; ...
    'F14',1; 'F15',0.0003075; 'F16',-1.031628; 'F17',0.397887; ...
    'F18',3; 'F19',-3.86278; 'F20',-3.32237; 'F21',-10.1532; ...
    'F22',-10.4029; 'F23',-10.5364 };

global_optima_map = containers.Map('KeyType', 'char', 'ValueType', 'double');
for k = 1:size(global_optima_definitions, 1)
    global_optima_map(global_optima_definitions{k, 1}) = global_optima_definitions{k, 2};
end

%% 2. GLOBAL EXPERIMENT PARAMETERS

N        = 30;
Max_iter = 500;
num_runs = 30;

color_map = [
    0.0000, 0.0000, 0.0000;
    0.8500, 0.3250, 0.0980;
    0.9290, 0.6940, 0.1250;
    0.4940, 0.1840, 0.5560;
    0.4660, 0.6740, 0.1880;
    0.3010, 0.7450, 0.9330;
    0.6350, 0.0780, 0.1840;
    0.2000, 0.2000, 0.8000;
    0.8000, 0.2000, 0.2000;
    0.6000, 0.3000, 0.0000;
];

line_styles   = {'-','--',':','-.','-','--',':','-.'};
marker_styles = {'none','none','none','none','o','s','^','d'};
marker_every  = 40;

% --- Algorithm-Specific Parameters (AVOA family) ---
param_avoa.P1        = 0.6;
param_avoa.P2        = 0.4;
param_avoa.P3        = 0.6;
param_avoa.w         = 2.5;
param_avoa.beta_levy = 1.5;
param_avoa.L1_fixed  = 0.8;

param_dff_avoa           = param_avoa;
param_dff_avoa.K_min     = 2;
param_dff_avoa.K_abs_max = 3;
param_dff_avoa.alpha     = 0.55;
param_dff_avoa.gamma_K   = 1.0;

param_g_avoa.P_apply_gauss_spiral   = 0.15;
param_g_avoa.sigma_g_spiral_initial = 0.33;
param_g_avoa.L_gauss_iter           = 12;
param_g_avoa.sigma_g_best_initial   = 0.85;

param_dffg_avoa                            = param_dff_avoa;
param_dffg_avoa.n_init                     = 20;
param_dffg_avoa.kmeans_max_iter            = 60;
param_dffg_avoa.epsilon_stag               = 1e-12;
param_dffg_avoa.s_boost                    = 8;
param_dffg_avoa.s_restart                  = 10;
param_dffg_avoa.P_apply_gauss_spiral       = 0.15;
param_dffg_avoa.sigma_g_spiral_initial     = 0.33;
param_dffg_avoa.L_gauss_iter               = 12;
param_dffg_avoa.sigma_g_best_initial       = 0.85;
param_dffg_avoa.tau_basin                  = 0.40;
param_dffg_avoa.omega_f                    = 0.75;
param_dffg_avoa.omega_d                    = 0.25;
param_dffg_avoa.c_L                        = 2.5;
param_dffg_avoa.c_sigma                    = 1.7;
param_dffg_avoa.tightening_start_ratio     = 0.80;
param_dffg_avoa.tightening_delta_Pg1       = 0.05;
param_dffg_avoa.tightening_delta_Lg2       = 2;
param_dffg_avoa.eps_denom                  = 1e-10;
param_dffg_avoa.use_directional_tightening = true;
param_dffg_avoa.eta_T                      = 0.70;
param_dffg_avoa.L_dir                      = 8; %chnage from 8 to 12
param_dffg_avoa.M_e                        = 3;
param_dffg_avoa.kappa_parallel             = 1.2692; % change from 1.2692
param_dffg_avoa.kappa_perp                 = 0.249; %chnage from 0.25 to 0.249
param_dffg_avoa.lambda_c0                  = 0.35;
param_dffg_avoa.L_contraction              = 2;
param_dffg_avoa.enable_restart             = true;
param_dffg_avoa.q_restart                  = 0.10;

param_iavoa      = param_avoa;
param_iavoa.DE_F = 0.5;
param_iroavoa    = param_avoa;

param_pso.c1    = 1.0;
param_pso.c2    = 1.0;
param_pso.w     = 0.7;
param_pso.v_max = 0.2;
param_pso.v_min = -0.2;

param_pso_old = param_pso;

param_pso_classic.c1 = 2.0;
param_pso_classic.c2 = 2.0;

param_pso_avoa.w  = 1;
param_pso_avoa.c1 = 2.0;
param_pso_avoa.c2 = 2.0;

zero_tol = 1e-320;

%% 3. OUTPUT CONTROL / STORAGE

save_individual_figures = true;

if strcmpi(problem_family, 'Eng')
    generate_composite_plots = false;
else
    generate_composite_plots = true;
end

disp('--- Initializing Experiment ---');

excel_filename            = [study_name, '_Statistics.xlsx'];
figures_directory         = [study_name, '_Figures'];
composite_plots_directory = [study_name, '_Composite_Plots'];
mat_filename              = [study_name, '_RawResults.mat'];

if save_individual_figures && ~exist(figures_directory, 'dir')
    mkdir(figures_directory);
end
if generate_composite_plots && ~exist(composite_plots_directory, 'dir')
    mkdir(composite_plots_directory);
end
if exist(excel_filename, 'file')
    try
        delete(excel_filename);
    catch
    end
end
if exist(mat_filename, 'file')
    try
        delete(mat_filename);
    catch
    end
end

num_benchmarks = numel(benchmark_functions_names);
num_algorithms = size(configurations, 1);

all_best_scores_raw         = cell(num_algorithms, 1);
all_convergence_curves_cell = cell(num_algorithms, 1);
all_best_positions_cell     = cell(num_algorithms, 1);

for i = 1:num_algorithms
    all_best_scores_raw{i}         = nan(num_benchmarks, num_runs);
    all_convergence_curves_cell{i} = cell(num_benchmarks, num_runs);
    all_best_positions_cell{i}     = cell(num_benchmarks, num_runs);
end

all_mean_results = nan(num_benchmarks, num_algorithms);
all_std_results  = nan(num_benchmarks, num_algorithms);
all_mae_results  = nan(num_benchmarks, num_algorithms);
all_min_results  = nan(num_benchmarks, num_algorithms);
all_max_results  = nan(num_benchmarks, num_algorithms);
all_rank_results = nan(num_benchmarks, num_algorithms);

% MAE and Worst remain calculated and saved for backward-compatible diagnostics,
% but they are excluded from journal reporting and ranking.

all_best_designs = cell(num_benchmarks, num_algorithms);

disp('Initialization complete.');
disp(repmat('=', 1, 80));

%% 4. MAIN EXPERIMENT LOOP

for f_idx = 1:num_benchmarks
    Fun_name  = benchmark_functions_names{f_idx};
    prob_name = get_problem_name(Fun_name);

    if isempty(prob_name)
        fprintf('\nProcessing Function: %s (%d/%d)\n', Fun_name, f_idx, num_benchmarks);
    else
        fprintf('\nProcessing Function: %s - %s (%d/%d)\n', ...
            Fun_name, prob_name, f_idx, num_benchmarks);
    end
    fprintf('%s\n', repmat('-', 1, 70));

    % Load benchmark
    clear N_local Max_iter_local mlp_meta

    if startsWith(Fun_name, 'F', 'IgnoreCase', true)
        [lb, ub, dim, fobj] = fun_info(Fun_name);

    elseif startsWith(Fun_name, 'E', 'IgnoreCase', true)
        gfd_name = ['F', Fun_name(2:end)];
        [lb, ub, dim, fobj_raw] = GFD(gfd_name);
        fobj = @(x) safe_objective_wrapper(fobj_raw, x);

    elseif startsWith(Fun_name, 'M', 'IgnoreCase', true)
        [lb, ub, dim, fobj, mlp_meta] = MLP_info(Fun_name);

        if isfield(mlp_meta, 'N') && ~isempty(mlp_meta.N)
            N_local = mlp_meta.N;
        else
            N_local = N;
        end

        if isfield(mlp_meta, 'Max_iter') && ~isempty(mlp_meta.Max_iter)
            Max_iter_local = mlp_meta.Max_iter;
        else
            Max_iter_local = Max_iter;
        end

    else
        error('Unknown benchmark label: %s', Fun_name);
    end

    % True optimum for MAE if available
    if isKey(global_optima_map, Fun_name)
        true_optimum_value = global_optima_map(Fun_name);
        if strcmpi(Fun_name, 'F8') && dim ~= 30
            true_optimum_value = -418.9829 * dim;
        end
    else
        true_optimum_value = NaN;
    end

    % Per-algorithm runs
    for algo_idx = 1:num_algorithms
        algo_name = configurations{algo_idx, 1};
        call_info = configurations{algo_idx, 2};
        call_type = call_info{1};
        call_args = call_info{2};

        fprintf('\n  Running Algorithm: %s\n', algo_name);

        N_run = N;
        Max_iter_run = Max_iter;

        if startsWith(Fun_name, 'M', 'IgnoreCase', true)
            if exist('N_local', 'var') && ~isempty(N_local)
                N_run = N_local;
            end
            if exist('Max_iter_local', 'var') && ~isempty(Max_iter_local)
                Max_iter_run = Max_iter_local;
            end
        end

        for r = 1:num_runs
            Best_score_run        = NaN;
            Best_pos_run          = [];
            Convergence_curve_run = [];
            run_h_fixed           = -2 + 4*rand();

            switch call_type
                case 'call_AVOA'
                    param_run = param_avoa;
                    param_run.h_fixed_for_run = run_h_fixed;
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        AVOA(N_run, Max_iter_run, lb, ub, dim, fobj, param_run);

                case 'call_DFF_AVOA'
                    param_run = param_dff_avoa;
                    param_run.h_fixed_for_run = run_h_fixed;
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        DFF_AVOA(N_run, Max_iter_run, lb, ub, dim, fobj, param_run);

                case 'call_G_AVOA'
                    param_run = param_g_avoa;
                    param_run.use_G1 = call_args{1};
                    param_run.use_G2 = call_args{2};
                    param_run.h_fixed_for_run = run_h_fixed;
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        G_AVOA(N_run, Max_iter_run, lb, ub, dim, fobj, param_run);

                case 'call_DFFG_AVOA'
                    param_run = param_dffg_avoa;
                    param_run.use_G1 = call_args{1};
                    param_run.use_G2 = call_args{2};
                    param_run.h_fixed_for_run = run_h_fixed;
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        DFFG_AVOA(N_run, Max_iter_run, lb, ub, dim, fobj, param_run);

                case 'call_IAVOA'
                    param_run = param_iavoa;
                    param_run.h_fixed_for_run = run_h_fixed;
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        IAVOA(N_run, Max_iter_run, lb, ub, dim, fobj, param_run);

                case 'call_IROAVOA'
                    param_run = param_iroavoa;
                    param_run.h_fixed_for_run = run_h_fixed;
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        IROAVOA(N_run, Max_iter_run, lb, ub, dim, fobj, param_run);

                case 'call_GWO'
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        GWO(N_run, Max_iter_run, lb, ub, dim, fobj);

                case 'call_PSO'
                    param_run = param_pso;
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        PSO(N_run, Max_iter_run, lb, ub, dim, fobj, param_run);

                case 'call_PSO_old'
                    param_run = param_pso_old;
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        PSO_old(N_run, Max_iter_run, lb, ub, dim, fobj, param_run);

                case 'call_PSO_classic'
                    param_run = param_pso_classic;
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        PSO_Classic(N_run, Max_iter_run, lb, ub, dim, fobj, param_run);

                case 'call_PSO_avoa'
                    param_run = param_pso_avoa;
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        PSO_AVOA(N_run, Max_iter_run, lb, ub, dim, fobj, param_run);

                case 'call_AOA'
                    % Suppress AOA internal console spam while preserving its outputs
                    aoa_eval_str = ['[Best_score_run, Best_pos_run, Convergence_curve_run] = ' ...
                                    'AOA(N_run, Max_iter_run, lb, ub, dim, fobj);'];
                    evalc(aoa_eval_str);

                case 'call_FPA'
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        FPA(N_run, Max_iter_run, lb, ub, dim, fobj);

                case 'call_GOA'
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        GOA(N_run, Max_iter_run, lb, ub, dim, fobj);

                case 'call_MFO'
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        MFO(N_run, Max_iter_run, lb, ub, dim, fobj);

                case 'call_ARO'
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        ARO(N_run, Max_iter_run, lb, ub, dim, fobj);

                case 'call_RO'
                    NMR = max(1, round(0.5 * N_run));
                    NCR = max(1, N_run - NMR);
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        RO(NMR, NCR, Max_iter_run, lb, ub, dim, fobj);

                case 'call_SSA'
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        SSA(N_run, Max_iter_run, lb, ub, dim, fobj);

                case 'call_SCA'
                    [Best_score_run, Best_pos_run, Convergence_curve_run] = ...
                        SCA(N_run, Max_iter_run, lb, ub, dim, fobj);

                otherwise
                    error('Unknown call_type: %s', call_type);
            end

            % Report the same decoded engineering design used by the objective.
            % Mathematical F1-F23 and MLP problems are not altered.
            if startsWith(Fun_name, 'E', 'IgnoreCase', true) && ~isempty(Best_pos_run)
                Best_pos_run   = decode_engineering_design(Fun_name, Best_pos_run);
                Best_score_run = fobj(Best_pos_run);
            end

            all_best_scores_raw{algo_idx}(f_idx, r)         = Best_score_run;
            all_convergence_curves_cell{algo_idx}{f_idx, r} = Convergence_curve_run;
            all_best_positions_cell{algo_idx}{f_idx, r}     = Best_pos_run;

            fprintf('    Run %d/%d Best (%s): %.12g\n', r, num_runs, algo_name, Best_score_run);
        end
    end

    %% 4a. Statistics for this function
    for algo_idx = 1:num_algorithms
        raw_scores = all_best_scores_raw{algo_idx}(f_idx, :);
        valid_run_mask = ~isnan(raw_scores);
        scores = raw_scores(valid_run_mask);

        if isempty(scores)
            continue;
        end

        all_min_results(f_idx, algo_idx)  = min(scores);
        all_max_results(f_idx, algo_idx)  = max(scores);
        all_mean_results(f_idx, algo_idx) = mean(scores);
        all_std_results(f_idx, algo_idx)  = sqrt(sum((scores - mean(scores)).^2) / numel(scores));

        if ~isnan(true_optimum_value)
            all_mae_results(f_idx, algo_idx) = mean(abs(scores - true_optimum_value));
        end

        valid_run_idx = find(valid_run_mask);
        [~, best_local_idx] = min(scores);
        best_run_idx = valid_run_idx(best_local_idx);
        all_best_designs{f_idx, algo_idx} = all_best_positions_cell{algo_idx}{f_idx, best_run_idx};
    end

    %% 4b. Strict lexicographic ranking
    % Ranking priority: Mean -> Std -> Best
    rank_matrix = nan(num_algorithms, 3);
    rank_matrix(:, 1) = all_mean_results(f_idx, :)';
    rank_matrix(:, 2) = all_std_results(f_idx, :)';
    rank_matrix(:, 3) = all_min_results(f_idx, :)';

    valid_algorithms = all(~isnan(rank_matrix), 2);
    valid_idx = find(valid_algorithms);

    if ~isempty(valid_idx)
        temp = rank_matrix(valid_idx, :);

        [~, sorted_local] = sortrows(temp, [1 2 3]);
        sorted_idx = valid_idx(sorted_local);

        current_rank = 1;
        all_rank_results(f_idx, sorted_idx(1)) = current_rank;

        for k = 2:numel(sorted_idx)
            prev = rank_matrix(sorted_idx(k - 1), :);
            curr = rank_matrix(sorted_idx(k), :);

            if isequal(prev, curr)
                all_rank_results(f_idx, sorted_idx(k)) = current_rank;
            else
                current_rank = k;
                all_rank_results(f_idx, sorted_idx(k)) = current_rank;
            end
        end
    end

    %% 4c. Mean convergence plot for this function
    if save_individual_figures
        hfig = figure('Visible', 'off');
        hold on;
        grid on;
        box on;

        legend_handles = gobjects(0);
        legend_labels  = {};

        for algo_idx = 1:num_algorithms
            curves = all_convergence_curves_cell{algo_idx}(f_idx, :);
            valid_curves = curves(~cellfun(@isempty, curves));
            if isempty(valid_curves)
                continue;
            end

            max_len = max(cellfun(@numel, valid_curves));
            curve_matrix = nan(numel(valid_curves), max_len);

            for rr = 1:numel(valid_curves)
                c = valid_curves{rr};
                if isempty(c)
                    continue;
                end
                curve_matrix(rr, 1:numel(c)) = c;
                if numel(c) < max_len
                    curve_matrix(rr, numel(c)+1:end) = c(end);
                end
            end

            mean_curve = mean(curve_matrix, 1, 'omitnan');

            plot_color   = color_map(mod(algo_idx - 1, size(color_map, 1)) + 1, :);
            line_style   = line_styles{mod(algo_idx - 1, numel(line_styles)) + 1};
            marker_style = marker_styles{mod(algo_idx - 1, numel(marker_styles)) + 1};

            if all(isfinite(mean_curve)) && all(mean_curve > 0)
                h = semilogy(1:numel(mean_curve), mean_curve, ...
                    'LineWidth', 1.8, ...
                    'Color', plot_color, ...
                    'LineStyle', line_style, ...
                    'DisplayName', configurations{algo_idx, 1});
            else
                h = plot(1:numel(mean_curve), mean_curve, ...
                    'LineWidth', 1.8, ...
                    'Color', plot_color, ...
                    'LineStyle', line_style, ...
                    'DisplayName', configurations{algo_idx, 1});
            end

            if ~strcmp(marker_style, 'none')
                set(h, ...
                    'Marker', marker_style, ...
                    'MarkerIndices', 1:marker_every:numel(mean_curve), ...
                    'MarkerSize', 5);
            end

            legend_handles(end+1) = h;
            legend_labels{end+1}  = configurations{algo_idx, 1};
        end

        xlabel('Iteration');

        if startsWith(Fun_name, 'M', 'IgnoreCase', true) && exist('mlp_meta', 'var') && isfield(mlp_meta, 'metric_name')
            ylabel(mlp_meta.metric_name);
        else
            ylabel('Objective Value');
        end

        if isempty(prob_name)
            title(Fun_name, 'FontWeight', 'normal');
        else
            title(sprintf('%s - %s', Fun_name, prob_name), 'FontWeight', 'normal');
        end

        if ~isempty(legend_handles)
            legend(legend_handles, legend_labels, ...
                'Location', 'northeast', ...
                'Interpreter', 'none', ...
                'FontSize', 10, ...
                'Box', 'on');
        end

        hold off;

        saveas(hfig, fullfile(figures_directory, [Fun_name, '.png']));
        savefig(hfig, fullfile(figures_directory, [Fun_name, '.fig']));
        close(hfig);
    end

    %% 4d. Per-function Excel sheet
    is_engineering_problem = startsWith(Fun_name, 'E', 'IgnoreCase', true);
    is_mlp_problem         = startsWith(Fun_name, 'M', 'IgnoreCase', true);

    excel_content = {};
    row_idx = 1;

    if isempty(prob_name)
        excel_content(row_idx, 1) = {['Raw Scores for ', Fun_name]};
    else
        excel_content(row_idx, 1) = {['Raw Scores for ', Fun_name, ' (', prob_name, ')']};
    end
    row_idx = row_idx + 1;

    headers_raw = [{'Algorithm'}, arrayfun(@(r) sprintf('Run %d', r), 1:num_runs, 'UniformOutput', false)];
    excel_content(row_idx, 1:numel(headers_raw)) = headers_raw;
    row_idx = row_idx + 1;

    for algo_idx = 1:num_algorithms
        excel_content{row_idx, 1} = configurations{algo_idx, 1};
        for r = 1:num_runs
            v = all_best_scores_raw{algo_idx}(f_idx, r);
            if ~isnan(v) && abs(v) < zero_tol
                v = 0;
            end
            excel_content{row_idx, r + 1} = v;
        end
        row_idx = row_idx + 1;
    end

    if is_engineering_problem
        row_idx = row_idx + 2;

        excel_content(row_idx, 1) = {['Optimization Results for ', Fun_name, ' (', prob_name, ')']};
        row_idx = row_idx + 1;

        excel_content{row_idx, 1} = 'Variable';
        for algo_idx = 1:num_algorithms
            excel_content{row_idx, 1 + algo_idx} = configurations{algo_idx, 1};
        end
        row_idx = row_idx + 1;

        for j = 1:dim
            excel_content{row_idx, 1} = get_engineering_variable_label(Fun_name, j);

            for algo_idx = 1:num_algorithms
                xbest = all_best_designs{f_idx, algo_idx};

                if ~isempty(xbest) && numel(xbest) >= j
                    xv = xbest(j);
                    if ~isnan(xv) && abs(xv) < zero_tol
                        xv = 0;
                    end
                    excel_content{row_idx, 1 + algo_idx} = xv;
                else
                    excel_content{row_idx, 1 + algo_idx} = NaN;
                end
            end
            row_idx = row_idx + 1;
        end

        excel_content{row_idx, 1} = 'Best objective value';
        for algo_idx = 1:num_algorithms
            vbest = all_min_results(f_idx, algo_idx);
            if ~isnan(vbest) && abs(vbest) < zero_tol
                vbest = 0;
            end
            excel_content{row_idx, 1 + algo_idx} = vbest;
        end
        row_idx = row_idx + 1;

        row_idx = row_idx + 2;
        excel_content(row_idx, 1) = {['Engineering Statistics for ', Fun_name, ' (', prob_name, ')']};
        row_idx = row_idx + 1;

        excel_content{row_idx, 1} = 'Metric';
        for algo_idx = 1:num_algorithms
            excel_content{row_idx, 1 + algo_idx} = configurations{algo_idx, 1};
        end
        row_idx = row_idx + 1;

        eng_metric_names = {'Mean', 'Std', 'Best objective value', 'Rank'};

        for m = 1:numel(eng_metric_names)
            excel_content{row_idx, 1} = eng_metric_names{m};

            for algo_idx = 1:num_algorithms
                switch eng_metric_names{m}
                    case 'Mean'
                        v = all_mean_results(f_idx, algo_idx);
                    case 'Std'
                        v = all_std_results(f_idx, algo_idx);
                    case 'Best objective value'
                        v = all_min_results(f_idx, algo_idx);
                    case 'Rank'
                        v = all_rank_results(f_idx, algo_idx);
                end

                if ~isnan(v) && ~strcmp(eng_metric_names{m}, 'Rank')
                    if abs(v) < zero_tol
                        v = 0;
                    end
                end

                excel_content{row_idx, 1 + algo_idx} = v;
            end
            row_idx = row_idx + 1;
        end

    else
        row_idx = row_idx + 2;

        if is_mlp_problem && exist('mlp_meta', 'var') && isfield(mlp_meta, 'metric_name')
            excel_content(row_idx, 1) = {['Summary Stats for ', Fun_name, ' (', prob_name, ', ', mlp_meta.metric_name, ')']};
        elseif isempty(prob_name)
            excel_content(row_idx, 1) = {['Summary Stats for ', Fun_name]};
        else
            excel_content(row_idx, 1) = {['Summary Stats for ', Fun_name, ' (', prob_name, ')']};
        end
        row_idx = row_idx + 1;

        excel_content{row_idx, 1} = 'Metric';
        for algo_idx = 1:num_algorithms
            excel_content{row_idx, 1 + algo_idx} = configurations{algo_idx, 1};
        end
        row_idx = row_idx + 1;

        metric_names = {'Mean', 'Std', 'Best', 'Rank'};

        for m = 1:numel(metric_names)
            excel_content{row_idx, 1} = metric_names{m};

            for algo_idx = 1:num_algorithms
                switch metric_names{m}
                    case 'Mean'
                        v = all_mean_results(f_idx, algo_idx);
                    case 'Std'
                        v = all_std_results(f_idx, algo_idx);
                    case 'Best'
                        v = all_min_results(f_idx, algo_idx);
                    case 'Rank'
                        v = all_rank_results(f_idx, algo_idx);
                end

                if ~isnan(v) && ~strcmp(metric_names{m}, 'Rank')
                    if abs(v) < zero_tol
                        v = 0;
                    end
                end

                excel_content{row_idx, 1 + algo_idx} = v;
            end
            row_idx = row_idx + 1;
        end
    end

    try
        writecell(excel_content, excel_filename, 'Sheet', Fun_name, 'WriteMode', 'overwrite');
        fprintf('  Wrote Excel sheet for %s\n', Fun_name);
    catch ME_xl
        warning('Excel write error for sheet %s: %s', Fun_name, ME_xl.message);
    end
end

%% 5. COMPOSITE PLOTS

if generate_composite_plots && num_benchmarks > 0
    composite_candidates = find(~startsWith(benchmark_functions_names, 'E', 'IgnoreCase', true));

    if ~isempty(composite_candidates)
        group_size = 8;
        num_groups = ceil(numel(composite_candidates) / group_size);

        for gs = 1:num_groups
            idx_group = composite_candidates((gs-1)*group_size + 1 : min(gs*group_size, numel(composite_candidates)));

            hfig = figure('Visible', 'off');
            t = tiledlayout(2, 4, 'TileSpacing', 'compact', 'Padding', 'compact');

            for kk = 1:numel(idx_group)
                f_idx_plot = idx_group(kk);
                nexttile;
                hold on;
                grid on;
                box on;

                for algo_idx = 1:num_algorithms
                    curves = all_convergence_curves_cell{algo_idx}(f_idx_plot, :);
                    valid_curves = curves(~cellfun(@isempty, curves));
                    if isempty(valid_curves)
                        continue;
                    end

                    max_len = max(cellfun(@numel, valid_curves));
                    curve_matrix = nan(numel(valid_curves), max_len);

                    for rr = 1:numel(valid_curves)
                        c = valid_curves{rr};
                        curve_matrix(rr, 1:numel(c)) = c;
                        if numel(c) < max_len
                            curve_matrix(rr, numel(c)+1:end) = c(end);
                        end
                    end

                    mean_curve = mean(curve_matrix, 1, 'omitnan');
                    plot_color   = color_map(mod(algo_idx - 1, size(color_map, 1)) + 1, :);
                    line_style   = line_styles{mod(algo_idx - 1, numel(line_styles)) + 1};
                    marker_style = marker_styles{mod(algo_idx - 1, numel(marker_styles)) + 1};

                    h = semilogy(1:numel(mean_curve), mean_curve, ...
                        'LineWidth', 1.4, ...
                        'Color', plot_color, ...
                        'LineStyle', line_style, ...
                        'DisplayName', configurations{algo_idx, 1});

                    if ~strcmp(marker_style, 'none')
                        set(h, 'Marker', marker_style, ...
                            'MarkerIndices', 1:marker_every:numel(mean_curve), ...
                            'MarkerSize', 4);
                    end
                end

                plot_fun  = benchmark_functions_names{f_idx_plot};
                plot_name = get_problem_name(plot_fun);

                if isempty(plot_name)
                    title(plot_fun, 'FontWeight', 'normal');
                else
                    title(sprintf('%s - %s', plot_fun, plot_name), 'FontWeight', 'normal');
                end

                xlabel('Iter');
                ylabel('Obj');
                hold off;
            end

            lgd = legend(configurations(:, 1), 'Interpreter', 'none', 'Orientation', 'horizontal');
            lgd.Layout.Tile = 'south';

            start_label = benchmark_functions_names{idx_group(1)};
            end_label   = benchmark_functions_names{idx_group(end)};
            title(t, sprintf('Composite Convergence Plots: %s to %s', start_label, end_label));

            composite_name_png = sprintf('Composite_%s_to_%s.png', start_label, end_label);
            composite_name_fig = sprintf('Composite_%s_to_%s.fig', start_label, end_label);

            saveas(hfig, fullfile(composite_plots_directory, composite_name_png));
            savefig(hfig, fullfile(composite_plots_directory, composite_name_fig));
            close(hfig);
        end
    end
end

%% 6. JOURNAL-STYLE SUMMARY SHEET

try
    excel_summary = {};
    r = 1;
    excel_summary{r, 1} = 'Journal-style summary: Mean / Std / Best / Rank for all functions';
    r = r + 2;

    algo_labels = configurations(:, 1)';
    header_row  = [{'No.', 'Metric'}, algo_labels];
    excel_summary(r, 1:numel(header_row)) = header_row;
    r = r + 1;

    metric_names = {'Mean', 'Std', 'Best', 'Rank'};

    for f_idx = 1:num_benchmarks
        Fun_name = benchmark_functions_names{f_idx};

        metric_values = {
            all_mean_results(f_idx, :);
            all_std_results(f_idx, :);
            all_min_results(f_idx, :);
            all_rank_results(f_idx, :)
        };

        for m = 1:numel(metric_names)
            excel_summary{r, 1} = Fun_name;
            excel_summary{r, 2} = metric_names{m};

            for algo_idx = 1:num_algorithms
                v = metric_values{m}(algo_idx);
                if ~isnan(v) && ~strcmp(metric_names{m}, 'Rank')
                    if abs(v) < zero_tol
                        v = 0;
                    end
                end
                excel_summary{r, 2 + algo_idx} = v;
            end

            r = r + 1;
        end
    end

    writecell(excel_summary, excel_filename, 'Sheet', 'Journal_Summary', 'WriteMode', 'overwrite');
    fprintf('Wrote journal-style summary sheet: Journal_Summary\n');

catch ME_js
    warning('Error writing Journal_Summary sheet: %s', ME_js.message);
end

%% 7. ENGINEERING SUMMARY SHEETS

try
    eng_idx = find(startsWith(benchmark_functions_names, 'E', 'IgnoreCase', true));

    if ~isempty(eng_idx)
        eng_best_sheet = {};
        rr = 1;
        eng_best_sheet(rr, 1) = {'Engineering Best Designs'};
        rr = rr + 2;

        for ii = 1:numel(eng_idx)
            f_idx = eng_idx(ii);
            Fun_name  = benchmark_functions_names{f_idx};
            prob_name = get_problem_name(Fun_name);

            current_dim = 0;
            for algo_idx = 1:num_algorithms
                xbest = all_best_designs{f_idx, algo_idx};
                if ~isempty(xbest)
                    current_dim = max(current_dim, numel(xbest));
                end
            end

            if current_dim == 0
                if startsWith(Fun_name, 'E', 'IgnoreCase', true)
                    gfd_name = ['F', Fun_name(2:end)];
                    [~, ~, current_dim, ~] = GFD(gfd_name);
                else
                    current_dim = 0;
                end
            end

            eng_best_sheet{rr, 1} = sprintf('%s - %s', Fun_name, prob_name);
            rr = rr + 1;

            eng_best_sheet{rr, 1} = 'Variable';
            for algo_idx = 1:num_algorithms
                eng_best_sheet{rr, 1 + algo_idx} = configurations{algo_idx, 1};
            end
            rr = rr + 1;

            for j = 1:current_dim
                eng_best_sheet{rr, 1} = get_engineering_variable_label(Fun_name, j);

                for algo_idx = 1:num_algorithms
                    xbest = all_best_designs{f_idx, algo_idx};

                    if ~isempty(xbest) && numel(xbest) >= j
                        xv = xbest(j);
                        if ~isnan(xv) && abs(xv) < zero_tol
                            xv = 0;
                        end
                        eng_best_sheet{rr, 1 + algo_idx} = xv;
                    else
                        eng_best_sheet{rr, 1 + algo_idx} = NaN;
                    end
                end
                rr = rr + 1;
            end

            eng_best_sheet{rr, 1} = 'Best objective value';
            for algo_idx = 1:num_algorithms
                vbest = all_min_results(f_idx, algo_idx);
                if ~isnan(vbest) && abs(vbest) < zero_tol
                    vbest = 0;
                end
                eng_best_sheet{rr, 1 + algo_idx} = vbest;
            end
            rr = rr + 2;
        end

        writecell(eng_best_sheet, excel_filename, ...
            'Sheet', 'Engineering_Best_Designs', 'WriteMode', 'overwrite');
        fprintf('Wrote engineering sheet: Engineering_Best_Designs\n');

        eng_stats_sheet = {};
        rr = 1;
        eng_stats_sheet(rr, 1) = {'Engineering Statistical Summary'};
        rr = rr + 2;

        eng_metric_names = {'Mean', 'Std', 'Best objective value', 'Rank'};

        for ii = 1:numel(eng_idx)
            f_idx = eng_idx(ii);
            Fun_name  = benchmark_functions_names{f_idx};
            prob_name = get_problem_name(Fun_name);

            eng_stats_sheet{rr, 1} = sprintf('%s - %s', Fun_name, prob_name);
            rr = rr + 1;

            eng_stats_sheet{rr, 1} = 'Metric';
            for algo_idx = 1:num_algorithms
                eng_stats_sheet{rr, 1 + algo_idx} = configurations{algo_idx, 1};
            end
            rr = rr + 1;

            for m = 1:numel(eng_metric_names)
                metric_name = eng_metric_names{m};
                eng_stats_sheet{rr, 1} = metric_name;

                for algo_idx = 1:num_algorithms
                    switch metric_name
                        case 'Mean'
                            v = all_mean_results(f_idx, algo_idx);
                        case 'Std'
                            v = all_std_results(f_idx, algo_idx);
                        case 'Best objective value'
                            v = all_min_results(f_idx, algo_idx);
                        case 'Rank'
                            v = all_rank_results(f_idx, algo_idx);
                    end

                    if ~isnan(v) && ~strcmp(metric_name, 'Rank')
                        if abs(v) < zero_tol
                            v = 0;
                        end
                    end

                    eng_stats_sheet{rr, 1 + algo_idx} = v;
                end
                rr = rr + 1;
            end

            rr = rr + 2;
        end

        writecell(eng_stats_sheet, excel_filename, ...
            'Sheet', 'Engineering_Stats', 'WriteMode', 'overwrite');
        fprintf('Wrote engineering sheet: Engineering_Stats\n');
    end

catch ME_eng
    warning('Error writing engineering summary sheets: %s', ME_eng.message);
end

%% 8. SAVE RAW RESULTS TO .MAT

try
    save(mat_filename, ...
        'study_name', ...
        'log_filename', ...
        'excel_filename', ...
        'figures_directory', ...
        'composite_plots_directory', ...
        'benchmark_functions_names', ...
        'configurations', ...
        'problem_family', ...
        'experiment_mode', ...
        'N', ...
        'Max_iter', ...
        'num_runs', ...
        'all_best_scores_raw', ...
        'all_convergence_curves_cell', ...
        'all_best_positions_cell', ...
        'all_mean_results', ...
        'all_std_results', ...
        'all_mae_results', ...
        'all_min_results', ...
        'all_max_results', ...
        'all_rank_results', ...
        'all_best_designs', ...
        'global_optima_definitions', ...
        '-v7.3');
    fprintf('Saved raw results file: %s\n', mat_filename);
catch ME_mat
    warning('Error saving MAT results file: %s', ME_mat.message);
end

%% 9. FINAL CONSOLE SUMMARY

fprintf('\n\n================ FINAL SUMMARY ================\n');

for algo_idx = 1:num_algorithms
    algo_name = configurations{algo_idx, 1};
    fprintf('\n--- Summary for Algorithm: %s ---\n', algo_name);
    fprintf('%-5s | %-28s | %-6s | %-12s | %-12s | %-12s\n', ...
        'Func', 'Problem Name', 'Rank', 'Mean', 'Std', 'Best');
    fprintf('%s\n', repmat('-', 1, 92));

    for f_idx = 1:num_benchmarks
        fun_name  = benchmark_functions_names{f_idx};
        prob_name = get_problem_name(fun_name);

        fprintf('%-5s | %-28s | %-6.2f | %-12.6g | %-12.6g | %-12.6g\n', ...
            fun_name, prob_name, ...
            all_rank_results(f_idx, algo_idx), ...
            all_mean_results(f_idx, algo_idx), ...
            all_std_results(f_idx, algo_idx), ...
            all_min_results(f_idx, algo_idx));
    end
end

eng_idx = find(startsWith(benchmark_functions_names, 'E', 'IgnoreCase', true));

if ~isempty(eng_idx)
    fprintf('\n\n================ ENGINEERING BEST DESIGNS ================\n');

    var_col_width  = 18;
    algo_col_width = 16;

    for k = 1:numel(eng_idx)
        f_idx     = eng_idx(k);
        fun_name  = benchmark_functions_names{f_idx};
        prob_name = get_problem_name(fun_name);

        current_dim = 0;
        for algo_idx = 1:num_algorithms
            xbest = all_best_designs{f_idx, algo_idx};
            if ~isempty(xbest)
                current_dim = max(current_dim, numel(xbest));
            end
        end

        if current_dim == 0
            fprintf('\n%s - %s\n', fun_name, prob_name);
            fprintf('No best design data available.\n');
            continue;
        end

        fprintf('\n%s - %s\n\n', fun_name, prob_name);

        fprintf(['%-', num2str(var_col_width), 's'], 'Variable');
        for algo_idx = 1:num_algorithms
            fprintf(['%-', num2str(algo_col_width), 's'], configurations{algo_idx, 1});
        end
        fprintf('\n');

        fprintf('%s\n', repmat('-', 1, var_col_width + algo_col_width * num_algorithms));

        for j = 1:current_dim
            fprintf(['%-', num2str(var_col_width), 's'], get_engineering_variable_label(fun_name, j));

            for algo_idx = 1:num_algorithms
                xbest = all_best_designs{f_idx, algo_idx};

                if ~isempty(xbest) && numel(xbest) >= j && ~isnan(xbest(j))
                    fprintf(['%-', num2str(algo_col_width), '.6f'], xbest(j));
                else
                    fprintf(['%-', num2str(algo_col_width), 's'], 'NaN');
                end
            end
            fprintf('\n');
        end

        fprintf(['%-', num2str(var_col_width), 's'], 'Best objective value');
        for algo_idx = 1:num_algorithms
            fbest = all_min_results(f_idx, algo_idx);
            if ~isnan(fbest)
                fprintf(['%-', num2str(algo_col_width), '.6f'], fbest);
            else
                fprintf(['%-', num2str(algo_col_width), 's'], 'NaN');
            end
        end
        fprintf('\n');
    end
end

fprintf('\n\nExperiment complete at %s\n', datestr(now));
fprintf('Excel workbook: %s\n', excel_filename);
fprintf('Figure directory: %s\n', figures_directory);
fprintf('Composite plot directory: %s\n', composite_plots_directory);
fprintf('MAT results file: %s\n', mat_filename);

diary off;

%% ============================================================
% LOCAL HELPERS
% ============================================================

function name = get_problem_name(fun_name)
    key = upper(strtrim(fun_name));

    switch key
        case 'F1'
            name = 'Sphere';
        case 'F2'
            name = 'Schwefel 2.22';
        case 'F3'
            name = 'Schwefel 1.2';
        case 'F4'
            name = 'Schwefel 2.21';
        case 'F5'
            name = 'Rosenbrock';
        case 'F6'
            name = 'Step';
        case 'F7'
            name = 'Quartic with noise';
        case 'F8'
            name = 'Schwefel 2.26';
        case 'F9'
            name = 'Rastrigin';
        case 'F10'
            name = 'Ackley';
        case 'F11'
            name = 'Griewank';
        case 'F12'
            name = 'Penalized 1';
        case 'F13'
            name = 'Penalized 2';
        case 'F14'
            name = 'Foxholes';
        case 'F15'
            name = 'Kowalik';
        case 'F16'
            name = 'Six-Hump Camel';
        case 'F17'
            name = 'Branin RCOS';
        case 'F18'
            name = 'Goldstein-Price';
        case 'F19'
            name = 'Hartmann 3D';
        case 'F20'
            name = 'Hartmann 6D';
        case 'F21'
            name = 'Shekel 5';
        case 'F22'
            name = 'Shekel 7';
        case 'F23'
            name = 'Shekel 10';

        case 'E1'
            name = 'Tension/compression spring design';
        case 'E2'
            name = 'Pressure vessel design';
        case 'E3'
            name = 'Welded beam design';
        case 'E4'
            name = 'Speed reducer design';
        case 'E5'
            name = 'Gear train design (continuous)';
        case 'E6'
            name = 'Three-bar truss design';
        case 'E7'
            name = 'Cantilever beam design';
        case 'E8'
            name = 'Multiple disc clutch brake design';
        case 'E9'
            name = 'Gear train design (discrete)';
        case 'E10'
            name = 'Rolling element bearing design';
        case 'E11'
            name = 'Car crashworthiness design';

        case 'M1'
            name = 'XOR classification';
        case 'M2'
            name = 'Cancer classification';

        otherwise
            name = '';
    end
end


function x_decoded = decode_engineering_design(fun_name, x)
    % Decode only mixed/discrete engineering variables. The external
    % E1-E11 labels and the internal GFD('F1')-GFD('F11') routing remain
    % unchanged.
    x_decoded = x;
    key = upper(strtrim(fun_name));

    switch key
        case 'E4'  % Speed reducer: number of pinion teeth
            x_decoded(3) = round(x_decoded(3));

        case 'E9'  % Discrete gear train: all tooth counts
            x_decoded = round(x_decoded);

        case 'E10' % Rolling-element bearing: number of balls
            x_decoded(3) = round(x_decoded(3));

        case 'E11' % Car crashworthiness: two material choices
            material_values = [0.192, 0.345];
            [~, idx8] = min(abs(material_values - x_decoded(8)));
            [~, idx9] = min(abs(material_values - x_decoded(9)));
            x_decoded(8) = material_values(idx8);
            x_decoded(9) = material_values(idx9);
    end
end

function label = get_engineering_variable_label(fun_name, variable_index)
    % Literature-style variable symbols for E1-E11. These labels affect
    % only Excel and console reporting, not the optimization variables.
    key = upper(strtrim(fun_name));

    switch key
        case 'E1'
            labels = {'d','D','N'};
        case 'E2'
            labels = {'T_s','T_h','R','L'};
        case 'E3'
            labels = {'h','l','t','b'};
        case 'E4'
            labels = {'b','m','z','l_1','l_2','d_1','d_2'};
        case 'E5'
            labels = {'T_A','T_B','T_D','T_F'};
        case 'E6'
            labels = {'A_1','A_2'};
        case 'E7'
            labels = {'b_1','b_2','b_3','b_4','b_5'};
        case 'E8'
            labels = {'r_i','r_o','t','F','Z'};
        case 'E9'
            labels = {'T_A','T_B','T_D','T_F'};
        case 'E10'
            labels = {'D_m','D_b','Z','f_i','f_o', ...
                      'K_Dmin','K_Dmax','epsilon','e','zeta'};
        case 'E11'
            labels = {'t_BI','t_BR','t_FS','t_CM','t_DB','t_BL', ...
                      't_RR','M_BI','M_FS','H_B','P_H'};
        otherwise
            labels = {};
    end

    if variable_index >= 1 && variable_index <= numel(labels)
        label = labels{variable_index};
    else
        label = sprintf('x%d', variable_index);
    end
end

function y = safe_objective_wrapper(fobj_raw, x)
    try
        y = fobj_raw(x);
        if ~isscalar(y) || ~isfinite(y)
            y = realmax('double') / 1e100;
        end
    catch
        y = realmax('double') / 1e100;
    end
end