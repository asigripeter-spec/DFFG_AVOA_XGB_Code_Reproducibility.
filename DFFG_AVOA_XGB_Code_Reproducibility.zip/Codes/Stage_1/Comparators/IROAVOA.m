function [Best_score, Best_pos, Convergence_curve] = IROAVOA(N, Max_iter, lb, ub, dim, fobj, params)
% IROAVOA: Improved African Vulture Optimization Algorithm
% 
% This implementation follows:
%   Kuang, X., Hou, J., Liu, X., Lin, C., Wang, Z., & Wang, T. (2024).
%   "Improved African Vulture Optimization Algorithm Based on Random
%   Opposition-Based Learning Strategy," Electronics, 13(16), 3329.
%   DOI: 10.3390/electronics13163329
%
% Inputs:
%   N         - population size
%   Max_iter  - maximum number of iterations
%   lb, ub    - lower and upper bounds (scalar or 1 x dim vectors)
%   dim       - problem dimension
%   fobj      - objective function handle
%   params    - struct with fields:
%                  P1, P2, P3, w, beta_levy, L1_fixed, h_fixed_for_run
%
% Outputs:
%   Best_score        - best objective value found
%   Best_pos          - best position vector
%   Convergence_curve - best fitness per iteration (1 x Max_iter)

% --- Extract Base AVOA Parameters ---
P1       = params.P1;
P2       = params.P2;
P3       = params.P3;
w_param  = params.w;           % used in oscillation term
beta_levy= params.beta_levy;
L1       = params.L1_fixed;    % leader selection probability
h        = params.h_fixed_for_run;

% --- Ensure vector bounds ---
if numel(lb) == 1
    lb = lb .* ones(1, dim);
end
if numel(ub) == 1
    ub = ub .* ones(1, dim);
end

% -------------------------------------------------------------------------
% IROAVOA MODIFICATION: Random Opposition-Based Learning (ROBL) for init
%   x_op = L1 + L2 - (rand * x)  (Eq. (25) in Kuang et al. 2024)
% -------------------------------------------------------------------------
% Step 1: Generate initial random population
Initial_Positions = rand(N, dim) .* (ub - lb) + lb;

% Step 2: Generate ROBL population
ROBL_Positions = (lb + ub) - rand(N, dim) .* Initial_Positions;

% Step 3: Boundary control for ROBL positions
ROBL_Positions = max(ROBL_Positions, lb);
ROBL_Positions = min(ROBL_Positions, ub);

% Step 4: Combine original + ROBL populations and select best N
Combined_Positions = [Initial_Positions; ROBL_Positions];
Combined_Fitness   = zeros(2*N, 1);
for i = 1:(2*N)
    Combined_Fitness(i) = fobj(Combined_Positions(i, :));
end

[sorted_combined_fitness, sort_indices] = sort(Combined_Fitness);
Vulture_Positions = Combined_Positions(sort_indices(1:N), :);
Vulture_Fitness   = sorted_combined_fitness(1:N);

% --- Identify the best two vultures ---
[sorted_fitness, sort_indices] = sort(Vulture_Fitness);
Best_vulture1_pos = Vulture_Positions(sort_indices(1), :);
Best_vulture2_pos = Vulture_Positions(sort_indices(2), :);
Best_score        = sorted_fitness(1);
Best_pos          = Best_vulture1_pos;

% --- Convergence curve ---
Convergence_curve    = zeros(1, Max_iter);
Convergence_curve(1) = Best_score;

% -------------------------------------------------------------------------
% Main optimization loop
% -------------------------------------------------------------------------
t = 1;
while t < Max_iter

    % --- Hunger / oscillation factor (AVOA-style) ---
    % Oscillatory term using w_param and h
    t_osc = h * (sin(pi * t / Max_iter)^w_param + cos(pi * t / Max_iter) - 1);
    z     = -1 + 2 * rand();                         % z in [-1,1]
    F_hunger = (2 * rand() + 1) * z * (1 - (t / Max_iter)) + t_osc;
    absF = abs(F_hunger);

    % --- For each vulture ---
    for i = 1:N

        current_pos = Vulture_Positions(i, :);
        current_fit = Vulture_Fitness(i);

        % ---------------- Leader selection (Best_vulture1 vs Best_vulture2) ---
        if rand() < L1
            R_i = Best_vulture1_pos;
        else
            R_i = Best_vulture2_pos;
        end

        % Default new position
        new_pos = current_pos;

        % =====================================================================
        % PHASE 1: Exploration (|F| >= 1) with disturbance factor w
        %   w = 0.5 * (0.1 + rand) * N(0,1)  (Eq. (19))
        %   Eq. (20) and Eq. (21) for the two exploration strategies
        % =====================================================================
        if absF >= 1

            w_dist = (0.5 * (0.1 + rand())) * randn();   % disturbance factor

            % AVOA distance term with X in [0,2]
            X = 2 * rand();   % IROAVOA: X in [0,2] as in original AVOA
            D_i = abs(X * R_i - current_pos);

            if rand() < P1
                % Perturbed guided search (Eq. (20))
                new_pos = R_i * (1 - w_dist) - D_i * F_hunger * w_dist;
            else
                % Perturbed random search (Eq. (21))
                new_pos = R_i * w_dist ...
                        - F_hunger ...
                        + rand(1, dim) .* ((ub - lb) * rand() + lb);
            end

        % =====================================================================
        % PHASE 2 & 3: Exploitation (unchanged AVOA behaviour)
        % =====================================================================
        else
            if absF >= 0.5
                % ------------------ Competition stage -------------------------
                if rand() < P2
                    % Competition strategy
                    D_i = abs((2 * rand()) * R_i - current_pos);
                    d_t = R_i - current_pos;
                    new_pos = D_i * (F_hunger + rand()) - d_t;
                else
                    % Spiral movement strategy
                    s1 = R_i .* ((rand(1, dim) .* current_pos) / (2 * pi)) .* cos(current_pos);
                    s2 = R_i .* ((rand(1, dim) .* current_pos) / (2 * pi)) .* sin(current_pos);
                    new_pos = R_i - (s1 + s2);
                end
            else
                % ------------------ Aggregation stage ------------------------
                if rand() < P3
                    % Aggregation strategy 1
                    A1 = Best_vulture1_pos - ...
                         ((Best_vulture1_pos .* current_pos) ./ ...
                         (Best_vulture1_pos - current_pos.^2 + eps)) * F_hunger;
                    A2 = Best_vulture2_pos - ...
                         ((Best_vulture2_pos .* current_pos) ./ ...
                         (Best_vulture2_pos - current_pos.^2 + eps)) * F_hunger;
                    new_pos = (A1 + A2) / 2;
                else
                    % Aggregation strategy 2: Lévy flight attack
                    d_t = R_i - current_pos;
                    new_pos = R_i - abs(d_t) .* F_hunger .* levy(dim, beta_levy);
                end
            end
        end

        % --- Boundary control ---
        new_pos = max(new_pos, lb);
        new_pos = min(new_pos, ub);

        % --- Greedy replacement ---
        new_fit = fobj(new_pos);
        if new_fit < current_fit
            Vulture_Positions(i, :) = new_pos;
            Vulture_Fitness(i)      = new_fit;
        end

    end % for i = 1:N

    % --- Update global best ---
    [current_best_fit, best_idx] = min(Vulture_Fitness);
    if current_best_fit < Best_score
        Best_score = current_best_fit;
        Best_pos   = Vulture_Positions(best_idx, :);
    end

    % --- Re-identify the top two vultures ---
    [sorted_fitness, sort_indices] = sort(Vulture_Fitness);
    Best_vulture1_pos = Vulture_Positions(sort_indices(1), :);
    Best_vulture2_pos = Vulture_Positions(sort_indices(2), :);

    % --- Record convergence and advance iteration ---
    t = t + 1;
    Convergence_curve(t) = Best_score;

end % while t < Max_iter

end % function IROAVOA
