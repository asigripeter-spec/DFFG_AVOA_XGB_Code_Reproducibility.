function [Best_score, Best_pos, Convergence_curve] = FPA(N, Max_iter, lb, ub, dim, fobj)
% FPA: Flower Pollination Algorithm
% Refactored from the original demo by Xin-She Yang (2012) for use in a
% generic benchmarking framework.
%
% Interface:
%   [Best_score, Best_pos, Convergence_curve] = FPA(N, Max_iter, lb, ub, dim, fobj)
%
% Inputs:
%   N         - Population size
%   Max_iter  - Number of iterations
%   lb, ub    - Lower and upper bounds (scalar or 1-by-dim vectors)
%   dim       - Problem dimension
%   fobj      - Handle to objective function: f = fobj(x)
%
% Outputs:
%   Best_score        - Best objective value found
%   Best_pos          - Best solution vector
%   Convergence_curve - 1-by-Max_iter vector of best values over iterations

    % Switch probability (as in the original demo)
    p = 0.8;

    % Ensure bounds are row vectors of length dim
    if numel(lb) == 1
        Lb = lb .* ones(1, dim);
    else
        Lb = lb(:).';
    end

    if numel(ub) == 1
        Ub = ub .* ones(1, dim);
    else
        Ub = ub(:).';
    end

    % Population size and iteration count
    n       = N;
    N_iter  = Max_iter;
    d       = dim;

    % Preallocate
    Sol     = zeros(n, d);
    Fitness = zeros(n, 1);

    % Initialize the population / solutions
    for i = 1:n
        Sol(i, :)  = Lb + (Ub - Lb) .* rand(1, d);
        Fitness(i) = fobj(Sol(i, :));
    end

    % Find the current best
    [fmin, I] = min(Fitness);
    best      = Sol(I, :);
    S         = Sol;

    % Convergence history
    Convergence_curve = zeros(1, N_iter);

    % Start the iterations: Flower Pollination Algorithm
    for t = 1:N_iter

        % Loop over all solutions
        for i = 1:n

            % Global pollination with Levy flights
            % Pollens are carried by insects and thus can move in
            % large scale, long distance.
            % Formula (global pollination):
            %   x_i^{t+1} = x_i^t + L .* (x_i^t - gbest)
            if rand > p
                % L is a Levy flight step
                Lstep = Levy(d);
                dS    = Lstep .* (Sol(i, :) - best);
                S(i, :) = Sol(i, :) + dS;

                % Apply simple bounds
                S(i, :) = simplebounds(S(i, :), Lb, Ub);

            else
                % Local pollination of neighbour flowers
                epsilon = rand;

                % Randomly choose two solutions from the population
                JK = randperm(n);
                % Local pollination (if same or similar species)
                % Formula (local pollination):
                %   x_i^{t+1} = x_i^t + epsilon * (x_j^t - x_k^t)
                S(i, :) = S(i, :) + epsilon * (Sol(JK(1), :) - Sol(JK(2), :));

                % Apply simple bounds
                S(i, :) = simplebounds(S(i, :), Lb, Ub);
            end

            % Evaluate new solution
            Fnew = fobj(S(i, :));

            % If fitness improves, update the solution
            if Fnew <= Fitness(i)
                Sol(i, :)  = S(i, :);
                Fitness(i) = Fnew;
            end

            % Update the current global best
            if Fnew <= fmin
                best = S(i, :);
                fmin = Fnew;
            end
        end

        % Record best-so-far
        Convergence_curve(t) = fmin;
    end

    % Final outputs
    Best_score = fmin;
    Best_pos   = best;

end


% ------------------------------------------------------------------------
% Helper: simple bounds handling (vectorised)
% ------------------------------------------------------------------------
function s = simplebounds(s, Lb, Ub)
% simplebounds: enforce lower and upper bounds on a solution vector s.

    % Ensure row shape for safety
    s = s(:).';

    % Lower bound
    s(s < Lb) = Lb(s < Lb);

    % Upper bound
    s(s > Ub) = Ub(s > Ub);

end


% ------------------------------------------------------------------------
% Helper: draw one Levy flight step of dimension d
% ------------------------------------------------------------------------
function L = Levy(d)
% Levy: generate a Levy flight step of length d.
% Based on Mantegna's algorithm, as used in the original FPA demo.

    % Levy exponent and coefficient
    beta  = 3 / 2;
    sigma = (gamma(1 + beta) * sin(pi * beta / 2) / ...
            (gamma((1 + beta) / 2) * beta * 2^((beta - 1) / 2)))^(1 / beta);

    u = randn(1, d) * sigma;
    v = randn(1, d);
    step = u ./ (abs(v).^(1 / beta));

    % Scaling factor (as in the original demo)
    L = 0.01 * step;

end
