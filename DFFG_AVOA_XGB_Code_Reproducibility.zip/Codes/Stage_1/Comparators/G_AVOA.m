function [Best_score, Best_pos, Convergence_curve] = G_AVOA(N, Max_iter, lb, ub, dim, fobj, params)
% G-AVOA: Gaussian-Enhanced African Vulture Optimization Algorithm
% Based on the paper "A Hierarchically Enhanced African Vulture Optimization Algorithm"
% This version implements the logic from Section 4 of the provided paper.
% It is made flexible with flags to enable G-1 and G-2 mechanisms independently.

% --- Extract Base AVOA Parameters ---
P1 = params.P1;
P2 = params.P2;
P3 = params.P3;
w = params.w;
beta_levy = params.beta_levy;
L1 = params.L1_fixed; 
h = params.h_fixed_for_run;

% --- Extract G-AVOA Specific Parameters & Flags ---
use_G1 = params.use_G1; % Flag to enable/disable G-1 Spiral Refinement
use_G2 = params.use_G2; % Flag to enable/disable G-2 Global Best Refinement
P_apply_gauss_spiral = params.P_apply_gauss_spiral;
sigma_g_spiral_initial = params.sigma_g_spiral_initial;
L_gauss_iter = params.L_gauss_iter;
sigma_g_best_initial = params.sigma_g_best_initial;

% --- Initialization ---
Vulture_Positions = rand(N, dim) .* (ub - lb) + lb;
Vulture_Fitness = zeros(N, 1);
for i = 1:N
    Vulture_Fitness(i) = fobj(Vulture_Positions(i, :));
end

[sorted_fitness, sort_indices] = sort(Vulture_Fitness);
Best_vulture1_pos = Vulture_Positions(sort_indices(1), :);
Best_vulture1_fit = sorted_fitness(1);
Best_vulture2_pos = Vulture_Positions(sort_indices(2), :);

Convergence_curve = zeros(1, Max_iter);
Convergence_curve(1) = Best_vulture1_fit;
Best_pos = Best_vulture1_pos;
Best_score = Best_vulture1_fit;

% --- Main Loop ---
t = 1;
while t < Max_iter
    % For each vulture
    for i = 1:N
        % --- Phase 1: Determine Best Vulture ---
        if rand() < L1
            R_i = Best_vulture1_pos;
        else
            R_i = Best_vulture2_pos;
        end

        % --- Phase 2: Rate of Starvation ---
        t_osc = h * (sin((pi * t / Max_iter))^w + cos(pi * t / Max_iter) - 1);
        z = -1 + 2 * rand();
        F_hunger = (2 * rand() + 1) * z * (1 - (t / Max_iter)) + t_osc;
        
        current_pos = Vulture_Positions(i, :);
        new_pos = current_pos;

        % --- Exploration vs. Exploitation ---
        if abs(F_hunger) >= 1 % Exploration (Unchanged)
            if rand() < P1
                D_i = abs((2 * rand()) * R_i - current_pos);
                new_pos = R_i - D_i * F_hunger;
            else
                new_pos = R_i - F_hunger + rand(1, dim) .* ((ub - lb) * rand() + lb);
            end
        else % Exploitation (Partially Modified for G-1)
            if abs(F_hunger) >= 0.5 % Competition Stage
                if rand() < P2 % Strategy 1: Competitive Movement (Unchanged)
                    D_i = abs((2 * rand()) * R_i - current_pos);
                    d_t = R_i - current_pos;
                    new_pos = D_i * (F_hunger + rand()) - d_t;
                else % Strategy 2: Spiral Movement (Potentially enhanced by G-1)
                    s1 = R_i .* ((rand().*current_pos) / (2*pi)) .* cos(current_pos);
                    s2 = R_i .* ((rand().*current_pos) / (2*pi)) .* sin(current_pos);
                    P_spiral = R_i - (s1 + s2); % Base spiral position from Eq. 14
                    
                    % --- G-1: Gaussian Refinement of Spiral Movement (Section 4.2.1) ---
                    if use_G1 && rand() < P_apply_gauss_spiral
                        % Adaptive step size for G-1 (Eq. 24)
                        sigma_t_spiral = sigma_g_spiral_initial * (1 - t / Max_iter);
                        % Apply Gaussian perturbation (Eq. 22)
                        new_pos = P_spiral + sigma_t_spiral * randn(1, dim);
                    else
                        new_pos = P_spiral; % Use standard spiral position
                    end
                end
            else % Aggregation Stage (Unchanged)
                if rand() < P3
                    A1 = Best_vulture1_pos - ((Best_vulture1_pos .* current_pos) ./ (Best_vulture1_pos - current_pos.^2 + eps)) * F_hunger;
                    A2 = Best_vulture2_pos - ((Best_vulture2_pos .* current_pos) ./ (Best_vulture2_pos - current_pos.^2 + eps)) * F_hunger;
                    new_pos = (A1 + A2) / 2;
                else
                    d_t = R_i - current_pos;
                    new_pos = R_i - abs(d_t) .* F_hunger .* levy(dim, beta_levy);
                end
            end
        end
        
        % --- Boundary Checking and Greedy Selection ---
        new_pos = max(new_pos, lb);
        new_pos = min(new_pos, ub);
        new_fit = fobj(new_pos);
        if new_fit < Vulture_Fitness(i)
            Vulture_Fitness(i) = new_fit;
            Vulture_Positions(i, :) = new_pos;
        end
    end % End of vulture loop
    
    % Re-identify the top two vultures for the next iteration
    [sorted_fitness, sort_indices] = sort(Vulture_Fitness);
    Best_vulture1_pos = Vulture_Positions(sort_indices(1), :);
    Best_vulture2_pos = Vulture_Positions(sort_indices(2), :);
    
    % Update the overall best found so far
    if sorted_fitness(1) < Best_score
        Best_score = sorted_fitness(1);
        Best_pos = Vulture_Positions(sort_indices(1), :);
    end
    
    % --- G-2: Dedicated Gaussian Local Search on Global Best (Section 4.2.2) ---
    if use_G2
        % Adaptive step size for G-2 (Eq. 25, quadratic decay)
        sigma_t_best = sigma_g_best_initial * (1 - (t / Max_iter))^2;
        
        % Iterative refinement loop (Eq. 23)
        for l = 1:L_gauss_iter
            P_cand = Best_pos + sigma_t_best * randn(1, dim);
            
            % Check boundaries
            P_cand = max(P_cand, lb);
            P_cand = min(P_cand, ub);
            
            f_cand = fobj(P_cand);
            if f_cand < Best_score
                Best_score = f_cand;
                Best_pos = P_cand;
            end
        end
    end

    t = t + 1;
    Convergence_curve(t) = Best_score;
end % End of main while loop
end