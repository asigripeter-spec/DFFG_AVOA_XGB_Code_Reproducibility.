%% DFFG_Benchmark_Friedman_Wilcoxon_AOA_Final4_4_1.m
% Reproducible statistical analysis for the F1-F23 mathematical benchmarks.
%
% PURPOSE
%   1. Reproduce an AOA-style Friedman ranking table (proposed manuscript
%      Table 13) from the 30-run MEAN objective value of each algorithm on
%      each benchmark function.
%   2. Perform pairwise two-sided Wilcoxon rank-sum tests between DFFG-AVOA
%      and each comparator using the RAW 30-run final objective values, and
%      produce an AOA-style p-value / H / S table (proposed manuscript
%      Table 14).
%   3. Preserve a complete audit trail and validation record.
%   4. Produce one native-Word transfer document containing manuscript
%      Tables 10-15. Tables 10-12 retain the current manuscript-facing content;
%      Table 15 retains the same engineering values but presents each design
%      variable on its own row for direct cross-algorithm comparison;
%      Tables 13-14 are the validated statistical tables.
%
% IMPORTANT METHODOLOGICAL CONTROLS
%   - All F1-F23 problems are minimisation problems: smaller is better.
%   - Friedman blocks = benchmark functions (23 rows).
%   - Friedman treatments = algorithms (8 columns).
%   - Friedman input = 30-run mean objective value for each function/algorithm.
%   - Proper average ranks are used for exact ties via tiedrank.
%   - Wilcoxon uses ranksum, NOT signrank, because run indices are not
%     established as matched experimental pairs.
%   - DFFG-AVOA is always the first ranksum sample x.
%   - Wilcoxon is two-sided, alpha = 0.05, method = approximate.
%   - Table 14 separates statistical significance (H) from performance
%     direction (S), following the adopted AOA reporting architecture:
%         H = 1  -> statistically significant difference at alpha = 0.05
%         H = 0  -> no statistically significant difference detected
%         z < 0  -> S = '+'; observed rank direction favours DFFG-AVOA
%         z > 0  -> S = '-'; observed rank direction favours comparator
%         z = 0  -> S = '='; no directional distinction
%   - Therefore H = 0 may legitimately occur with S = '+' or S = '-'.
%   - The Table 14 summary follows the AOA display order (W|L|T) and
%     counts the S symbols, not the H decisions.
%
% REQUIRED TOOLBOX
%   Statistics and Machine Learning Toolbox (friedman, tiedrank, ranksum).
%
% INPUT FILES
%   IDFFG_Master_Study_Math_6New_Corrected_RawResults.mat
%   IDFFG_Master_Study_Eng_6New_Corrected_RawResults.mat
%
% OUTPUT FILES
%   DFFG_Benchmark_Friedman_Wilcoxon_AOA_Final4_4_1.xlsx
%   DFFG_Benchmark_Friedman_Wilcoxon_AOA_Final_Results4_4_1.mat
%   DFFG_Benchmark_Friedman_Wilcoxon_AOA_Final4_4_1_Log.txt
%   DFFG_Benchmark_Tables_10_15_Word_V4_4_1.docx
%   DFFG_Benchmark_Friedman_Wilcoxon_AOA_Final4_4_1_Error.mat  (failure only)
%
% V4.4.1 IS SELF-CONTAINED
%   Runtime inputs required: the authoritative mathematical and engineering
%   raw-results MAT files listed above. V4.4 does not read earlier scripts,
%   earlier Excel outputs, earlier Results MAT files, or earlier logs.
%   Tables 10-12 preserve frozen manuscript-facing display strings;
%   Table 15 preserves the same manuscript engineering values while changing
%   only their presentation from vectors to one-variable-per-row;
%   the raw MAT files are used to validate those strings, not overwrite them.
%
% The script does not alter the original raw-results MAT file or the
% manuscript's existing descriptive benchmark tables.

clear; clc;

analysis_version = "AOA_HS_DIRECTION_FINAL_V4_4_1_TABLE15_COM_FIX";
fprintf('\n============================================================\n');
fprintf('RUNNING: DFFG_Benchmark_Friedman_Wilcoxon_AOA_Final4_4_1.m\n');
fprintf('VERSION: %s\n', analysis_version);
fprintf('FILE: %s.m\n', mfilename('fullpath'));
fprintf('============================================================\n\n');

%% 1. USER-FACING SETTINGS

input_mat_name = 'IDFFG_Master_Study_Math_6New_Corrected_RawResults.mat';
input_eng_mat_name = 'IDFFG_Master_Study_Eng_6New_Corrected_RawResults.mat';
output_xlsx_name = 'DFFG_Benchmark_Friedman_Wilcoxon_AOA_Final4_4_1.xlsx';
output_mat_name  = 'DFFG_Benchmark_Friedman_Wilcoxon_AOA_Final_Results4_4_1.mat';
output_log_name  = 'DFFG_Benchmark_Friedman_Wilcoxon_AOA_Final4_4_1_Log.txt';
output_error_mat_name = 'DFFG_Benchmark_Friedman_Wilcoxon_AOA_Final4_4_1_Error.mat';
output_tables_10_15_docx_name = 'DFFG_Benchmark_Tables_10_15_Word_V4_4_1.docx';

alpha = 0.05;
expected_num_runs = 30;
expected_N = 30;
expected_Max_iter = 500;

expected_algorithms = [ ...
    "DFFG-AVOA"; ...
    "AVOA"; ...
    "IROAVOA"; ...
    "GWO"; ...
    "AOA"; ...
    "FPA"; ...
    "MFO"; ...
    "SCA"];

expected_functions = arrayfun(@(k) sprintf('F%d', k), 1:23, ...
    'UniformOutput', false)';

%% 2. RESOLVE INPUT / OUTPUT PATHS

script_full_path = mfilename('fullpath');
if isempty(script_full_path)
    script_dir = pwd;
else
    script_dir = fileparts(script_full_path);
end

output_xlsx = fullfile(script_dir, output_xlsx_name);
output_mat  = fullfile(script_dir, output_mat_name);
output_log  = fullfile(script_dir, output_log_name);
output_error_mat = fullfile(script_dir, output_error_mat_name);
output_tables_10_15_docx = fullfile(script_dir, output_tables_10_15_docx_name);

% Start a fresh persistent text log before resolving the raw input file.
% This ensures that missing-input and other early failures are recorded.
if exist(output_log, 'file') == 2
    delete(output_log);
end
if exist(output_error_mat, 'file') == 2
    delete(output_error_mat);
end
if exist(output_tables_10_15_docx, 'file') == 2
    delete(output_tables_10_15_docx);
end

% Stage/status variables distinguish statistical, Excel/MAT, and Word failures.
current_stage = "INITIALISATION";
statistical_validation_pass = false;
excel_export_pass = false;
mat_save_pass = false;
word_export_pass = false;
word_validation = struct();
manuscript_table_validation = struct();
manuscript_table_validation_pass = false;
input_eng_mat = ''; % initialise so early input-resolution failures are still logged safely

diary off;
diary(output_log);
diary on;
diary_cleanup = onCleanup(@() diary('off'));

fprintf('\n============================================================\n');
fprintf('LOG-ENABLED RUN STARTED\n');
fprintf('VERSION: %s\n', analysis_version);
fprintf('SCRIPT: %s.m\n', mfilename('fullpath'));
fprintf('LOG: %s\n', output_log);
fprintf('START TIME: %s\n', datestr(now, 31));
fprintf('============================================================\n\n');

try
    current_stage = "INPUT_RESOLUTION";
    input_mat = resolveInputFile(input_mat_name, script_dir);
    input_eng_mat = resolveInputFile(input_eng_mat_name, script_dir);

    fprintf('======================================================================\n');
    fprintf('DFFG-AVOA BENCHMARK STATISTICAL ANALYSIS\n');
    fprintf('Math input: %s\n', input_mat);
    fprintf('Eng input : %s\n', input_eng_mat);
    fprintf('Output Excel: %s\n', output_xlsx);
    fprintf('Output MAT  : %s\n', output_mat);
    fprintf('Output Log  : %s\n', output_log);
    fprintf('Output Word : %s\n', output_tables_10_15_docx);
    fprintf('======================================================================\n\n');

    current_stage = "RAW_DATA_AUDIT";

%% 3. LOAD ONLY THE REQUIRED AUTHORITATIVE VARIABLES

required_vars = { ...
    'benchmark_functions_names', ...
    'configurations', ...
    'N', ...
    'Max_iter', ...
    'num_runs', ...
    'all_best_scores_raw', ...
    'all_mean_results', ...
    'all_std_results', ...
    'all_min_results', ...
    'all_rank_results'};

S = load(input_mat, required_vars{:});

for k = 1:numel(required_vars)
    assert(isfield(S, required_vars{k}), ...
        'Required variable "%s" is missing from the MAT file.', required_vars{k});
end

%% 4. VALIDATE EXPERIMENT IDENTITY AND ORIENTATION

assert(S.num_runs == expected_num_runs, ...
    'Expected %d runs, but MAT file reports %d.', expected_num_runs, S.num_runs);
assert(S.N == expected_N, ...
    'Expected population size N = %d, but MAT file reports %g.', expected_N, S.N);
assert(S.Max_iter == expected_Max_iter, ...
    'Expected Max_iter = %d, but MAT file reports %g.', expected_Max_iter, S.Max_iter);

loaded_functions = string(S.benchmark_functions_names(:));
expected_functions_string = string(expected_functions(:));
assert(isequal(loaded_functions, expected_functions_string), ...
    'Benchmark-function order is not exactly F1-F23. Audit the MAT file before continuing.');

loaded_algorithms = string(S.configurations(:, 1));
assert(isequal(loaded_algorithms, expected_algorithms), ...
    ['Algorithm order does not match the frozen order: DFFG-AVOA, AVOA, ' ...
     'IROAVOA, GWO, AOA, FPA, MFO, SCA.']);

num_functions = numel(expected_functions);
num_algorithms = numel(expected_algorithms);

assert(numel(S.all_best_scores_raw) == num_algorithms, ...
    'Expected %d raw-score matrices, found %d.', ...
    num_algorithms, numel(S.all_best_scores_raw));
assert(isequal(size(S.all_mean_results), [num_functions, num_algorithms]), ...
    'all_mean_results must be 23 x 8.');
assert(isequal(size(S.all_std_results), [num_functions, num_algorithms]), ...
    'all_std_results must be 23 x 8.');
assert(isequal(size(S.all_min_results), [num_functions, num_algorithms]), ...
    'all_min_results must be 23 x 8.');

%% 5. RAW-DATA AUDIT AND RECOMPUTATION OF DESCRIPTIVE QUANTITIES

raw_cube = nan(num_functions, num_algorithms, expected_num_runs);
recomputed_mean = nan(num_functions, num_algorithms);
recomputed_std_population = nan(num_functions, num_algorithms);
recomputed_best = nan(num_functions, num_algorithms);

for a = 1:num_algorithms
    A = S.all_best_scores_raw{a};

    assert(isequal(size(A), [num_functions, expected_num_runs]), ...
        'Raw-score matrix for %s must be 23 x 30, but is %s.', ...
        expected_algorithms(a), mat2str(size(A)));

    assert(~any(isnan(A), 'all'), ...
        'Unexpected NaN found in raw results for %s. Audit before testing.', ...
        expected_algorithms(a));
    assert(~any(isinf(A), 'all'), ...
        'Unexpected Inf found in raw results for %s. Audit before testing.', ...
        expected_algorithms(a));

    raw_cube(:, a, :) = reshape(A, [num_functions, 1, expected_num_runs]);

    for f = 1:num_functions
        x = A(f, :);
        mu = mean(x);
        recomputed_mean(f, a) = mu;

        % Matches the benchmark driver: denominator = number of runs (R),
        % not the sample-standard-deviation denominator R-1.
        recomputed_std_population(f, a) = ...
            sqrt(sum((x - mu).^2) / numel(x));
        recomputed_best(f, a) = min(x);
    end
end

% Exact reproduction is expected because the same raw values and formulas
% are used. If a future MATLAB version produces a tiny arithmetic-order
% difference, the fallback tolerance check still prevents false alarms.
assertMatrixMatch(recomputed_mean, S.all_mean_results, ...
    '30-run mean values');
assertMatrixMatch(recomputed_std_population, S.all_std_results, ...
    'population standard deviations');
assertMatrixMatch(recomputed_best, S.all_min_results, ...
    'best objective values');

fprintf('Raw-data audit passed: 23 functions x 8 algorithms x 30 runs.\n');
fprintf('Stored Mean/Std/Best quantities reproduce from the raw data.\n\n');

current_stage = "FRIEDMAN_ANALYSIS";

%% 6. FRIEDMAN ANALYSIS FOR PROPOSED MANUSCRIPT TABLE 13
%
% AOA-style construction:
%   - one row per benchmark case;
%   - algorithms ranked using the mean objective value for that case;
%   - lower objective value = better rank;
%   - average ranks retained for exact ties;
%   - mean rank across F1-F23;
%   - final ranking from the mean ranks.
%
% The formal MATLAB friedman() call uses the same 23 x 8 mean matrix:
% rows = benchmark-function blocks, columns = algorithm treatments.

friedman_input_means = recomputed_mean;

[friedman_p, friedman_anova_table, friedman_stats] = ...
    friedman(friedman_input_means, 1, 'off');

friedman_h = double(friedman_p < alpha);

friedman_function_ranks = nan(num_functions, num_algorithms);
for f = 1:num_functions
    friedman_function_ranks(f, :) = tiedrank(friedman_input_means(f, :));
end

friedman_mean_rank = mean(friedman_function_ranks, 1);
friedman_final_ranking = tiedrank(friedman_mean_rank);

% Extract inferential quantities from MATLAB's returned ANOVA-style table.
friedman_df = friedman_anova_table{2, 3};
friedman_chi_square = friedman_anova_table{2, 5};

% Where available, cross-check MATLAB's stored mean ranks against our
% explicit tiedrank calculation. The explicit matrix is retained because
% it is exactly what is needed for the manuscript table.
if isfield(friedman_stats, 'meanranks')
    matlab_mean_ranks = friedman_stats.meanranks(:)';
    if max(abs(matlab_mean_ranks - friedman_mean_rank)) > 1e-12
        error('Explicit Friedman mean ranks do not match friedman() stats.meanranks.');
    end
end

% Table 13 follows the AOA visual architecture without the unnecessary Dim
% column because this study uses one implemented setting per F1-F23 case.
table13 = cell(num_functions + 3, num_algorithms + 1);
table13(1, :) = [{'F'}, cellstr(expected_algorithms)'];

for f = 1:num_functions
    table13{f + 1, 1} = expected_functions{f};
    for a = 1:num_algorithms
        table13{f + 1, a + 1} = friedman_function_ranks(f, a);
    end
end

table13{num_functions + 2, 1} = 'Mean Rank';
table13{num_functions + 3, 1} = 'Final Ranking';
for a = 1:num_algorithms
    % Manuscript-facing display follows the compact AOA-style format.
    % Full-precision mean ranks remain in the audit sheets and MAT output.
    table13{num_functions + 2, a + 1} = sprintf('%.2f', friedman_mean_rank(a));
    table13{num_functions + 3, a + 1} = friedman_final_ranking(a);
end

friedman_summary = table( ...
    alpha, friedman_p, friedman_h, friedman_chi_square, friedman_df, ...
    num_functions, num_algorithms, ...
    'VariableNames', { ...
    'Alpha', 'PValue', 'H', 'ChiSquare', 'DF', ...
    'BenchmarkBlocks', 'Algorithms'});

fprintf('Friedman analysis completed.\n');
fprintf('  p-value     = %.16g\n', friedman_p);
fprintf('  H           = %d\n', friedman_h);
fprintf('  Chi-square  = %.16g\n', friedman_chi_square);
fprintf('  df          = %g\n\n', friedman_df);

current_stage = "WILCOXON_ANALYSIS";

%% 7. WILCOXON RANK-SUM ANALYSIS FOR PROPOSED MANUSCRIPT TABLE 14
%
% DFFG-AVOA is always x (sample 1). Each comparator is y (sample 2).
% There are 23 functions x 7 comparators = 161 tests.

reference_idx = 1;
comparator_indices = 2:num_algorithms;
num_comparators = numel(comparator_indices);

wilcoxon_p = nan(num_functions, num_comparators);
wilcoxon_h = nan(num_functions, num_comparators);
wilcoxon_ranksum = nan(num_functions, num_comparators);
wilcoxon_z = nan(num_functions, num_comparators);
wilcoxon_S = strings(num_functions, num_comparators);

x_constant = false(num_functions, num_comparators);
y_constant = false(num_functions, num_comparators);
identical_samples = false(num_functions, num_comparators);
edge_flag = strings(num_functions, num_comparators);

% Full audit vectors, one row for every pairwise test.
num_tests = num_functions * num_comparators;
audit_function = strings(num_tests, 1);
audit_comparator = strings(num_tests, 1);
audit_n_dffg = nan(num_tests, 1);
audit_n_comp = nan(num_tests, 1);
audit_p = nan(num_tests, 1);
audit_h = nan(num_tests, 1);
audit_ranksum = nan(num_tests, 1);
audit_z = nan(num_tests, 1);
audit_S = strings(num_tests, 1);
audit_dffg_median = nan(num_tests, 1);
audit_comp_median = nan(num_tests, 1);
audit_dffg_mean = nan(num_tests, 1);
audit_comp_mean = nan(num_tests, 1);
audit_dffg_std_pop = nan(num_tests, 1);
audit_comp_std_pop = nan(num_tests, 1);
audit_dffg_constant = false(num_tests, 1);
audit_comp_constant = false(num_tests, 1);
audit_identical = false(num_tests, 1);
audit_flag = strings(num_tests, 1);

row = 0;
for f = 1:num_functions
    x = squeeze(raw_cube(f, reference_idx, :));
    x = x(:);

    for c = 1:num_comparators
        a = comparator_indices(c);
        y = squeeze(raw_cube(f, a, :));
        y = y(:);

        row = row + 1;

        assert(numel(x) == expected_num_runs && numel(y) == expected_num_runs, ...
            'Unexpected sample size at %s versus %s.', ...
            expected_functions{f}, expected_algorithms(a));
        assert(all(isfinite(x)) && all(isfinite(y)), ...
            'Non-finite value encountered at %s versus %s.', ...
            expected_functions{f}, expected_algorithms(a));

        x_constant(f, c) = all(x == x(1));
        y_constant(f, c) = all(y == y(1));
        identical_samples(f, c) = isequal(x, y);

        flags = strings(0, 1);
        if x_constant(f, c)
            flags(end + 1) = "DFFG constant"; %#ok<SAGROW>
        end
        if y_constant(f, c)
            flags(end + 1) = "Comparator constant"; %#ok<SAGROW>
        end
        if identical_samples(f, c)
            flags(end + 1) = "Identical samples"; %#ok<SAGROW>
        end

        % Exact-identical samples are a known degenerate edge case.
        % Their empirical distributions are identical, so the neutral
        % rank-sum result is p = 1, H = 0, z = 0. Handling this case
        % explicitly avoids a possible 0/0 normal-approximation variance
        % when every pooled observation is tied. The audit flag preserves
        % complete transparency.
        if identical_samples(f, c)
            pooled_ranks = tiedrank([x; y]);
            p_value = 1;
            h_value = false;
            rank_sum_value = sum(pooled_ranks(1:numel(x)));
            z_value = 0;
            flags(end + 1) = "Identical-sample neutral rank-sum result"; %#ok<SAGROW>
        else
            [p_value, h_value, test_stats] = ranksum( ...
                x, y, ...
                'alpha', alpha, ...
                'tail', 'both', ...
                'method', 'approximate');
            rank_sum_value = test_stats.ranksum;
            z_value = test_stats.zval;
        end

        wilcoxon_p(f, c) = p_value;
        wilcoxon_h(f, c) = double(h_value);
        wilcoxon_ranksum(f, c) = rank_sum_value;
        wilcoxon_z(f, c) = z_value;

        if ~isfinite(p_value) || ~isfinite(rank_sum_value) || ...
                ~isfinite(z_value)
            flags(end + 1) = "Non-finite ranksum output"; %#ok<SAGROW>
        end

        % AOA-style reporting semantics adopted for Table 14:
        % H reports statistical significance, while S independently reports
        % the observed rank direction. DFFG-AVOA is always sample x, so a
        % negative ranksum z-value favours DFFG-AVOA and a positive value
        % favours the comparator. z = 0 is reported as no directional
        % distinction. This permits H = 0 with S = '+' or S = '-'.
        if z_value < 0
            symbol = "+";
        elseif z_value > 0
            symbol = "-";
        else
            symbol = "=";
            if ~identical_samples(f, c)
                flags(end + 1) = "Zero z-direction reported as '='"; %#ok<SAGROW>
            end
        end

        wilcoxon_S(f, c) = symbol;

        if isempty(flags)
            edge_flag(f, c) = "";
        else
            edge_flag(f, c) = strjoin(flags, '; ');
        end

        audit_function(row) = string(expected_functions{f});
        audit_comparator(row) = expected_algorithms(a);
        audit_n_dffg(row) = numel(x);
        audit_n_comp(row) = numel(y);
        audit_p(row) = p_value;
        audit_h(row) = double(h_value);
        audit_ranksum(row) = rank_sum_value;
        audit_z(row) = z_value;
        audit_S(row) = symbol;
        audit_dffg_median(row) = median(x);
        audit_comp_median(row) = median(y);
        audit_dffg_mean(row) = mean(x);
        audit_comp_mean(row) = mean(y);
        audit_dffg_std_pop(row) = sqrt(sum((x - mean(x)).^2) / numel(x));
        audit_comp_std_pop(row) = sqrt(sum((y - mean(y)).^2) / numel(y));
        audit_dffg_constant(row) = x_constant(f, c);
        audit_comp_constant(row) = y_constant(f, c);
        audit_identical(row) = identical_samples(f, c);
        audit_flag(row) = edge_flag(f, c);
    end
end

assert(row == num_tests, 'Wilcoxon test-count audit failed.');
assert(num_tests == 161, 'Expected exactly 161 pairwise Wilcoxon tests.');

% Any undefined result must stop manuscript-table production.
if any(~isfinite(wilcoxon_p), 'all') || ...
        any(~isfinite(wilcoxon_ranksum), 'all') || ...
        any(~isfinite(wilcoxon_z), 'all')
    error(['At least one ranksum result is non-finite. Inspect the audit ' ...
           'flags and raw samples before manuscript reporting.']);
end

current_stage = "STATISTICAL_VALIDATION";

%% 8. W/L/T COUNTS FOR TABLE 14
%
% AOA display order is (W|L|T). These are DIRECTIONAL counts:
%   W = number of '+' symbols; observed rank direction favours DFFG-AVOA
%   L = number of '-' symbols; observed rank direction favours comparator
%   T = number of '=' symbols; no directional distinction
% Statistical significance is reported separately by H and p-value.

wins = sum(wilcoxon_S == "+", 1);
losses = sum(wilcoxon_S == "-", 1);
ties = sum(wilcoxon_S == "=", 1);

assert(all(wins + losses + ties == num_functions), ...
    'W/L/T total must equal 23 for every comparator.');

wlt_summary = strings(1, num_comparators);
for c = 1:num_comparators
    wlt_summary(c) = sprintf('(%d|%d|%d)', wins(c), losses(c), ties(c));
end

% Reporting-rule validation: S must follow z direction independently of H.
expected_S_from_z = strings(size(wilcoxon_S));
expected_S_from_z(wilcoxon_z < 0) = "+";
expected_S_from_z(wilcoxon_z > 0) = "-";
expected_S_from_z(wilcoxon_z == 0) = "=";
assert(isequal(wilcoxon_S, expected_S_from_z), ...
    'S-direction validation failed: S does not match the z-value sign.');

non_sig_plus = sum((wilcoxon_h == 0) & (wilcoxon_S == "+"), 'all');
non_sig_minus = sum((wilcoxon_h == 0) & (wilcoxon_S == "-"), 'all');
non_sig_equal = sum((wilcoxon_h == 0) & (wilcoxon_S == "="), 'all');

% All statistical assertions required for Tables 13 and 14 have passed.
statistical_validation_pass = true;
current_stage = "TABLE_CONSTRUCTION";

%% 9. BUILD AOA-ARCHITECTURE TABLE 14 CELL MATRIX
%
% Row 1: comparator group names
% Row 2: p-value | H | S repeated for each comparator
% Rows 3-25: F1-F23
% Final row: (W|L|T), with the summary placed under the p-value subcolumn
%            of each comparator group, matching the AOA visual pattern.

num_table14_cols = 1 + 3 * num_comparators;
table14 = cell(num_functions + 3, num_table14_cols);

table14{1, 1} = 'F';
table14{2, 1} = '';

for c = 1:num_comparators
    start_col = 2 + (c - 1) * 3;
    table14{1, start_col} = char(expected_algorithms(comparator_indices(c)));
    table14{1, start_col + 1} = '';
    table14{1, start_col + 2} = '';

    table14{2, start_col} = 'p-value';
    table14{2, start_col + 1} = 'H';
    table14{2, start_col + 2} = 'S';
end

for f = 1:num_functions
    out_row = f + 2;
    table14{out_row, 1} = expected_functions{f};

    for c = 1:num_comparators
        start_col = 2 + (c - 1) * 3;
        table14{out_row, start_col} = formatPValue(wilcoxon_p(f, c));
        table14{out_row, start_col + 1} = wilcoxon_h(f, c);
        table14{out_row, start_col + 2} = char(wilcoxon_S(f, c));
    end
end

summary_row = num_functions + 3;
table14{summary_row, 1} = '(W|L|T)';
for c = 1:num_comparators
    start_col = 2 + (c - 1) * 3;
    table14{summary_row, start_col} = char(wlt_summary(c));
    table14{summary_row, start_col + 1} = '';
    table14{summary_row, start_col + 2} = '';
end

%% 10. CREATE FULL AUDIT TABLES

wilcoxon_audit = table( ...
    audit_function, audit_comparator, audit_n_dffg, audit_n_comp, ...
    audit_p, audit_h, audit_ranksum, audit_z, audit_S, ...
    audit_dffg_median, audit_comp_median, ...
    audit_dffg_mean, audit_comp_mean, ...
    audit_dffg_std_pop, audit_comp_std_pop, ...
    audit_dffg_constant, audit_comp_constant, audit_identical, audit_flag, ...
    'VariableNames', { ...
    'Function', 'Comparator', 'N_DFFG', 'N_Comparator', ...
    'PValue', 'H', 'RankSum', 'ZValue', 'S', ...
    'DFFG_Median', 'Comparator_Median', ...
    'DFFG_Mean', 'Comparator_Mean', ...
    'DFFG_StdPopulation', 'Comparator_StdPopulation', ...
    'DFFG_Constant', 'Comparator_Constant', 'IdenticalSamples', 'AuditFlag'});

wlt_table = table( ...
    expected_algorithms(comparator_indices), ...
    wins(:), losses(:), ties(:), wlt_summary(:), ...
    'VariableNames', {'Comparator', 'W', 'L', 'T', 'W_L_T'});

friedman_rank_table = array2table(friedman_function_ranks, ...
    'VariableNames', cellstr(expected_algorithms));
friedman_rank_table = addvars(friedman_rank_table, string(expected_functions), ...
    'Before', 1, 'NewVariableNames', 'Function');

friedman_mean_rank_table = table( ...
    expected_algorithms, friedman_mean_rank(:), friedman_final_ranking(:), ...
    'VariableNames', {'Algorithm', 'MeanRank', 'FinalRanking'});

friedman_input_table = array2table(friedman_input_means, ...
    'VariableNames', cellstr(expected_algorithms));
friedman_input_table = addvars(friedman_input_table, string(expected_functions), ...
    'Before', 1, 'NewVariableNames', 'Function');

%% 11. VALIDATION SUMMARY

validation_item = [ ...
    "Functions are exactly F1-F23"; ...
    "Algorithms are in frozen 8-algorithm order"; ...
    "Each algorithm/function has 30 finite raw observations"; ...
    "Stored means reproduce from raw observations"; ...
    "Stored population standard deviations reproduce"; ...
    "Stored best values reproduce"; ...
    "Friedman input is 23 x 8 function-level mean matrix"; ...
    "Wilcoxon test count is 161"; ...
    "DFFG-AVOA is always ranksum sample x"; ...
    "Wilcoxon tail is two-sided"; ...
    "Wilcoxon method is approximate"; ...
    "Alpha is 0.05"; ...
    "Every comparator W+L+T total is 23"; ...
    "No non-finite Wilcoxon output"; ...
    "S direction is assigned independently from H"; ...
    "S symbols exactly match the sign of ranksum z-values"; ...
    "Execution version is AOA_HS_DIRECTION_FINAL_V4_3_TABLES_10_15_WORD"];

validation_status = repmat("PASS", size(validation_item));
validation_table = table(validation_item, validation_status, ...
    'VariableNames', {'ValidationItem', 'Status'});

edge_case_summary = table( ...
    sum(x_constant, 'all'), ...
    sum(y_constant, 'all'), ...
    sum(identical_samples, 'all'), ...
    sum((x_constant | y_constant), 'all'), ...
    'VariableNames', { ...
    'DFFGConstantComparisons', ...
    'ComparatorConstantComparisons', ...
    'IdenticalSampleComparisons', ...
    'AnyConstantSampleComparisons'});

%% 12. EXPORT EXCEL WORKBOOK

current_stage = "EXCEL_EXPORT";

if exist(output_xlsx, 'file')
    delete(output_xlsx);
end

caption13_text = ...
    'Ranking-based Friedman test for the comparative algorithms using the benchmark functions (F1-F23).';
caption13 = {'Proposed Table 13'; caption13_text};
writecell(caption13, output_xlsx, 'Sheet', 'Table 13', 'Range', 'A1');
writecell(table13, output_xlsx, 'Sheet', 'Table 13', 'Range', 'A4');

caption14_text = ...
    ['Ranking-based Wilcoxon rank-sum test between DFFG-AVOA and the ' ...
     'comparative algorithms using the benchmark functions (F1-F23).'];
caption14 = {'Proposed Table 14'; caption14_text};
writecell(caption14, output_xlsx, 'Sheet', 'Table 14', 'Range', 'A1');
writecell(table14, output_xlsx, 'Sheet', 'Table 14', 'Range', 'A4');

writetable(friedman_summary, output_xlsx, 'Sheet', 'Friedman_Summary');
writetable(friedman_input_table, output_xlsx, 'Sheet', 'Friedman_Input_Means');
writetable(friedman_rank_table, output_xlsx, 'Sheet', 'Friedman_Ranks_Audit');
writetable(friedman_mean_rank_table, output_xlsx, 'Sheet', 'Friedman_Mean_Ranks');
writetable(wilcoxon_audit, output_xlsx, 'Sheet', 'Wilcoxon_Full_Audit');
writetable(wlt_table, output_xlsx, 'Sheet', 'Wilcoxon_WLT');
writetable(edge_case_summary, output_xlsx, 'Sheet', 'Edge_Case_Summary');
writetable(validation_table, output_xlsx, 'Sheet', 'Validation');

% Apply presentation-only formatting to the two manuscript-facing sheets.
% Statistical values are already written and are not recalculated here.
formatManuscriptWorkbook(output_xlsx, num_functions, num_comparators);
excel_export_pass = true;

%% 13. LOAD AND VALIDATE FROZEN MANUSCRIPT-FACING TABLES 10-12 AND 15
current_stage = "MANUSCRIPT_TABLE_AUDIT";

[table10, table11, table12, table15, manuscript_captions] = ...
    getFrozenManuscriptFacingTables();

eng_required_vars = { ...
    'benchmark_functions_names', ...
    'configurations', ...
    'N', ...
    'Max_iter', ...
    'num_runs', ...
    'all_best_designs', ...
    'all_min_results'};
E = load(input_eng_mat, eng_required_vars{:});
for k = 1:numel(eng_required_vars)
    assert(isfield(E, eng_required_vars{k}), ...
        'Required engineering variable "%s" is missing from the MAT file.', ...
        eng_required_vars{k});
end

manuscript_table_validation = validateFrozenManuscriptTables( ...
    table10, table11, table12, table15, S, E, ...
    expected_algorithms, expected_num_runs, expected_N, expected_Max_iter);
manuscript_table_validation_pass = true;

fprintf('Manuscript-facing Tables 10-12 validation: PASS\n');
fprintf('  Mathematical display cells checked: %d\n', ...
    manuscript_table_validation.MathDisplayCellsChecked);
fprintf('  Practical-zero display exceptions retained: %d\n', ...
    manuscript_table_validation.MathUnderflowDisplayZeroExceptions);
fprintf('Engineering Table 15 value/presentation validation: PASS\n');
fprintf('  Engineering objective values checked: %d\n', ...
    manuscript_table_validation.EngineeringObjectivesChecked);
fprintf('  Engineering design scalars checked: %d\n', ...
    manuscript_table_validation.EngineeringDesignScalarsChecked);
fprintf('Frozen display strings preserved: PASS\n');

%% 14. SAVE MACHINE-READABLE RESULTS MAT FILE

current_stage = "MAT_SAVE";

save(output_mat, ...
    'analysis_version', ...
    'input_mat', ...
    'alpha', ...
    'expected_algorithms', ...
    'expected_functions', ...
    'recomputed_mean', ...
    'recomputed_std_population', ...
    'recomputed_best', ...
    'friedman_input_means', ...
    'friedman_function_ranks', ...
    'friedman_mean_rank', ...
    'friedman_final_ranking', ...
    'friedman_p', ...
    'friedman_h', ...
    'friedman_chi_square', ...
    'friedman_df', ...
    'friedman_anova_table', ...
    'friedman_stats', ...
    'wilcoxon_p', ...
    'wilcoxon_h', ...
    'wilcoxon_ranksum', ...
    'wilcoxon_z', ...
    'wilcoxon_S', ...
    'wins', ...
    'losses', ...
    'ties', ...
    'wlt_summary', ...
    'non_sig_plus', ...
    'non_sig_minus', ...
    'non_sig_equal', ...
    'x_constant', ...
    'y_constant', ...
    'identical_samples', ...
    'edge_flag', ...
    'wilcoxon_audit', ...
    'validation_table', ...
    'statistical_validation_pass', ...
    'excel_export_pass', ...
    'mat_save_pass', ...
    'word_export_pass', ...
    'input_eng_mat', ...
    'table10', 'table11', 'table12', 'table15', ...
    'manuscript_captions', 'manuscript_table_validation', ...
    'manuscript_table_validation_pass', ...
    'output_tables_10_15_docx');

mat_save_pass = true;

% Refresh status variables in the already-created Results MAT.
save(output_mat, ...
    'statistical_validation_pass', 'excel_export_pass', ...
    'mat_save_pass', 'manuscript_table_validation_pass', ...
    'word_export_pass', '-append');

%% 15. CREATE NATIVE WORD TABLES 10-15
%
% This stage does not recalculate any statistic. It consumes the frozen
% manuscript-facing Tables 10-12 and 15 plus the validated Table 13/14
% matrices. All six are created directly as native Word tables.

current_stage = "WORD_EXPORT";
fprintf('\nWORD TABLE GENERATION\n');

word_validation = generateNativeWordTables10to15( ...
    output_tables_10_15_docx, ...
    table10, table11, table12, table13, table14, table15, ...
    manuscript_captions, caption13_text, caption14_text, ...
    num_functions, num_algorithms, num_comparators, ...
    expected_algorithms, comparator_indices);

word_export_pass = true;

% Append Word-export provenance/validation to the Results MAT.
save(output_mat, ...
    'analysis_version', 'word_export_pass', 'word_validation', ...
    'manuscript_table_validation', 'manuscript_table_validation_pass', ...
    'output_tables_10_15_docx', '-append');

fprintf('Table 10 created: PASS\n');
fprintf('Table 11 created: PASS\n');
fprintf('Table 12 created: PASS\n');
fprintf('Table 13 created: PASS\n');
fprintf('Table 14 created: PASS\n');
fprintf('Table 15 created: PASS\n');
fprintf('Word document saved: PASS\n');

%% 16. FINAL CONSOLE REPORT

fprintf('======================================================================\n');
fprintf('ANALYSIS COMPLETE\n');
fprintf('VERSION: %s\n', analysis_version);
fprintf('======================================================================\n');
fprintf('Friedman p-value: %.16g\n', friedman_p);
fprintf('Friedman chi-square: %.16g, df = %g\n\n', ...
    friedman_chi_square, friedman_df);

fprintf('Friedman mean ranks / final rankings:\n');
for a = 1:num_algorithms
    fprintf('  %-10s  Mean Rank = %8.4f   Final Rank = %g\n', ...
        expected_algorithms(a), friedman_mean_rank(a), friedman_final_ranking(a));
end

fprintf('\nWilcoxon comparisons: %d = %d functions x %d comparators.\n', ...
    num_tests, num_functions, num_comparators);
fprintf('Directional DFFG-AVOA (W|L|T), counted from S symbols:\n');
for c = 1:num_comparators
    fprintf('  %-10s  %s\n', ...
        expected_algorithms(comparator_indices(c)), wlt_summary(c));
end

fprintf('\nNon-significant directional cases retained in S:\n');
fprintf('  H=0, S=+ : %d\n', non_sig_plus);
fprintf('  H=0, S=- : %d\n', non_sig_minus);
fprintf('  H=0, S== : %d\n', non_sig_equal);
fprintf('Direction-rule validation: PASS\n');

fprintf('\nEdge-case audit:\n');
fprintf('  Comparisons with constant DFFG sample : %d\n', sum(x_constant, 'all'));
fprintf('  Comparisons with constant comparator  : %d\n', sum(y_constant, 'all'));
fprintf('  Comparisons with identical samples    : %d\n', sum(identical_samples, 'all'));

fprintf('\nFiles written:\n');
fprintf('  %s\n', output_xlsx);
fprintf('  %s\n', output_mat);
fprintf('  %s\n', output_log);
fprintf('  %s\n', output_tables_10_15_docx);
fprintf('\nThe Word file contains native manuscript-transfer tables 10 through 15.\n');

current_stage = "COMPLETE";

fprintf('\nSTATISTICAL VALIDATION: PASS\n');
fprintf('EXCEL EXPORT: PASS\n');
fprintf('MAT RESULTS SAVE: PASS\n');
fprintf('MANUSCRIPT TABLE VALIDATION: PASS\n');
fprintf('WORD TABLE 10: PASS\n');
fprintf('WORD TABLE 11: PASS\n');
fprintf('WORD TABLE 12: PASS\n');
fprintf('WORD TABLE 13: PASS\n');
fprintf('WORD TABLE 14: PASS\n');
fprintf('WORD TABLE 15: PASS\n');
fprintf('WORD DOCUMENT SAVE: PASS\n');
fprintf('RUN COMPLETED SUCCESSFULLY\n');
fprintf('END TIME: %s\n', datestr(now, 31));

% Explicitly flush/close the diary on successful completion.
diary off;
clear diary_cleanup;

catch ME
    % The catch block is intentionally simple and robust. It records the
    % MATLAB error in human-readable form and saves a structured emergency
    % MAT file without altering the original benchmark data.
    fprintf('\n============================================================\n');
    fprintf('RUN FAILED\n');
    fprintf('VERSION: %s\n', analysis_version);
    fprintf('FAILED STAGE: %s\n', current_stage);
    fprintf('STATISTICAL VALIDATION PASS: %d\n', statistical_validation_pass);
    fprintf('EXCEL EXPORT PASS: %d\n', excel_export_pass);
    fprintf('MAT RESULTS SAVE PASS: %d\n', mat_save_pass);
    fprintf('MANUSCRIPT TABLE VALIDATION PASS: %d\n', manuscript_table_validation_pass);
    fprintf('WORD EXPORT PASS: %d\n', word_export_pass);
    fprintf('TIME: %s\n', datestr(now, 31));
    fprintf('ERROR IDENTIFIER: %s\n', ME.identifier);
    fprintf('ERROR MESSAGE: %s\n', ME.message);
    fprintf('------------------------------------------------------------\n');
    for kk = 1:numel(ME.stack)
        fprintf('STACK %d: %s | line %d | %s\n', ...
            kk, ME.stack(kk).file, ME.stack(kk).line, ME.stack(kk).name);
    end
    fprintf('============================================================\n');

    error_identifier = ME.identifier;
    error_message = ME.message;
    error_stack = ME.stack;
    error_time = datestr(now, 31);

    try
        save(output_error_mat, ...
            'analysis_version', 'script_full_path', 'current_stage', ...
            'statistical_validation_pass', 'excel_export_pass', ...
            'mat_save_pass', 'manuscript_table_validation_pass', ...
            'word_export_pass', ...
            'output_xlsx', 'output_mat', 'output_log', ...
            'input_eng_mat', 'output_tables_10_15_docx', ...
            'error_identifier', 'error_message', 'error_stack', 'error_time');
        fprintf('Emergency error MAT written: %s\n', output_error_mat);
    catch saveME
        fprintf('WARNING: Could not write emergency error MAT: %s\n', saveME.message);
    end

    diary off;
    clear diary_cleanup;
    rethrow(ME);
end

%% LOCAL FUNCTIONS



function validation = generateNativeWordTables10to15( ...
        output_docx, table10, table11, table12, table13, table14, table15, ...
        manuscript_captions, caption13_text, caption14_text, ...
        num_functions, num_algorithms, num_comparators, ...
        expected_algorithms, comparator_indices)
% Create manuscript Tables 10-15 directly as six native Microsoft Word
% tables. No Excel range is copied or pasted.
%
% Tables 10-12 and 15 use frozen manuscript-facing display strings.
% Tables 13-14 use the already-validated statistical matrices.

    if ~ispc
        error(['Native Word-table generation requires Windows and Microsoft ' ...
               'Word COM automation.']);
    end

    assert(isequal(size(table10), [29, 10]), 'Table 10 must be 29 x 10.');
    assert(isequal(size(table11), [25, 10]), 'Table 11 must be 25 x 10.');
    assert(isequal(size(table12), [41, 10]), 'Table 12 must be 41 x 10.');
    assert(isequal(size(table13), [num_functions + 3, num_algorithms + 1]), ...
        'Table 13 dimensions are invalid.');
    assert(isequal(size(table14), [num_functions + 3, 1 + 3*num_comparators]), ...
        'Table 14 dimensions are invalid.');
    assert(isequal(size(table15), [18, 10]), 'Table 15 must be 18 x 10.');

    if exist(output_docx, 'file') == 2
        delete(output_docx);
    end

    word = [];
    doc = [];
    current_word_substage = "WORD_INITIALISATION";

    % Word constants.
    wdAlignParagraphCenter = 1;
    wdCellAlignVerticalCenter = 1;
    wdAutoFitFixed = 0;
    wdAdjustNone = 0;
    wdPageBreak = 7;
    wdPaperA4 = 7;
    wdOrientPortrait = 0;
    wdFormatDocumentDefault = 16;
    points_per_cm = 28.3464567;

    try
        word = actxserver('Word.Application');
        word.Visible = false;
        word.DisplayAlerts = 0;
        doc = word.Documents.Add;

        doc.PageSetup.PaperSize = wdPaperA4;
        doc.PageSetup.Orientation = wdOrientPortrait;
        margin_points = 1.0 * points_per_cm;
        doc.PageSetup.TopMargin = margin_points;
        doc.PageSetup.BottomMargin = margin_points;
        doc.PageSetup.LeftMargin = margin_points;
        doc.PageSetup.RightMargin = margin_points;

        selection = word.Selection;

        %% Tables 10-12: descriptive mathematical benchmark tables
        descriptive_tables = {table10, table11, table12};
        descriptive_numbers = [10, 11, 12];
        descriptive_captions = { ...
            manuscript_captions.Table10, ...
            manuscript_captions.Table11, ...
            manuscript_captions.Table12};
        descriptive_functions = [7, 6, 10];

        for kk = 1:3
            table_number = descriptive_numbers(kk);
            current_word_substage = sprintf('TABLE%d_CREATION', table_number);
            fprintf('  Word Table %d creation...\n', table_number);

            if kk > 1
                selection.InsertBreak(wdPageBreak);
            end

            addWordCaption(selection, table_number, descriptive_captions{kk});
            w = doc.Tables.Add(selection.Range, ...
                size(descriptive_tables{kk},1), size(descriptive_tables{kk},2));

            populateWordTable(w, descriptive_tables{kk});
            formatCommonWordTable(w, 8, wdAlignParagraphCenter, ...
                wdCellAlignVerticalCenter, wdAutoFitFixed);

            % Fixed width = 19.00 cm total on A4 portrait with 1 cm margins.
            w.Columns.Item(1).SetWidth(3.40 * points_per_cm, wdAdjustNone);
            w.Columns.Item(2).SetWidth(1.20 * points_per_cm, wdAdjustNone);
            for c = 3:10
                w.Columns.Item(c).SetWidth(1.80 * points_per_cm, wdAdjustNone);
            end
            w.AllowAutoFit = 0;
            w.AutoFitBehavior(wdAutoFitFixed);

            w.Rows.Item(1).Range.Font.Bold = true;
            w.Rows.Item(1).HeadingFormat = -1;
            w.Rows.AllowBreakAcrossPages = 0;

            % Vertically merge each benchmark-name block over Mean/Std/Best/Rank.
            current_word_substage = sprintf('TABLE%d_FUNCTION_MERGE', table_number);
            nfun = descriptive_functions(kk);
            for j = nfun:-1:1
                start_row = 2 + (j-1)*4;
                label = char(string(descriptive_tables{kk}{start_row,1}));
                top_cell = w.Cell(start_row, 1);
                bottom_cell = w.Cell(start_row+3, 1);
                top_cell.Merge(bottom_cell);
                top_cell.Range.Text = label;
                top_cell.Range.ParagraphFormat.Alignment = wdAlignParagraphCenter;
                top_cell.VerticalAlignment = wdCellAlignVerticalCenter;
            end
            w.AllowAutoFit = 0;
            w.AutoFitBehavior(wdAutoFitFixed);

            fprintf('  Word Table %d formatting: PASS\n', table_number);
            selection.SetRange(w.Range.End, w.Range.End);
            selection.TypeParagraph;
        end

        %% Table 13: Friedman
        current_word_substage = "TABLE13_CREATION";
        selection.InsertBreak(wdPageBreak);
        addWordCaption(selection, 13, caption13_text);
        w13 = doc.Tables.Add(selection.Range, size(table13,1), size(table13,2));
        populateWordTable(w13, table13);
        formatCommonWordTable(w13, 8, wdAlignParagraphCenter, ...
            wdCellAlignVerticalCenter, wdAutoFitFixed);
        w13.Columns.Item(1).SetWidth(1.20 * points_per_cm, wdAdjustNone);
        for c = 2:9
            w13.Columns.Item(c).SetWidth(2.225 * points_per_cm, wdAdjustNone);
        end
        w13.AllowAutoFit = 0;
        w13.AutoFitBehavior(wdAutoFitFixed);
        w13.Rows.Item(1).Range.Font.Bold = true;
        w13.Rows.Item(size(table13,1)-1).Range.Font.Bold = true;
        w13.Rows.Item(size(table13,1)).Range.Font.Bold = true;
        w13.Rows.Item(1).HeadingFormat = -1;
        w13.Rows.AllowBreakAcrossPages = 0;
        fprintf('  Word Table 13 formatting: PASS\n');
        selection.SetRange(w13.Range.End, w13.Range.End);
        selection.TypeParagraph;

        %% Table 14: Wilcoxon - retain the proven V4.2 fixed-width layout
        current_word_substage = "TABLE14_CREATION";
        selection.InsertBreak(wdPageBreak);
        addWordCaption(selection, 14, caption14_text);
        w14 = doc.Tables.Add(selection.Range, size(table14,1), size(table14,2));
        populateWordTable(w14, table14);
        formatCommonWordTable(w14, 7, wdAlignParagraphCenter, ...
            wdCellAlignVerticalCenter, wdAutoFitFixed);

        pvalue_insert_count = 0;
        for f = 1:num_functions
            row_index = f + 2;
            for comp = 1:num_comparators
                start_col = 2 + (comp - 1) * 3;
                ptxt = char(string(table14{row_index, start_col}));
                assert(~isempty(regexp(ptxt, '^\d\.\d{3}E[+-]\d{2,3}$', 'once')), ...
                    'Unexpected Table 14 p-value display at function %d comparator %d: %s', ...
                    f, comp, ptxt);
                pvalue_insert_count = pvalue_insert_count + 1;
            end
        end
        assert(pvalue_insert_count == num_functions*num_comparators, ...
            'Table 14 must contain %d p-values.', num_functions*num_comparators);

        wlt_insert_count = 0;
        summary_row = size(table14,1);
        for comp = 1:num_comparators
            start_col = 2 + (comp - 1) * 3;
            wtxt = char(string(table14{summary_row, start_col}));
            assert(~isempty(regexp(wtxt, '^\(\d+\|\d+\|\d+\)$', 'once')), ...
                'Unexpected Table 14 W/L/T display for comparator %d: %s', comp, wtxt);
            wlt_insert_count = wlt_insert_count + 1;
        end

        f_width_cm = 1.30;
        p_width_cm = 1.55;
        h_width_cm = 0.45;
        s_width_cm = 0.45;
        table14_total_width_cm = ...
            f_width_cm + num_comparators*(p_width_cm+h_width_cm+s_width_cm);
        assert(table14_total_width_cm <= 19.0, ...
            'Configured Table 14 width exceeds usable A4 portrait width.');

        w14.Columns.Item(1).SetWidth(f_width_cm * points_per_cm, wdAdjustNone);
        for comp = 1:num_comparators
            start_col = 2 + (comp - 1) * 3;
            w14.Columns.Item(start_col).SetWidth(p_width_cm*points_per_cm, wdAdjustNone);
            w14.Columns.Item(start_col+1).SetWidth(h_width_cm*points_per_cm, wdAdjustNone);
            w14.Columns.Item(start_col+2).SetWidth(s_width_cm*points_per_cm, wdAdjustNone);
        end
        w14.AllowAutoFit = 0;
        w14.AutoFitBehavior(wdAutoFitFixed);
        w14.Rows.Item(1).Range.Font.Bold = true;
        w14.Rows.Item(2).Range.Font.Bold = true;
        w14.Rows.Item(summary_row).Range.Font.Bold = true;
        w14.Rows.Item(1).HeadingFormat = -1;
        w14.Rows.Item(2).HeadingFormat = -1;
        w14.Rows.AllowBreakAcrossPages = 0;

        current_word_substage = "TABLE14_HEADER_MERGE";
        header_row = w14.Rows.Item(1);
        for comp = num_comparators:-1:1
            start_index = 2 + (comp - 1) * 3;
            first_cell = header_row.Cells.Item(start_index);
            last_cell = header_row.Cells.Item(start_index + 2);
            first_cell.Merge(last_cell);
            first_cell.Range.Text = char(expected_algorithms(comparator_indices(comp)));
            first_cell.Range.Font.Bold = true;
            first_cell.Range.ParagraphFormat.Alignment = wdAlignParagraphCenter;
            first_cell.VerticalAlignment = wdCellAlignVerticalCenter;
        end
        first_header_cell = w14.Rows.Item(1).Cells.Item(1);
        second_header_cell = w14.Rows.Item(2).Cells.Item(1);
        first_header_cell.Merge(second_header_cell);
        first_header_cell.Range.Text = 'F';
        first_header_cell.Range.Font.Bold = true;
        first_header_cell.Range.ParagraphFormat.Alignment = wdAlignParagraphCenter;
        first_header_cell.VerticalAlignment = wdCellAlignVerticalCenter;
        w14.AllowAutoFit = 0;
        w14.AutoFitBehavior(wdAutoFitFixed);
        fprintf('  Word Table 14 formatting: PASS\n');
        selection.SetRange(w14.Range.End, w14.Range.End);
        selection.TypeParagraph;

        %% Table 15: engineering best feasible solutions
        % V4.4 presents each design variable on its own row so that the reader
        % can compare the same variable directly across all eight algorithms.
        current_word_substage = "TABLE15_CREATION";
        selection.InsertBreak(wdPageBreak);
        addWordCaption(selection, 15, manuscript_captions.Table15);
        w15 = doc.Tables.Add(selection.Range, size(table15,1), size(table15,2));
        populateWordTable(w15, table15);
        formatCommonWordTable(w15, 8, wdAlignParagraphCenter, ...
            wdCellAlignVerticalCenter, wdAutoFitFixed);

        % A4 portrait fixed widths: 18.60 cm total within 19.00 cm usable width.
        w15.Columns.Item(1).SetWidth(2.50 * points_per_cm, wdAdjustNone);
        w15.Columns.Item(2).SetWidth(1.30 * points_per_cm, wdAdjustNone);
        for c = 3:10
            w15.Columns.Item(c).SetWidth(1.85 * points_per_cm, wdAdjustNone);
        end
        w15.AllowAutoFit = 0;
        w15.AutoFitBehavior(wdAutoFitFixed);
        w15.Rows.Item(1).Range.Font.Bold = true;
        w15.Rows.Item(1).HeadingFormat = -1;
        w15.Rows.AllowBreakAcrossPages = 0;

        % IMPORTANT WORD-COM ORDER (V4.4.1):
        % Perform every operation that addresses Rows.Item(...) BEFORE vertical
        % merges. Microsoft Word does not permit individual-row access through
        % the Rows collection once a table contains vertically merged cells.

        % Apply mathematical styling to the Variable column: italic variable
        % symbols, subscripted indices, and x_best notation in objective rows.
        current_word_substage = "TABLE15_VARIABLE_LABEL_FORMATTING";
        formatEngineeringVariableLabels(w15);

        % Give the three objective rows a light structural emphasis through bold
        % text only; no colour/highlighting is introduced. This MUST precede
        % vertical merging of the Problem column.
        current_word_substage = "TABLE15_OBJECTIVE_ROW_FORMATTING";
        for r = [9, 12, 18]
            w15.Rows.Item(r).Range.Font.Bold = true;
        end

        % Merge each problem name across all of its design-variable and
        % objective rows. Merge from bottom to top to keep Word cell addressing
        % stable. No Rows.Item(...) calls are made after this point.
        current_word_substage = "TABLE15_PROBLEM_CELL_MERGING";
        table15_problem_blocks = [13 18; 10 12; 2 9]; % bottom-to-top
        for j = 1:size(table15_problem_blocks,1)
            start_row = table15_problem_blocks(j,1);
            end_row = table15_problem_blocks(j,2);
            label = char(string(table15{start_row,1}));
            top_cell = w15.Cell(start_row,1);
            bottom_cell = w15.Cell(end_row,1);
            top_cell.Merge(bottom_cell);
            top_cell.Range.Text = label;
            top_cell.Range.ParagraphFormat.Alignment = wdAlignParagraphCenter;
            top_cell.VerticalAlignment = wdCellAlignVerticalCenter;
        end

        w15.AllowAutoFit = 0;
        w15.AutoFitBehavior(wdAutoFitFixed);
        fprintf('  Word Table 15 variable-row formatting: PASS\n');

        assert(doc.Tables.Count == 6, 'Expected exactly six native Word tables.');

        current_word_substage = "DOCX_SAVE";
        try
            doc.SaveAs2(output_docx, wdFormatDocumentDefault);
        catch
            doc.SaveAs(output_docx, wdFormatDocumentDefault);
        end
        doc.Close(false);
        word.Quit;
        delete(word);
        word = [];
        doc = [];

    catch ME
        fprintf('  WORD SUBSTAGE FAILED: %s\n', current_word_substage);
        try
            if ~isempty(doc), doc.Close(false); end
        catch
        end
        try
            if ~isempty(word), word.Quit; delete(word); end
        catch
        end
        rethrow(ME);
    end

    assert(exist(output_docx, 'file') == 2, ...
        'Word document was not created: %s', output_docx);
    info = dir(output_docx);
    assert(~isempty(info) && info.bytes > 0, ...
        'Word document exists but is empty: %s', output_docx);

    validation = struct();
    validation.OutputFile = output_docx;
    validation.FileBytes = info.bytes;
    validation.TableCount = 6;
    validation.Table10Rows = 29;
    validation.Table11Rows = 25;
    validation.Table12Rows = 41;
    validation.Table13Rows = size(table13,1);
    validation.Table14RowsBeforeMerge = size(table14,1);
    validation.Table14PValuesInserted = pvalue_insert_count;
    validation.Table14WLTInserted = wlt_insert_count;
    validation.Table15Rows = 18;
    validation.A4Portrait = true;
    validation.NativeWordTables = true;
    validation.FixedWidths = true;
    validation.Table14TotalWidthCm = table14_total_width_cm;
end

function addWordCaption(selection, table_number, caption_text)
    selection.Font.Name = 'Times New Roman';
    selection.Font.Size = 10;
    selection.Font.Bold = true;
    selection.TypeText(sprintf('Table %d. %s', table_number, caption_text));
    selection.TypeParagraph;
    selection.Font.Bold = false;
end

function populateWordTable(word_table, cell_matrix)
    for r = 1:size(cell_matrix,1)
        for c = 1:size(cell_matrix,2)
            setWordCellText(word_table.Cell(r,c), cell_matrix{r,c});
        end
    end
end

function formatCommonWordTable(word_table, font_size, align_center, ...
        vertical_center, wdAutoFitFixed)
    word_table.Borders.Enable = 1;
    word_table.Rows.Alignment = align_center;
    word_table.Range.Font.Name = 'Times New Roman';
    word_table.Range.Font.Size = font_size;
    word_table.Range.ParagraphFormat.Alignment = align_center;
    word_table.Range.ParagraphFormat.SpaceBefore = 0;
    word_table.Range.ParagraphFormat.SpaceAfter = 0;
    word_table.Range.Cells.VerticalAlignment = vertical_center;
    word_table.TopPadding = 0;
    word_table.BottomPadding = 0;
    word_table.LeftPadding = 0.5;
    word_table.RightPadding = 0.5;
    word_table.AllowAutoFit = 0;
    word_table.AutoFitBehavior(wdAutoFitFixed);
end


function [table10, table11, table12, table15, captions] = getFrozenManuscriptFacingTables()
% Return the exact manuscript-facing content for Tables 10-12 and the
% engineering table that becomes Table 15 in V4.4.
%
% IMPORTANT: these are display strings, not recalculated values. V4.4
% validates them against the authoritative raw MAT files but does not
% silently replace the manuscript-facing precision or wording.

    table10 = { ...
        'Functions', 'Metric', 'DFFG-AVOA', 'AVOA', 'IROAVOA', 'GWO', 'AOA', 'FPA', 'MFO', 'SCA'; ...
        'F1  (Sphere)', 'Mean', '0.00E+00', '2.68E-258', '1.13E-307', '4.64E-31', '2.61E-15', '2.00E+03', '3.02E+03', '1.03E+01'; ...
        'F1  (Sphere)', 'Std', '0.00E+00', '0.00E+00', '0.00E+00', '5.26E-31', '1.41E-14', '5.13E+02', '5.26E+03', '1.79E+01'; ...
        'F1  (Sphere)', 'Best', '0.00E+00', '0.00E+00', '0.00E+00', '1.84E-32', '5.49E-141', '1.02E+03', '6.86E-01', '1.85E-01'; ...
        'F1  (Sphere)', 'Rank', '1', '3', '2', '4', '5', '7', '8', '6'; ...
        'F2  (Schwefel 2.22)', 'Mean', '1.89E-149', '4.90E-134', '1.72E-150', '1.24E-18', '0.00E+00', '3.10E+01', '3.51E+01', '2.28E-02'; ...
        'F2  (Schwefel 2.22)', 'Std', '1.02E-148', '2.28E-133', '9.28E-150', '1.15E-18', '0.00E+00', '5.00E+00', '2.18E+01', '3.70E-02'; ...
        'F2  (Schwefel 2.22)', 'Best', '3.05E-223', '2.25E-196', '1.03E-255', '1.81E-19', '0.00E+00', '2.26E+01', '2.13E-01', '4.69E-05'; ...
        'F2  (Schwefel 2.22)', 'Rank', '3', '4', '2', '5', '1', '7', '8', '6'; ...
        'F3  (Schwefel 1.2)', 'Mean', '5.38E-288', '3.45E-224', '4.11E-230', '2.45E-04', '5.61E-03', '1.45E+03', '2.02E+04', '8.74E+03'; ...
        'F3  (Schwefel 1.2)', 'Std', '0.00E+00', '0.00E+00', '0.00E+00', '5.40E-04', '8.91E-03', '3.91E+02', '1.32E+04', '5.93E+03'; ...
        'F3  (Schwefel 1.2)', 'Best', '0.00E+00', '0.00E+00', '0.00E+00', '4.48E-07', '1.69E-156', '7.43E+02', '4.46E+03', '1.09E+03'; ...
        'F3  (Schwefel 1.2)', 'Rank', '1', '3', '2', '4', '5', '6', '8', '7'; ...
        'F4  (Schwefel 2.21)', 'Mean', '9.38E-165', '1.31E-141', '5.72E-145', '3.25E-06', '2.53E-02', '2.40E+01', '6.81E+01', '3.29E+01'; ...
        'F4  (Schwefel 2.21)', 'Std', '0.00E+00', '5.79E-141', '3.07E-144', '3.47E-06', '1.96E-02', '3.77E+00', '9.26E+00', '1.09E+01'; ...
        'F4  (Schwefel 2.21)', 'Best', '1.39E-223', '3.60E-208', '2.01E-282', '2.39E-07', '5.51E-51', '1.73E+01', '4.64E+01', '1.12E+01'; ...
        'F4  (Schwefel 2.21)', 'Rank', '1', '3', '2', '4', '5', '6', '8', '7'; ...
        'F5  (Rosenbrock)', 'Mean', '2.19E+01', '2.40E+01', '2.30E+01', '2.70E+01', '2.84E+01', '3.08E+05', '8.03E+06', '8.31E+04'; ...
        'F5  (Rosenbrock)', 'Std', '1.20E+01', '9.50E+00', '1.01E+01', '7.20E-01', '2.91E-01', '1.42E+05', '2.40E+07', '2.69E+05'; ...
        'F5  (Rosenbrock)', 'Best', '1.87E-02', '1.38E+00', '1.93E-01', '2.56E+01', '2.76E+01', '7.48E+04', '5.23E+02', '4.52E+01'; ...
        'F5  (Rosenbrock)', 'Rank', '1', '3', '2', '4', '5', '7', '8', '6'; ...
        'F6  (Step)', 'Mean', '0.00E+00', '0.00E+00', '0.00E+00', '0.00E+00', '0.00E+00', '1.86E+03', '3.73E+03', '1.34E+01'; ...
        'F6  (Step)', 'Std', '0.00E+00', '0.00E+00', '0.00E+00', '0.00E+00', '0.00E+00', '4.20E+02', '5.45E+03', '3.28E+01'; ...
        'F6  (Step)', 'Best', '0.00E+00', '0.00E+00', '0.00E+00', '0.00E+00', '0.00E+00', '1.15E+03', '3.00E+00', '0.00E+00'; ...
        'F6  (Step)', 'Rank', '1', '1', '1', '1', '1', '7', '8', '6'; ...
        'F7  (Quartic with noise)', 'Mean', '1.37E-04', '1.14E-04', '1.65E-04', '2.26E-03', '6.40E-05', '2.59E-01', '3.65E+00', '1.67E-01'; ...
        'F7  (Quartic with noise)', 'Std', '1.12E-04', '9.51E-05', '2.43E-04', '9.60E-04', '6.44E-05', '1.03E-01', '9.22E+00', '2.29E-01'; ...
        'F7  (Quartic with noise)', 'Best', '3.31E-06', '1.16E-05', '4.85E-06', '5.95E-04', '6.48E-07', '6.48E-02', '1.16E-01', '1.33E-02'; ...
        'F7  (Quartic with noise)', 'Rank', '3', '2', '4', '5', '1', '7', '8', '6'};

    table11 = { ...
        'No.', 'Metric', 'DFFG-AVOA', 'AVOA', 'IROAVOA', 'GWO', 'AOA', 'FPA', 'MFO', 'SCA'; ...
        'F8 (Schwefel 2.26)', 'Mean', '-1.24E+04', '-1.16E+04', '-7.38E+03', '-5.88E+03', '-5.30E+03', '-6.41E+03', '-8.61E+03', '-3.66E+03'; ...
        '', 'Std', '4.05E+02', '9.87E+02', '2.26E+03', '1.22E+03', '3.21E+02', '1.87E+02', '6.61E+02', '2.40E+02'; ...
        '', 'Best', '-1.26E+04', '-1.26E+04', '-1.20E+04', '-7.63E+03', '-6.09E+03', '-6.93E+03', '-9.59E+03', '-4.21E+03'; ...
        '', 'Rank', '1', '2', '4', '6', '7', '5', '3', '8'; ...
        'F9 (Rastrigin)', 'Mean', '0.00E+00', '0.00E+00', '0.00E+00', '8.03E+00', '0.00E+00', '1.82E+02', '1.62E+02', '3.76E+01'; ...
        'F9 (Rastrigin)', 'Std', '0.00E+00', '0.00E+00', '0.00E+00', '6.33E+00', '0.00E+00', '1.61E+01', '3.93E+01', '3.16E+01'; ...
        'F9 (Rastrigin)', 'Best', '0.00E+00', '0.00E+00', '0.00E+00', '2.66E-14', '0.00E+00', '1.53E+02', '9.65E+01', '4.15E+00'; ...
        'F9 (Rastrigin)', 'Rank', '1', '1', '1', '5', '1', '8', '7', '6'; ...
        'F10 (Ackley)', 'Mean', '4.44E-16', '4.44E-16', '4.44E-16', '6.68E-14', '4.44E-16', '7.79E+00', '1.73E+01', '1.41E+01'; ...
        'F10 (Ackley)', 'Std', '0.00E+00', '0.00E+00', '0.00E+00', '6.76E-15', '0.00E+00', '1.17E+00', '5.15E+00', '8.57E+00'; ...
        'F10 (Ackley)', 'Best', '4.44E-16', '4.44E-16', '4.44E-16', '5.02E-14', '4.44E-16', '4.87E+00', '1.85E+00', '1.25E-02'; ...
        'F10 (Ackley)', 'Rank', '1', '1', '1', '5', '1', '6', '8', '7'; ...
        'F11 (Griewank)', 'Mean', '0.00E+00', '0.00E+00', '0.00E+00', '3.01E-03', '2.19E-01', '1.78E+01', '2.50E+01', '1.18E+00'; ...
        'F11 (Griewank)', 'Std', '0.00E+00', '0.00E+00', '0.00E+00', '6.80E-03', '1.60E-01', '3.76E+00', '5.15E+01', '1.12E+00'; ...
        'F11 (Griewank)', 'Best', '0.00E+00', '0.00E+00', '0.00E+00', '0.00E+00', '1.01E-02', '1.15E+01', '6.09E-01', '2.93E-01'; ...
        'F11 (Griewank)', 'Rank', '1', '1', '1', '4', '5', '7', '8', '6'; ...
        'F12 ( Penalised 1 )', 'Mean', '2.02E-06', '8.34E-04', '1.22E-03', '4.82E-02', '5.11E-01', '5.40E+01', '5.09E+01', '9.11E+04'; ...
        'F12 ( Penalised 1 )', 'Std', '7.97E-07', '6.38E-04', '1.94E-03', '2.91E-02', '3.76E-02', '7.47E+01', '1.53E+02', '3.22E+05'; ...
        'F12 ( Penalised 1 )', 'Best', '4.01E-07', '3.42E-04', '2.61E-05', '1.38E-02', '4.25E-01', '1.13E+01', '1.69E+00', '5.24E-01'; ...
        'F12 ( Penalised 1 )', 'Rank', '1', '2', '3', '4', '5', '7', '6', '8'; ...
        'F13 ( Penalised 2 )', 'Mean', '1.86E-03', '7.43E-02', '3.57E-02', '6.02E-01', '2.81E+00', '6.50E+04', '1.37E+07', '3.88E+04'; ...
        'F13 ( Penalised 2 )', 'Std', '4.10E-03', '4.02E-02', '3.89E-02', '2.43E-01', '1.24E-01', '9.68E+04', '7.36E+07', '7.66E+04'; ...
        'F13 ( Penalised 2 )', 'Best', '7.97E-06', '7.93E-03', '3.46E-04', '1.89E-01', '2.45E+00', '1.93E+02', '8.27E+00', '3.32E+00'; ...
        'F13 ( Penalised 2 )', 'Rank', '1', '3', '2', '4', '5', '7', '8', '6'};

    table12 = { ...
        'No.', 'Metric', 'DFFG-AVOA', 'AVOA', 'IROAVOA', 'GWO', 'AOA', 'FPA', 'MFO', 'SCA'; ...
        'F14 (Foxholes)', 'Mean', '1.33E+00', '2.40E+00', '1.30E+00', '5.17E+00', '1.05E+01', '1.00E+00', '3.16E+00', '1.99E+00'; ...
        'F14 (Foxholes)', 'Std', '5.93E-01', '2.98E+00', '5.21E-01', '4.47E+00', '3.77E+00', '1.36E-02', '3.21E+00', '1.87E+00'; ...
        'F14 (Foxholes)', 'Best', '9.98E-01', '9.98E-01', '9.98E-01', '9.98E-01', '9.98E-01', '9.98E-01', '9.98E-01', '9.98E-01'; ...
        'F14 (Foxholes)', 'Rank', '3', '5', '2', '7', '8', '1', '6', '4'; ...
        'F15 (Kowalik)', 'Mean', '4.30E-04', '6.64E-04', '7.47E-04', '5.15E-03', '1.31E-02', '6.12E-04', '1.88E-03', '1.06E-03'; ...
        'F15 (Kowalik)', 'Std', '2.09E-04', '3.93E-04', '6.16E-04', '8.40E-03', '2.47E-02', '1.21E-04', '3.69E-03', '3.72E-04'; ...
        'F15 (Kowalik)', 'Best', '3.07E-04', '3.09E-04', '3.13E-04', '3.07E-04', '3.28E-04', '3.82E-04', '6.49E-04', '5.18E-04'; ...
        'F15 (Kowalik)', 'Rank', '1', '3', '4', '7', '8', '2', '6', '5'; ...
        'F16 (Six-Hump Camel)', 'Mean', '-1.03E+00', '-1.03E+00', '-1.03E+00', '-1.03E+00', '-1.03E+00', '-1.03E+00', '-1.03E+00', '-1.03E+00'; ...
        'F16 (Six-Hump Camel)', 'Std', '1.44E-11', '2.53E-04', '1.00E-06', '9.20E-09', '1.61E-07', '8.13E-08', '6.66E-16', '5.55E-05'; ...
        'F16 (Six-Hump Camel)', 'Best', '-1.03E+00', '-1.03E+00', '-1.03E+00', '-1.03E+00', '-1.03E+00', '-1.03E+00', '-1.03E+00', '-1.03E+00'; ...
        'F16 (Six-Hump Camel)', 'Rank', '2', '8', '6', '3', '5', '4', '1', '7'; ...
        'F17 (Branin RCOS)', 'Mean', '3.98E-01', '4.09E-01', '3.99E-01', '3.98E-01', '4.08E-01', '3.98E-01', '3.98E-01', '4.01E-01'; ...
        'F17 (Branin RCOS)', 'Std', '2.14E-11', '1.82E-02', '1.56E-03', '8.90E-05', '1.07E-02', '3.27E-06', '0.00E+00', '3.40E-03'; ...
        'F17 (Branin RCOS)', 'Best', '3.98E-01', '3.98E-01', '3.98E-01', '3.98E-01', '3.98E-01', '3.98E-01', '3.98E-01', '3.98E-01'; ...
        'F17 (Branin RCOS)', 'Rank', '2', '8', '5', '4', '7', '3', '1', '6'; ...
        'F18 (Goldstein-Price)', 'Mean', '3.00E+00', '3.90E+00', '3.26E+00', '5.70E+00', '7.11E+00', '3.00E+00', '3.00E+00', '3.00E+00'; ...
        'F18 (Goldstein-Price)', 'Std', '2.15E-09', '4.85E+00', '3.95E-01', '1.45E+01', '1.08E+01', '1.98E-08', '2.72E-15', '9.55E-05'; ...
        'F18 (Goldstein-Price)', 'Best', '3.00E+00', '3.00E+00', '3.00E+00', '3.00E+00', '3.00E+00', '3.00E+00', '3.00E+00', '3.00E+00'; ...
        'F18 (Goldstein-Price)', 'Rank', '2', '6', '5', '7', '8', '3', '1', '4'; ...
        'F19 (Hartmann 3D)', 'Mean', '-3.86E+00', '-3.78E+00', '-3.79E+00', '-3.86E+00', '-3.85E+00', '-3.86E+00', '-3.86E+00', '-3.85E+00'; ...
        'F19 (Hartmann 3D)', 'Std', '1.11E-06', '1.40E-01', '5.73E-02', '1.77E-03', '4.24E-03', '4.71E-09', '3.09E-15', '3.25E-03'; ...
        'F19 (Hartmann 3D)', 'Best', '-3.86E+00', '-3.86E+00', '-3.86E+00', '-3.86E+00', '-3.86E+00', '-3.86E+00', '-3.86E+00', '-3.86E+00'; ...
        'F19 (Hartmann 3D)', 'Rank', '3', '8', '7', '4', '6', '2', '1', '5'; ...
        'F20 (Hartmann 6D)', 'Mean', '-3.29E+00', '-3.15E+00', '-3.04E+00', '-3.27E+00', '-3.06E+00', '-3.29E+00', '-3.23E+00', '-2.87E+00'; ...
        'F20 (Hartmann 6D)', 'Std', '5.18E-02', '8.49E-02', '1.43E-01', '7.74E-02', '8.85E-02', '2.43E-02', '6.20E-02', '4.76E-01'; ...
        'F20 (Hartmann 6D)', 'Best', '-3.32E+00', '-3.28E+00', '-3.26E+00', '-3.32E+00', '-3.23E+00', '-3.32E+00', '-3.32E+00', '-3.14E+00'; ...
        'F20 (Hartmann 6D)', 'Rank', '2', '5', '7', '3', '6', '1', '4', '8'; ...
        'F21 (Shekel 5)', 'Mean', '-9.47E+00', '-9.13E+00', '-7.70E+00', '-8.81E+00', '-4.01E+00', '-1.01E+01', '-6.22E+00', '-2.70E+00'; ...
        'F21 (Shekel 5)', 'Std', '1.73E+00', '1.50E+00', '2.05E+00', '2.50E+00', '1.43E+00', '1.38E-02', '3.34E+00', '2.01E+00'; ...
        'F21 (Shekel 5)', 'Best', '-1.02E+01', '-1.01E+01', '-1.01E+01', '-1.02E+01', '-8.06E+00', '-1.02E+01', '-1.02E+01', '-7.54E+00'; ...
        'F21 (Shekel 5)', 'Rank', '2', '3', '5', '4', '7', '1', '6', '8'; ...
        'F22 (Shekel 7)', 'Mean', '-9.69E+00', '-8.34E+00', '-7.91E+00', '-1.01E+01', '-3.51E+00', '-1.03E+01', '-6.08E+00', '-2.68E+00'; ...
        'F22 (Shekel 7)', 'Std', '1.81E+00', '2.58E+00', '1.98E+00', '1.37E+00', '8.81E-01', '1.36E-01', '3.56E+00', '1.66E+00'; ...
        'F22 (Shekel 7)', 'Best', '-1.04E+01', '-1.04E+01', '-1.04E+01', '-1.04E+01', '-5.13E+00', '-1.04E+01', '-1.04E+01', '-4.86E+00'; ...
        'F22 (Shekel 7)', 'Rank', '3', '4', '5', '2', '7', '1', '6', '8'; ...
        'F23 (Shekel 10)', 'Mean', '-1.02E+01', '-8.58E+00', '-6.91E+00', '-1.05E+01', '-4.51E+00', '-1.05E+01', '-6.83E+00', '-3.82E+00'; ...
        'F23 (Shekel 10)', 'Std', '1.35E+00', '2.64E+00', '2.06E+00', '3.19E-04', '1.73E+00', '6.90E-02', '3.51E+00', '1.79E+00'; ...
        'F23 (Shekel 10)', 'Best', '-1.05E+01', '-1.05E+01', '-1.04E+01', '-1.05E+01', '-8.35E+00', '-1.05E+01', '-1.05E+01', '-7.70E+00'; ...
        'F23 (Shekel 10)', 'Rank', '3', '4', '5', '1', '7', '2', '6', '8'};

    table15 = { ...
        'Problem', 'Variable', 'DFFG-AVOA', 'AVOA', 'IROAVOA', 'GWO', 'AOA', 'FPA', 'MFO', 'SCA'; ...
        'Speed reducer', 'b',  '3.5000', '3.5001', '3.5001', '3.5036', '3.6000', '3.5051', '3.5000', '3.6000'; ...
        '', 'm',              '0.7000', '0.7000', '0.7000', '0.7000', '0.7000', '0.7000', '0.7000', '0.7000'; ...
        '', 'z',              '17',     '17',     '17',     '17',     '17',     '17',     '17',     '17'; ...
        '', 'l1',             '7.3049', '7.3000', '8.1860', '7.3260', '7.5353', '7.3349', '7.3000', '7.3000'; ...
        '', 'l2',             '7.7192', '8.0784', '8.1816', '7.8572', '8.3000', '7.7365', '7.7153', '8.3000'; ...
        '', 'd1',             '3.3525', '3.4375', '3.4050', '3.3534', '3.3609', '3.3515', '3.3502', '3.3978'; ...
        '', 'd2',             '5.2867', '5.3455', '5.4228', '5.2876', '5.3416', '5.2874', '5.2867', '5.2932'; ...
        '', 'f(xbest)',       '2995.18295', '3063.28351', '3116.28566', '3000.62214', '3086.86872', '2998.04214', '2994.47107', '3062.98216'; ...
        'Three-bar truss', 'A1', '0.7888', '0.7855', '0.7880', '0.7897', '0.7791', '0.7887', '0.7884', '0.7905'; ...
        '', 'A2',                  '0.4078', '0.4175', '0.4102', '0.4054', '0.4366', '0.4083', '0.4089', '0.4032'; ...
        '', 'f(xbest)',            '263.895868', '263.916111', '263.897625', '263.896638', '264.006397', '263.895844', '263.895887', '263.911528'; ...
        'Cantilever beam', 'b1', '6.0207', '6.2648', '5.8420', '6.0234', '5.9577', '6.2044', '6.0330', '6.4308'; ...
        '', 'b2',                '5.3159', '5.7381', '5.3578', '5.3220', '5.3518', '5.1539', '5.2589', '5.7034'; ...
        '', 'b3',                '4.4830', '4.3947', '4.7634', '4.4857', '5.2489', '4.7325', '4.5513', '4.5397'; ...
        '', 'b4',                '3.4971', '3.2170', '3.6092', '3.4997', '3.5425', '3.8981', '3.4891', '2.9501'; ...
        '', 'b5',                '2.1571', '2.0169', '1.9805', '2.1433', '3.1506', '2.2627', '2.1439', '2.2233'; ...
        '', 'f(xbest)',          '1.339963', '1.349801', '1.344894', '1.339981', '1.450892', '1.388507', '1.340121', '1.363279'};

    captions = struct();
    captions.Table10 = 'Comparative Optimisation Results for UM Benchmark Functions (F1–F7)';
    captions.Table11 = 'Comparative Optimisation Results for VDM Benchmark Functions (F8–F13)';
    captions.Table12 = 'Comparative Optimisation Results for FDM Benchmark Functions (F14–F23)';
    captions.Table15 = 'Comparative Best Feasible Solutions for Three Engineering Design Problems';
end



function validation = validateFrozenManuscriptTables( ...
        table10, table11, table12, table15, S, E, expected_algorithms, ...
        expected_num_runs, expected_N, expected_Max_iter)
% Verify that frozen manuscript-facing strings correspond to the two raw
% authorities without rewriting the strings. This protects manuscript
% precision and catches accidental source drift.

    assert(isequal(size(table10), [29,10]), 'Frozen Table 10 dimensions changed.');
    assert(isequal(size(table11), [25,10]), 'Frozen Table 11 dimensions changed.');
    assert(isequal(size(table12), [41,10]), 'Frozen Table 12 dimensions changed.');
    assert(isequal(size(table15), [18,10]), 'Frozen Table 15 dimensions changed.');

    frozen_tables = {table10, table11, table12, table15};
    for kk = 1:numel(frozen_tables)
        TT = frozen_tables{kk};
        header_algs = string(TT(1,3:10));
        assert(isequal(header_algs(:), expected_algorithms(:)), ...
            'Frozen manuscript algorithm order does not match the raw-data order.');
    end

    % Mathematical Tables 10-12: compare every displayed Mean/Std/Best/Rank
    % algorithm cell against the stored raw-study descriptive arrays.
    math_tables = {table10, table11, table12};
    starts = [1, 8, 14];
    counts = [7, 6, 10];
    underflow_display_zero_count = 0;
    checked_math_cells = 0;

    for tt = 1:3
        T = math_tables{tt};
        for local_f = 1:counts(tt)
            f = starts(tt) + local_f - 1;
            base_row = 2 + (local_f-1)*4;
            assert(contains(string(T{base_row,1}), sprintf('F%d', f)), ...
                'Frozen benchmark label mismatch for F%d.', f);

            stored = { ...
                S.all_mean_results(f,:), ...
                S.all_std_results(f,:), ...
                S.all_min_results(f,:), ...
                S.all_rank_results(f,:)};

            for metric = 1:4
                for a = 1:8
                    observed = char(string(T{base_row+metric-1, a+2}));
                    raw_value = stored{metric}(a);
                    if metric <= 3
                        expected = sprintf('%.2E', raw_value);
                        if ~strcmp(observed, expected)
                            % One manuscript-facing practical-zero convention
                            % is retained for subnormal values below 1e-300.
                            is_display_zero = strcmp(observed, '0.00E+00') && ...
                                abs(raw_value) < 1e-300;
                            assert(is_display_zero, ...
                                ['Frozen Table %d value mismatch at F%d metric %d ' ...
                                 'algorithm %s: manuscript=%s raw-display=%s'], ...
                                9+tt, f, metric, expected_algorithms(a), ...
                                observed, expected);
                            underflow_display_zero_count = underflow_display_zero_count + 1;
                        end
                    else
                        expected = sprintf('%g', raw_value);
                        assert(strcmp(observed, expected), ...
                            ['Frozen descriptive Rank mismatch at F%d algorithm %s: ' ...
                             'manuscript=%s raw=%s'], ...
                            f, expected_algorithms(a), observed, expected);
                    end
                    checked_math_cells = checked_math_cells + 1;
                end
            end
        end
    end

    % Engineering identity and orientation.
    assert(E.num_runs == expected_num_runs, 'Engineering run count mismatch.');
    assert(E.N == expected_N, 'Engineering population-size mismatch.');
    assert(E.Max_iter == expected_Max_iter, 'Engineering iteration-count mismatch.');
    expected_eng_functions = arrayfun(@(k) sprintf('E%d', k), 1:11, ...
        'UniformOutput', false)';
    assert(isequal(string(E.benchmark_functions_names(:)), string(expected_eng_functions)), ...
        'Engineering problem order is not exactly E1-E11.');
    assert(isequal(string(E.configurations(:,1)), expected_algorithms), ...
        'Engineering algorithm order does not match the frozen algorithm order.');
    assert(isequal(size(E.all_min_results), [11,8]), ...
        'Engineering all_min_results must be 11 x 8.');
    assert(isequal(size(E.all_best_designs), [11,8]), ...
        'Engineering all_best_designs must be 11 x 8.');

    eng_indices = [4, 6, 7]; % speed reducer, three-bar truss, cantilever beam
    expected_problem_names = ["Speed reducer", "Three-bar truss", "Cantilever beam"];
    problem_start_rows = [2, 10, 13];
    problem_objective_rows = [9, 12, 18];
    problem_design_lengths = [7, 2, 5];
    expected_variable_labels = { ...
        ["b","m","z","l1","l2","d1","d2"], ...
        ["A1","A2"], ...
        ["b1","b2","b3","b4","b5"]};

    checked_eng_objectives = 0;
    checked_eng_design_values = 0;

    for p = 1:3
        start_row = problem_start_rows(p);
        objective_row = problem_objective_rows(p);
        assert(strcmp(string(table15{start_row,1}), expected_problem_names(p)), ...
            'Frozen engineering problem label mismatch for Table 15 row %d.', start_row);

        labels_in_table = string(table15(start_row:objective_row-1,2))';
        assert(isequal(labels_in_table, expected_variable_labels{p}), ...
            'Table 15 variable labels changed for %s.', expected_problem_names(p));
        assert(strcmp(string(table15{objective_row,2}), "f(xbest)"), ...
            'Table 15 objective label changed for %s.', expected_problem_names(p));

        fidx = eng_indices(p);

        for a = 1:8
            % Objective: preserve the manuscript-facing displayed precision.
            display_obj = char(string(table15{objective_row,a+2}));
            obj_numeric = str2double(display_obj);
            tol_obj = 1.1 * decimalDisplayUnit(display_obj);
            raw_obj = E.all_min_results(fidx,a);
            assert(abs(obj_numeric - raw_obj) <= tol_obj, ...
                ['Table 15 objective mismatch for %s / %s: ' ...
                 'display=%s raw=%.16g'], ...
                expected_problem_names(p), expected_algorithms(a), ...
                display_obj, raw_obj);
            checked_eng_objectives = checked_eng_objectives + 1;

            % Design variables: one displayed scalar per row. This preserves
            % exactly the same four-decimal values previously contained in
            % each xbest vector, while making variable identities explicit.
            raw_design = E.all_best_designs{fidx,a};
            raw_design = raw_design(:)';
            assert(numel(raw_design) == problem_design_lengths(p), ...
                'Engineering design length mismatch for %s / %s.', ...
                expected_problem_names(p), expected_algorithms(a));

            for q = 1:problem_design_lengths(p)
                display_design = char(string(table15{start_row+q-1,a+2}));
                display_numeric = str2double(display_design);
                if p == 1 && q == 3  % speed-reducer tooth count z is integer
                    tol_design = 0;
                else
                    tol_design = 1.1 * decimalDisplayUnit(display_design);
                end
                assert(abs(display_numeric - raw_design(q)) <= tol_design, ...
                    ['Table 15 design-variable mismatch for %s / %s / %s: ' ...
                     'display=%s raw=%.16g'], ...
                    expected_problem_names(p), expected_algorithms(a), ...
                    expected_variable_labels{p}(q), display_design, raw_design(q));
                checked_eng_design_values = checked_eng_design_values + 1;
            end
        end
    end

    validation = struct();
    validation.MathDisplayCellsChecked = checked_math_cells;
    validation.MathUnderflowDisplayZeroExceptions = underflow_display_zero_count;
    validation.EngineeringObjectivesChecked = checked_eng_objectives;
    validation.EngineeringDesignScalarsChecked = checked_eng_design_values;
    validation.Tables10to12ExactDisplayPreserved = true;
    validation.Table15EngineeringValuesPreserved = true;
    validation.Table15VariableRowPresentation = true;
    validation.RawAuthorityCrossCheckPassed = true;
end

function values = parseDisplayedVector(txt)
    left = strfind(txt, '[');
    right = strfind(txt, ']');
    assert(~isempty(left) && ~isempty(right) && right(end) > left(1), ...
        'Could not parse displayed engineering vector: %s', txt);
    body = txt(left(1)+1:right(end)-1);
    parts = strsplit(body, ',');
    values = nan(1,numel(parts));
    for k = 1:numel(parts)
        values(k) = str2double(strtrim(parts{k}));
    end
    assert(~any(isnan(values)), 'Non-numeric displayed engineering vector: %s', txt);
end

function unit = decimalDisplayUnit(txt)
    epos = regexpi(txt, 'e');
    if ~isempty(epos)
        mantissa = txt(1:epos(1)-1);
        exponent = str2double(txt(epos(1)+1:end));
    else
        mantissa = txt;
        exponent = 0;
    end
    dot = strfind(mantissa, '.');
    if isempty(dot)
        decimals = 0;
    else
        decimals = numel(mantissa) - dot(end);
    end
    unit = 10^(exponent - decimals);
end


function formatEngineeringVariableLabels(word_table)
% Format the Table 15 Variable column for the V4.4 one-variable-per-row
% presentation. Variable symbols are italic, numeric indices are subscript,
% and the objective label is rendered as f(x_best).

    variable_rows = [2:8, 10:11, 13:17];
    objective_rows = [9, 12, 18];

    % Design-variable labels.
    for r = variable_rows
        cell_obj = word_table.Cell(r,2);
        content = cell_obj.Range.Duplicate;
        content.End = content.End - 1; % exclude Word end-of-cell marker
        content.Font.Name = 'Times New Roman';
        content.Font.Size = 8;
        content.Font.Italic = -1;

        txt = char(content.Text);
        base = content.Start;
        for pos = 1:numel(txt)
            if isstrprop(txt(pos), 'digit')
                dr = cell_obj.Range.Duplicate;
                dr.Start = base + pos - 1;
                dr.End = dr.Start + 1;
                dr.Font.Subscript = -1;
                dr.Font.Italic = -1;
            end
        end
    end

    % Objective label f(xbest) -> f(x_best), retaining the compact table text.
    for r = objective_rows
        cell_obj = word_table.Cell(r,2);
        content = cell_obj.Range.Duplicate;
        content.End = content.End - 1;
        content.Font.Name = 'Times New Roman';
        content.Font.Size = 8;
        content.Font.Italic = -1;

        txt = char(content.Text);
        xpos = strfind(txt, 'xbest');
        if ~isempty(xpos)
            base = content.Start;

            xr = cell_obj.Range.Duplicate;
            xr.Start = base + xpos(1) - 1;
            xr.End = xr.Start + 1;
            xr.Font.Bold = -1;
            xr.Font.Italic = -1;

            br = cell_obj.Range.Duplicate;
            br.Start = base + xpos(1);
            br.End = br.Start + 4;
            br.Font.Subscript = -1;
            br.Font.Italic = -1;
        end
    end
end


function setWordCellText(word_cell, value)
% Convert a MATLAB cell value to deterministic Word text.

    if isempty(value)
        txt = '';
    elseif isstring(value)
        txt = char(value);
    elseif ischar(value)
        txt = value;
    elseif isnumeric(value) || islogical(value)
        if isscalar(value)
            txt = sprintf('%g', value);
        else
            txt = char(string(value));
        end
    else
        txt = char(string(value));
    end

    word_cell.Range.Text = txt;
end


function formatManuscriptWorkbook(workbook_path, num_functions, num_comparators)
% Apply AOA-style presentation formatting to worksheet "Table 13" and
% worksheet "Table 14". This function changes workbook appearance only.
% It does not recalculate or alter the underlying statistical outputs.
%
% MATLAB's writecell/writetable functions do not provide grouped/merged
% Excel headers. On Windows, Excel COM automation is therefore used when
% available. If Excel automation is unavailable, the workbook remains
% numerically complete and the script continues with a warning.

    if ~ispc
        warning(['AOA-style Excel grouping was not applied because Excel COM ' ...
                 'automation is available only on Windows.']);
        return;
    end

    excel = [];
    workbook = [];
    try
        excel = actxserver('Excel.Application');
        excel.Visible = false;
        excel.DisplayAlerts = false;
        workbook = excel.Workbooks.Open(workbook_path);

        xlCenter = -4108;
        xlContinuous = 1;
        xlThin = 2;

        %% Table 13
        ws13 = workbook.Worksheets.Item('Table 13');
        last_row13 = 4 + (num_functions + 3) - 1;
        data_range13 = ws13.Range(sprintf('A4:I%d', last_row13));
        data_range13.HorizontalAlignment = xlCenter;
        data_range13.VerticalAlignment = xlCenter;
        data_range13.Borders.LineStyle = xlContinuous;
        data_range13.Borders.Weight = xlThin;

        ws13.Range('A4:I4').Font.Bold = true;
        ws13.Range(sprintf('A%d:I%d', last_row13 - 1, last_row13)).Font.Bold = true;
        ws13.Columns.Item(1).ColumnWidth = 14;
        for col = 2:9
            ws13.Columns.Item(col).ColumnWidth = 12;
        end
        ws13.Range('A1:I2').Font.Bold = true;

        %% Table 14
        ws14 = workbook.Worksheets.Item('Table 14');
        last_row14 = 4 + (num_functions + 3) - 1;
        last_col14 = 1 + 3 * num_comparators;
        last_col_letter = excelColumnName(last_col14);
        data_range14 = ws14.Range(sprintf('A4:%s%d', last_col_letter, last_row14));
        data_range14.HorizontalAlignment = xlCenter;
        data_range14.VerticalAlignment = xlCenter;
        data_range14.Borders.LineStyle = xlContinuous;
        data_range14.Borders.Weight = xlThin;

        % F spans the two header rows, as in the adopted AOA architecture.
        ws14.Range('A4:A5').Merge;
        ws14.Range('A4').Value = 'F';
        ws14.Range('A4').Font.Bold = true;

        % Each comparator spans p-value | H | S.
        for c = 1:num_comparators
            start_col = 2 + (c - 1) * 3;
            finish_col = start_col + 2;
            start_letter = excelColumnName(start_col);
            finish_letter = excelColumnName(finish_col);
            group_range = ws14.Range(sprintf('%s4:%s4', start_letter, finish_letter));
            group_range.Merge;
            group_range.HorizontalAlignment = xlCenter;
            group_range.Font.Bold = true;

            ws14.Columns.Item(start_col).ColumnWidth = 13;     % p-value
            ws14.Columns.Item(start_col + 1).ColumnWidth = 5;  % H
            ws14.Columns.Item(start_col + 2).ColumnWidth = 5;  % S
        end

        ws14.Range(sprintf('A5:%s5', last_col_letter)).Font.Bold = true;
        ws14.Range(sprintf('A%d:%s%d', last_row14, last_col_letter, last_row14)).Font.Bold = true;
        ws14.Columns.Item(1).ColumnWidth = 12;
        ws14.Range(sprintf('A1:%s2', last_col_letter)).Font.Bold = true;

        workbook.Save;
        workbook.Close(false);
        excel.Quit;

    catch ME
        % Best-effort cleanup so Excel is not left running after a formatting
        % failure. The numerical workbook already exists at this point.
        try
            if ~isempty(workbook)
                workbook.Close(false);
            end
        catch
        end
        try
            if ~isempty(excel)
                excel.Quit;
            end
        catch
        end
        warning('Manuscript-sheet Excel formatting was not fully applied: %s', ME.message);
    end
end

function name = excelColumnName(column_number)
% Convert a positive Excel column number to its A1-style column letters.

    assert(column_number >= 1 && column_number == floor(column_number), ...
        'Excel column number must be a positive integer.');

    name = '';
    n = column_number;
    while n > 0
        remainder = mod(n - 1, 26);
        name = [char(65 + remainder), name]; %#ok<AGROW>
        n = floor((n - 1) / 26);
    end
end

function filepath = resolveInputFile(filename, script_dir)
% Resolve the raw MAT file without silently selecting an arbitrary file.

    candidates = { ...
        fullfile(script_dir, filename), ...
        fullfile(pwd, filename), ...
        fullfile(script_dir, 'aaa', filename), ...
        fullfile(pwd, 'aaa', filename)};

    filepath = '';
    for i = 1:numel(candidates)
        if exist(candidates{i}, 'file') == 2
            filepath = candidates{i};
            break;
        end
    end

    if isempty(filepath)
        error(['Cannot locate %s. Place this script beside the raw MAT file ' ...
               'or in the parent folder of an aaa directory containing it.'], ...
               filename);
    end
end

function assertMatrixMatch(A, B, label)
% Demand exact reproduction where possible, then allow only tiny floating
% arithmetic differences. This is an audit safeguard, not a data repair.

    if isequaln(A, B)
        return;
    end

    if ~isequal(size(A), size(B))
        error('%s matrix size mismatch.', label);
    end

    abs_diff = abs(A - B);
    scale = max(abs(B), realmin('double'));
    rel_diff = abs_diff ./ scale;

    % Relative tolerance is deliberately tight; absolute tolerance only
    % protects values extremely close to zero from meaningless ratios.
    bad = (rel_diff > 1e-12) & (abs_diff > 1e-300);

    if any(bad, 'all')
        [r, c] = find(bad, 1, 'first');
        error(['%s do not reproduce from raw data. First mismatch at ' ...
               'row %d, column %d: recomputed=%.17g, stored=%.17g.'], ...
               label, r, c, A(r, c), B(r, c));
    end
end

function txt = formatPValue(p)
% Compact scientific notation for the manuscript-style Wilcoxon table.
% Full precision remains available in Wilcoxon_Full_Audit.

    if ~isfinite(p)
        txt = 'NaN';
        return;
    end

    txt = sprintf('%.3E', p);
end
