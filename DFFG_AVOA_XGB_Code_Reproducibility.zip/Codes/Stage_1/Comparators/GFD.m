function [lb,ub,dim,fobj] = GFD(F)

switch F
    case 'F1' % Tension/compression spring design
        fobj = @F1;        lb=[0.05,0.25,2];        ub=[2,1.3,15];        dim=3;   
    case 'F2' %Pressure vessel design
        fobj = @F2;        lb=[0,0,10,10];        ub=[99,99,200,200];        dim=4;
    case 'F3' %Welded beam design
        fobj = @F3;        lb=[0.1,0.1,0.1,0.1];        ub=[2,10,10,2];        dim=4;
    case 'F4' % speed reducer problem
        fobj = @F4;  lb=[2.6,0.7,17,7.3,7.3,2.9,5.0];   ub=[3.6,0.8,28,8.3,8.3,3.9,5.5];  dim=7;
    case 'F5' % Gear train design problem (Standard continuous)
        fobj = @F5;  lb=[12,12,12,12]; ub=[60,60,60,60]; dim=4;
    case 'F6' % Three bar truss design
        fobj = @F6; lb=[0,0]; ub=[1,1]; dim=2;
    case 'F7' % Cantilever beam design (Corrected Coefficient)
        fobj = @F7; lb=[0.01,0.01,0.01,0.01,0.01]; ub=[100,100,100,100,100]; dim=5;
    case 'F8' % Multiple disc clutch brake design (Corrected Units)
        fobj = @F8; lb=[60,90,1,600,2]; ub=[80,110,3,1000,9]; dim=5;
        
    case 'F9' % Gear train design (Integer/Discrete version)
        fobj = @F9; 
        lb=[12, 12, 12, 12]; 
        ub=[60, 60, 60, 60]; 
        dim=4;
        
    case 'F10' % Rolling element bearing design
        fobj = @F10;
        % Bounds calculated from EngRange.m using D=160, d=90
        % LB = [0.5(D+d), 0.15(D-d), 4, 0.515, 0.515, 0.4, 0.6, 0.3, 0.02, 0.6]
        lb = [125, 10.5, 4, 0.515, 0.515, 0.4, 0.6, 0.3, 0.02, 0.6];
        % UB = [0.6(D+d), 0.45(D-d), 50, 0.6, 0.6, 0.5, 0.7, 0.4, 0.1, 0.85]
        ub = [150, 31.5, 50, 0.6, 0.6, 0.5, 0.7, 0.4, 0.1, 0.85];
        dim = 10;

    case 'F11' % Car crashworthiness design
        fobj = @F11;
        lb = [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.192, 0.192, -30, -30];
        ub = [1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 0.345, 0.345, 30, 30];
        dim = 11;
end
end

% F1
function o = F1(x) % Tension/compression spring design
cost=(x(3)+2)*x(2)*(x(1)^2);
g(1)=1-((x(3)*(x(2)^3))/(71785*(x(1)^4)));   
gtmp=(4*x(2)^2-x(1)*x(2))/(12566*(x(2)*x(1)^3-x(1)^4));
g(2)=gtmp+1/(5108*x(1)^2)-1;                      
g(3)=1-((140.45*x(1))/((x(2)^2)*x(3)));        
g(4)=((x(1)+x(2))/1.5)-1;            
lam=10^15; Z=0;     for k=1:length(g),    Z=Z+ lam*g(k)^2*getH(g(k));   end
o=cost+ Z;
end

% F2
function o = F2(x) % Pressure vessel design
cost=0.6224*x(1)*x(3)*x(4)+1.7781*x(2)*x(3)^2+3.1661*x(1)^2*x(4)+19.84*x(1)^2*x(3);
g(1)=-x(1)+0.0193*x(3);                                  
g(2)=-x(2)+0.00954*x(3);                                  
g(3)=-pi*x(3)^2*x(4)-(4/3)*pi*x(3)^3+1296000;  
g(4)=x(4)-240;       
lam=10^15; Z=0;     for k=1:length(g),    Z=Z+ lam*g(k)^2*getH(g(k));   end
o=cost+ Z;
end

% F3
function o = F3(x) % Welded beam design
cost=1.10471*x(1)^2*x(2)+0.04811*x(3)*x(4)*(14.0+x(2));
Q=6000*(14+x(2)/2);
D=sqrt(x(2)^2/4 + (x(1)+x(3))^2/4);
J=2*(x(1)*x(2)*sqrt(2)*(x(2)^2/12 + (x(1)+x(3))^2/4));
alfa=6000/(sqrt(2)*x(1)*x(2));
beta=Q*D/J;
tau=sqrt(alfa^2 + 2*alfa*beta*x(2)/(2*D) + beta^2);
sigma=504000/(x(4)*x(3)^2);
delta=65856000/(30*10^6*x(4)*x(3)^3);
F=4.013*(30*10^6)/196*sqrt(x(3)^2*x(4)^6/36)*(1-x(3)*sqrt(30/48)/28);

g(1)=tau-13600;
g(2)=sigma-30000;
g(3)=x(1)-x(4);
g(4)=0.10471*x(1)^2 + 0.04811*x(3)*x(4)*(14+x(2))-5.0;
g(5)=0.125-x(1);
g(6)=delta-0.25;
g(7)=6000-F;

lam=10^15; Z=0;     for k=1:length(g),    Z=Z+ lam*g(k)^2*getH(g(k));   end
o=cost+ Z;
end

% F4
function o = F4(x) % Speed reducer problem
cost=0.7854*x(1)*(x(2)^2)*(3.3333*x(3)^2+14.9334*x(3)-43.0934)-1.508*x(1)*(x(6)^2+x(7)^2)+7.4777*(x(6)^3+x(7)^3)+0.7854*(x(4)*x(6)^2+x(5)*x(7)^2);

g(1)=27/(x(1)*x(2)^2*x(3))-1;
g(2)=397.5/(x(1)*x(2)^2*x(3)^2)-1;
g(3)=1.93*x(4)^3/(x(2)*x(6)^4*x(3))-1;
g(4)=1.93*x(5)^3/(x(2)*x(7)^4*x(3))-1;
g(5)=sqrt((745*x(4)/(x(2)*x(3)))^2+16.9*10^6)/(110*x(6)^3)-1;
g(6)=sqrt((745*x(5)/(x(2)*x(3)))^2+157.5*10^6)/(85*x(7)^3)-1;
g(7)=x(2)*x(3)/40-1;
g(8)=5*x(2)/x(1)-1;
g(9)=(x(1)/(12*x(2)))-1;
g(10)=((1.5*x(6)+1.9)/x(4))-1;
g(11)=((1.1*x(7)+1.9)/x(5))-1;

lam=10^15; Z=0;     for k=1:length(g),    Z=Z+ lam*g(k)^2*getH(g(k));   end
o=cost+ Z;
end

% F5
function o = F5(x) % Gear train design problem (Standard)
cost=((1/6.931)-((x(3)*x(2))/(x(1)*x(4))))^2;  
o=cost;
end

% F6
function o = F6(x) % Three-bar truss design problem
    % Safe version to prevent non-finite objective values
    cost= (2.*sqrt(2).*x(1)+x(2))*100;

    d1 = sqrt(2).*x(1).^2 + 2.*x(1).*x(2);
    d2 = sqrt(2).*x(2) + x(1);
    eps_den = 1e-12;

    if abs(d1) < eps_den
        if d1 == 0
            d1 = eps_den;
        else
            d1 = sign(d1) * eps_den;
        end
    end

    if abs(d2) < eps_den
        if d2 == 0
            d2 = eps_den;
        else
            d2 = sign(d2) * eps_den;
        end
    end

    g(1) = (sqrt(2).*x(1)+x(2))./d1*2-2;
    g(2) = x(2)./d1*2-2;
    g(3) = 1./d2*2-2;

    lam=10^15; Z=0;
    for k=1:length(g)
        if ~isfinite(g(k))
            g(k)=1e12;
        end
        Z=Z+ lam*g(k)^2*getH(g(k));
    end

    o=cost+ Z;

    if ~isfinite(o) || ~isscalar(o)
        o = realmax('double') / 1e100;
    end
end

% F7
function o = F7(x) % Cantilever beam design problem
    % Corrected coefficient 0.06224 used to match results table
    cost = 0.06224 * (x(1) + x(2) + x(3) + x(4) + x(5));
    g(1) = (60/(x(1)^3) + 27/(x(2)^3) + 19/(x(3)^3) + 7/(x(4)^3) + 1/(x(5)^3)) - 1;
    lam=10^15; Z=0;     for k=1:length(g),    Z=Z+ lam*g(k)^2*getH(g(k));   end
    o=cost+ Z;
end

% F8
function o = F8(x) % Multiple disc clutch brake problem
    ri = x(1); ro = x(2); t = x(3); F = x(4); Z = x(5);
    mu = 0.5; rho = 0.0000078; Ms = 40; Mf = 3; n = 250; 
    Iz = 55; lmax = 30; Pmax = 1; Tmax = 15; Vsr_max = 10; delta = 0.5;
    cost = pi * (ro^2 - ri^2) * t * (Z + 1) * rho;
    Rs = (2/3) * ((ro^3 - ri^3) / (ro^2 - ri^2)); 
    area = pi * (ro^2 - ri^2);
    Prz = F / area;
    Vsr = (pi * Rs * n) / (30 * 1000); % Fixed unit conversion (mm/s to m/s)
    Mh = (2/3) * mu * F * Z * ((ro^3 - ri^3) / (ro^2 - ri^2));
    T = (Iz * (pi * n / 30)) / (Mh + Mf);
    g(1) = (ri - ro) + 20;               
    g(2) = (Z + 1) * (t + delta) - lmax; 
    g(3) = Prz - Pmax;                   
    g(4) = Prz * Vsr - (Pmax * Vsr_max); 
    g(5) = Vsr - Vsr_max;                
    g(6) = T - Tmax;                     
    g(7) = (1.5 * Ms) - Mh;              
    lam=10^15; Z_pen=0;     for k=1:length(g),    Z_pen = Z_pen + lam*g(k)^2*getH(g(k));   end
    o = cost + Z_pen;
end

% F9
function o = F9(x) % Gear train design (Integer/Discrete)
    % Extracted from EngFunctions.m (otherwise case)
    x = round(x); 
    cost = ((1/6.931)-((x(3)*x(2))/(x(1)*x(4))))^2;  
    o = cost;
end

% F10
function o = F10(x) % Rolling element bearing design
    % Extracted from EngFunctions.m (case 2)
    x(3)=round(x(3));
    
    D=160; d=90; Bw=30;
    
    % Calculation of Phio with domain check
    T=D-d-2*x(2);
    num = (((D-d)/2)-3*(T/4))^2+(D/2-T/4-x(2))^2-(d/2+T/4)^2;
    den = 2*((D-d)/2-3*(T/4))*(D/2-T/4-x(2));
    arg = num/den;
    % Clamp arg to [-1, 1] to avoid complex numbers in acos
    if arg > 1, arg = 1; elseif arg < -1, arg = -1; end
    
    phio = 2*pi - 2*acos(arg);
    
    g(1)=-phio/(2*asin(x(2)/x(1)))+x(3)-1;
    g(2)=-2*x(2)+x(6)*(D-d);
    g(3)= -x(7)*(D-d)+2*x(2);
    g(4)=(0.5-x(9))*(D+d)-x(1);
    g(5)=-(0.5+x(9))*(D+d)+x(1);
    g(6)=-x(1)+0.5*(D+d);
    g(7)= -0.5*(D-x(1)-x(2))+x(8)*x(2);
    g(8)=x(10)*Bw-x(2);
    g(9)=0.515-x(4);
    g(10)=0.515-x(5);
    
    gama=x(2)/x(1);
    
    term_pow = ((x(4)*(2*x(5)-1))/(x(5)*(2*x(4)-1)))^0.41;
    term_1 = (1 + (1.04 * ((1-gama)/(1+gama))^1.72) * term_pow)^(10/3);
    
    fc = 37.91 * (term_1^-0.3) * ((gama^0.3 * (1-gama)^1.39) / (1+gama)^(1/3)) * (2*x(4)/(2*x(4)-1))^0.41;
    
    if x(2) <= 25.4
        f = -fc*x(3)^(2/3)*x(2)^1.8;
    else
        f = -3.647*fc*x(3)^(2/3)*x(2)^1.4;
    end
    
    lam=10^20; Z_pen=0;
    for k=1:length(g)
        Z_pen = Z_pen + lam*g(k)^2*getH(g(k));
    end
    
    o = f + Z_pen;
end

% F11
function o = F11(x) % Car crashworthiness design problem
    cost = 1.98 + 4.90*x(1) + 6.67*x(2) + 6.98*x(3) + 4.01*x(4) + 1.78*x(5) + 2.73*x(7);

    g(1) = 1.16 - 0.3717*x(2)*x(4) - 0.00931*x(2)*x(10) - 0.484*x(3)*x(9) + 0.01343*x(6)*x(10) - 1.0;
    g(2) = 0.261 - 0.0159*x(1)*x(2) - 0.188*x(1)*x(8) - 0.019*x(2)*x(7) + 0.0144*x(3)*x(5) + 0.0008757*x(5)*x(10) + 0.080405*x(6)*x(9) + 0.00139*x(8)*x(11) + 0.00001575*x(10)*x(11) - 0.32;
    g(3) = 0.214 + 0.00817*x(5) - 0.131*x(1)*x(8) - 0.0704*x(1)*x(9) + 0.03099*x(2)*x(6) - 0.018*x(2)*x(7) + 0.0208*x(3)*x(8) + 0.121*x(3)*x(9) - 0.00364*x(5)*x(6) + 0.0007715*x(5)*x(10) - 0.0005354*x(6)*x(10) + 0.00121*x(8)*x(11) - 0.32;
    g(4) = 0.074 - 0.061*x(2) - 0.163*x(3)*x(8) + 0.001232*x(3)*x(10) - 0.166*x(7)*x(9) + 0.227*x(2)^2 - 0.32;
    g(5) = 28.98 + 3.818*x(3) - 4.2*x(1)*x(2) + 0.0207*x(5)*x(10) + 6.63*x(6)*x(9) - 7.7*x(7)*x(8) + 0.32*x(9)*x(10) - 32.0;
    g(6) = 33.86 + 2.95*x(3) + 0.1792*x(10) - 5.057*x(1)*x(2) - 11.0*x(2)*x(8) - 0.0215*x(5)*x(10) - 9.98*x(7)*x(8) + 22.0*x(8)*x(9) - 32.0;
    g(7) = 46.36 - 9.9*x(2) - 12.9*x(1)*x(8) + 0.1107*x(3)*x(10) - 32.0;
    g(8) = 4.72 - 0.5*x(4) - 0.19*x(2)*x(3) - 0.0122*x(4)*x(10) + 0.009325*x(6)*x(10) + 0.000191*x(11)^2 - 4.0;
    g(9) = 10.58 - 0.674*x(1)*x(2) - 1.95*x(2)*x(8) + 0.02054*x(3)*x(10) - 0.0198*x(4)*x(10) + 0.028*x(6)*x(10) - 9.9;
    g(10)= 16.45 - 0.489*x(3)*x(7) - 0.843*x(5)*x(6) + 0.0432*x(9)*x(10) - 0.0556*x(9)*x(11) - 0.000786*x(11)^2 - 15.7;

    lam=10^15; Z_pen=0;
    for k=1:length(g)
        if ~isfinite(g(k))
            g(k)=1e12;
        end
        Z_pen = Z_pen + lam*g(k)^2*getH(g(k));
    end

    o = cost + Z_pen;

    if ~isfinite(o) || ~isscalar(o)
        o = realmax('double') / 1e100;
    end
end

function z=getH(g)
if g<=0
    z=0;
else
    z=1;
end
end