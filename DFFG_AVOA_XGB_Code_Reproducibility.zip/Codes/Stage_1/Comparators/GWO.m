function [Alpha_score, Alpha_pos, Convergence_curve] = GWO(N, Max_iter, lb, ub, dim, fobj)
% GWO: Grey Wolf Optimizer
% Mirjalili, S., Mirjalili, S. M., & Lewis, A. (2014).
% Grey Wolf Optimizer. Advances in Engineering Software, 69, 46–61.
% DOI: 10.1016/j.advengsoft.2013.12.007
%
% Inputs:
%   N         - number of wolves (population size)
%   Max_iter  - maximum number of iterations
%   lb, ub    - lower and upper bounds (scalar or 1 x dim vectors)
%   dim       - problem dimension
%   fobj      - objective function handle
%
% Outputs:
%   Alpha_score       - best (minimum) fitness found
%   Alpha_pos         - position of the best wolf
%   Convergence_curve - Alpha_score at each iteration

% --- Initialization ---
% Initialize alpha, beta, and delta positions and scores
Alpha_pos   = zeros(1, dim);
Alpha_score = inf;

Beta_pos    = zeros(1, dim);
Beta_score  = inf;

Delta_pos   = zeros(1, dim);
Delta_score = inf;

% Initialize the positions of the wolf pack
Positions = rand(N, dim) .* (ub - lb) + lb;
Convergence_curve = zeros(1, Max_iter);

% --- Main Loop ---
t = 1;
while t <= Max_iter
    % Evaluate each wolf's fitness
    for i = 1:N
        % Boundary checking before fitness evaluation
        Positions(i, :) = max(Positions(i, :), lb);
        Positions(i, :) = min(Positions(i, :), ub);

        fitness = fobj(Positions(i, :));

        % Update Alpha, Beta, and Delta leaders
        if fitness < Alpha_score
            % If the new wolf is better than alpha, all leaders shift down
            Delta_score = Beta_score;
            Delta_pos   = Beta_pos;
            Beta_score  = Alpha_score;
            Beta_pos    = Alpha_pos;
            Alpha_score = fitness;
            Alpha_pos   = Positions(i, :);

        elseif fitness > Alpha_score && fitness < Beta_score
            Delta_score = Beta_score;
            Delta_pos   = Beta_pos;
            Beta_score  = fitness;
            Beta_pos    = Positions(i, :);

        elseif fitness > Beta_score && fitness < Delta_score
            Delta_score = fitness;
            Delta_pos   = Positions(i, :);
        end
    end

    % Linearly decrease 'a' from 2 to 0 to balance exploration and exploitation
    a = 2 - t * (2 / Max_iter);

    % Update the position of the search agents (wolves) including omegas
    for i = 1:N
        % --- Position update based on the three leaders (Eq. 3.5–3.7) ---

        % Towards Alpha
        r1_alpha = rand(1, dim);
        r2_alpha = rand(1, dim);
        A1 = 2 * a * r1_alpha - a;
        C1 = 2 * r2_alpha;
        D_alpha = abs(C1 .* Alpha_pos - Positions(i, :));
        X1 = Alpha_pos - A1 .* D_alpha;

        % Towards Beta
        r1_beta = rand(1, dim);
        r2_beta = rand(1, dim);
        A2 = 2 * a * r1_beta - a;
        C2 = 2 * r2_beta;
        D_beta = abs(C2 .* Beta_pos - Positions(i, :));
        X2 = Beta_pos - A2 .* D_beta;

        % Towards Delta
        r1_delta = rand(1, dim);
        r2_delta = rand(1, dim);
        A3 = 2 * a * r1_delta - a;
        C3 = 2 * r2_delta;
        D_delta = abs(C3 .* Delta_pos - Positions(i, :));
        X3 = Delta_pos - A3 .* D_delta;

        % Average the three influences
        Positions(i, :) = (X1 + X2 + X3) / 3;

        % Immediate boundary checking after update (added refinement)
        Positions(i, :) = max(Positions(i, :), lb);
        Positions(i, :) = min(Positions(i, :), ub);
    end

    Convergence_curve(t) = Alpha_score;
    t = t + 1;
end
end
