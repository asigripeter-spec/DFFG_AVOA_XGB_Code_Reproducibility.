# Stage 1 — DFFG-AVOA Optimization Validation

## Purpose

Stage 1 contains the MATLAB materials used to evaluate the proposed Dynamic Flock Fragmentation and Gaussian-Enhanced African Vultures Optimization Algorithm (DFFG-AVOA) before its use for XGBoost hyperparameter optimization in Stage 2.

Stage 1 is divided into two principal packages:

1. **Ablation_DFFG_AVOA__Package** — controlled mechanism-level ablation study.
2. **Comparators** — comparative mathematical-benchmark and engineering-design studies.

Each package contains its own code, saved experimental results, statistical-analysis materials, figures, logs, and supporting files. Detailed execution instructions are provided in the README inside each package.

## Folder Structure

```text
Stage_1/
│
├── README.md
│
├── Ablation_DFFG_AVOA__Package/
│   ├── README.md
│   └── [ablation source code, raw results, statistical outputs,
│        figures, logs, and supporting files]
│
└── Comparators/
    ├── README.md
    └── [comparative source code, mathematical and engineering
         result packages, statistical-analysis code, and support files]
```

## Stage 1 Experimental Framework

The supplied Stage 1 drivers use the following principal experimental settings for the reported mathematical benchmark studies:

- population size: `N = 30`;
- maximum iterations: `Max_iter = 500`;
- independent runs: `30`;
- mathematical benchmark set: `F1–F23`.

The comparative package also contains the engineering-design experiment covering `E1–E11`.

The exact algorithm parameters, problem definitions, execution modes, and output settings are defined in the supplied MATLAB files and are described further in the package-specific README files.

## 1. Ablation Study

The ablation package evaluates the standard AVOA reference together with seven controlled DFFG-AVOA variants.

The reported full mathematical ablation experiment is driven by:

`DFFG_Main_Ablation_Study.m`

with the supplied configuration set to the full `F1–F23` mathematical benchmark study.

The package contains the raw experimental results and the subsequent analysis materials used to generate and validate the manuscript-facing ablation statistics and tables.

A principal downstream dependency is:

```text
DFFG_Main_Ablation_Study.m
        │
        ▼
DFFG_AVOA_Ablation_Study_RawResults.mat
        │
        ▼
DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4.m
        │
        ▼
statistical, Excel, MAT, log, and Word outputs
```

The supplied raw-results MAT file is therefore not merely an archival output. It is an input to the later statistical-analysis workflow and must be retained.

The ablation folder also contains a recovery workflow for reconstructing the authoritative raw-results MAT file from the saved Excel statistics and log if required. The package-specific README will explain these files and their roles in detail.

## 2. Comparative Benchmark and Engineering Studies

The `Comparators` package contains the proposed DFFG-AVOA implementation together with the comparator algorithms used in the reported study.

The active reported comparison set in the supplied statistical-analysis workflow is:

- DFFG-AVOA;
- AVOA;
- IROAVOA;
- GWO;
- AOA;
- FPA;
- MFO;
- SCA.

The mathematical and engineering experiments are provided as separate configured runs of the comparative master driver:

- `DFFG_Main__Math_Engineering_Benchmarks_4.m` — configured for the full mathematical `F1–F23` study;
- `DFFG_Main__Math_Engineering_Benchmarks_4(1).m` — configured for the full engineering `E1–E11` study.

The corresponding archived result packages are:

- `IDFFG_Master_Study_Math_6New_Corrected.zip`;
- `IDFFG_Master_Study_Eng_6New_Corrected.zip`.

These result packages contain the raw-results MAT files, statistics, logs, figures, and related materials produced by the corresponding experiments.

The downstream comparative statistical-analysis script:

`DFFG_Benchmark_Friedman_Wilcoxon_AOA_Final4_4_1.m`

requires the authoritative mathematical and engineering raw-results MAT files:

```text
IDFFG_Master_Study_Math_6New_Corrected_RawResults.mat
IDFFG_Master_Study_Eng_6New_Corrected_RawResults.mat
```

The detailed `Comparators/README.md` will specify how these files are obtained from the supplied result packages and where they must be placed before the downstream analysis is executed.

## Reproducing Stage 1

Stage 1 supports two related uses.

### Full rerun from source

Users may execute the appropriate MATLAB driver to regenerate the corresponding experiment from the source code.

For the reported studies, the complete runs involve repeated stochastic optimization. A rerun in a different MATLAB, operating-system, or hardware environment should therefore be understood as reproduction of the experimental procedure rather than a guarantee of bit-for-bit identity with every archived numerical result.

After a new full run is completed, the newly generated raw-results files can be supplied to the corresponding downstream statistical-analysis scripts.

### Reproduction and verification from the supplied artifacts

Users who wish to reproduce the downstream statistics, tables, figures, or manuscript-facing outputs associated with the archived study may use the supplied raw-results and supporting files directly.

This is why the generated results, MAT files, logs, workbooks, figures, and related Stage 1 materials have been retained in the package.

## Important File-Retention Rule

**Do not remove files from Stage 1 merely because they appear to be generated results or intermediate outputs.**

Within both the ablation and comparative packages, saved experimental outputs are used by later stages of the analysis or provide the reference artifacts against which the reported results can be verified.

The current Stage 1 package should therefore be treated as an integrated reproducibility record. Any future removal or restructuring of a file should first be checked against the input requirements of the downstream MATLAB scripts.

## MATLAB Requirements

Stage 1 is implemented in MATLAB.

The statistical-analysis scripts use functions including:

- `friedman`;
- `tiedrank`;
- `ranksum`.

These functions require the **Statistics and Machine Learning Toolbox**.

Some manuscript-facing Word or Excel formatting/export functions use Microsoft Office COM automation and therefore depend on a compatible Windows/Microsoft Office environment. The package-specific README files will distinguish the core computational outputs from environment-dependent document-formatting outputs.

## Recommended Reading Order

For Stage 1, use the documentation in this order:

1. Read this `Stage_1/README.md` for the overall structure.
2. Open `Ablation_DFFG_AVOA__Package/README.md` before running or analysing the ablation study.
3. Open `Comparators/README.md` before running or analysing the mathematical benchmark or engineering-design comparison.

The package-specific README files provide the exact script order, input dependencies, output files, and rerun instructions.
