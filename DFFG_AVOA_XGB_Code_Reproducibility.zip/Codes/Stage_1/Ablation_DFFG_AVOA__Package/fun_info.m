function [lb, ub, dim, fobj] = fun_info(F)
    [lb, ub, dim, fobj] = benchmark_functions(F);
end