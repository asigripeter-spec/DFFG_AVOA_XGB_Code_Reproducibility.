function [Best_score, Best_pos, Convergence_curve] = DFFG_AVOA_Ablation(N, Max_iter, lb, ub, dim, fobj, params)
% DFFG_AVOA_Ablation.m
% Dynamic Flock Fragmentation and Gaussian-enhanced African Vultures Optimization Algorithm
%
% Phases implemented:
%   1. Tent-chaotic initialization
%   2. Dynamic Flock Fragmentation (DFF)
%   3. Localized AVOA search within sub-flocks
%   4. G1 Gaussian perturbation
%   5. Standard G2 Gaussian refinement
%   6. Reliability-filtered Alternative-center Boosted G2
%   7. Directional Elite-guided Tightening
%   8. Elite-centroid Contraction
%   9. Elite Reinjection
%  10. Final-best stagnation detection and selective restart
%
% Ablation controls (all default TRUE so the full configuration reproduces DFFG-AVOA):
%   params.use_TC_init               - Tent-chaotic initialization
%   params.use_DFF                   - Dynamic Flock Fragmentation / localized AVOA
%   params.use_G1                    - Gaussian-assisted rotational-flight perturbation
%   params.use_G2                    - Standard + boosted alternative-center G2 refinement
%   params.use_directional_tightening- Elite-guided tightening + centroid contraction
%   params.enable_restart            - Phase-6 elite preservation + selective restart
%
% Signature:
% [Best_score, Best_pos, Convergence_curve] = DFFG_AVOA_Ablation(N, Max_iter, lb, ub, dim, fobj, params)

    %% 0. Input normalization
    if nargin < 7 || isempty(params)
        params = struct();
    end

    lb = normalize_bounds(lb, dim);
    ub = normalize_bounds(ub, dim);

    if any(ub <= lb)
        error('DFFG_AVOA:InvalidBounds', ...
            'Each upper bound must be strictly greater than its lower bound.');
    end

    %% 1. Parameter closure
    p = close_params(params, N, Max_iter);

    %% 2. Initialization (TC on/off for ablation)
    if p.use_TC_init
        P = tent_initialize(N, dim, lb, ub);
    else
        P = random_initialize(N, dim, lb, ub);
    end
    fit = zeros(N, 1);

    for i = 1:N
        fit(i) = safe_eval(fobj, P(i, :));
    end

    [Best_score, best_idx] = min(fit);
    Best_pos = P(best_idx, :);

    Convergence_curve = zeros(1, Max_iter);

    % Running references for DFF
    D_ref_max  = 1e-12;
    F_ref_impr = 1e-12;

    % Final-best stagnation counter
    stagnation_counter = 0;

    %% 3. Main loop
    for t = 1:Max_iter
        Best_before_iter = Best_score;

        %% 3.1-3.2 Dynamic Flock Fragmentation (on/off for ablation)
        if p.use_DFF
            D_flock = safe_mean_pdist(P);

            if t == 1
                Delta_F = 0;
            else
                Delta_F = abs(Best_score - Convergence_curve(max(t - 1, 1)));
            end

            D_ref_max  = max(D_ref_max, D_flock);
            F_ref_impr = max(F_ref_impr, Delta_F);

            decay_term = (1 - t / Max_iter)^p.gamma_K;

            K_calc = p.K_min + (p.K_abs_max - p.K_min) * ...
                ( p.alpha * (D_flock / max(D_ref_max, 1e-12)) + ...
                (1 - p.alpha) * max(0, 1 - (Delta_F / max(F_ref_impr, 1e-12))) ) * decay_term;

            K_t = max(p.K_min, min(round(K_calc), p.K_abs_max));

            sub_idx = safe_partition(P, K_t, p.n_init, p.kmeans_max_iter);

            if isempty(sub_idx) || numel(sub_idx) ~= N
                sub_idx = ones(N, 1);
                K_t = 1;
            end
        else
            % No fragmentation: the whole population is one AVOA flock.
            K_t = 1;
            sub_idx = ones(N, 1);
            D_flock = 0;
        end

        % Best member of each sub-flock after local updates
        subflock_best_idx = nan(K_t, 1);
        subflock_best_fit = inf(K_t, 1);

        %% 3.3 Localized AVOA search
        for s = 1:K_t
            I_s = find(sub_idx == s);
            if isempty(I_s)
                continue;
            end

            [~, ord_local] = sort(fit(I_s), 'ascend');
            idx1 = I_s(ord_local(1));
            X1s = P(idx1, :);

            if numel(I_s) >= 2
                idx2 = I_s(ord_local(2));
                X2s = P(idx2, :);
            else
                X2s = X1s;
            end

            for kk = 1:numel(I_s)
                i = I_s(kk);
                Xi = P(i, :);

                % Leader selection
                if rand < p.L1
                    Ri = X1s;
                else
                    Ri = X2s;
                end

                % Hunger factor
                if p.use_fixed_h
                    hi = p.h_fixed_for_run;
                else
                    hi = -2 + 4 * rand;
                end

                Tosc = hi * (sin((pi / 2) * (t / Max_iter))^p.w + ...
                             cos((pi / 2) * (t / Max_iter)) - 1);
                zr = -1 + 2 * rand;
                Fh = (2 * rand + 1) * zr * (1 - t / Max_iter) + Tosc;

                % Phase switching
                if abs(Fh) >= 1
                    %% Exploration
                    if rand < p.P1
                        Xs = 2 * rand;
                        Ds = abs(Xs .* Ri - Xi);
                        Xnew = Ri - Ds .* Fh;
                    else
                        v  = rand(1, dim);
                        r3 = rand;
                        Xnew = Ri - Fh + v .* ((ub - lb) * r3 + lb);
                    end

                elseif abs(Fh) >= 0.5
                    %% Competition
                    if rand < p.P2
                        Xs = 2 * rand;
                        Ds = abs(Xs .* Ri - Xi);
                        ds = Ri - Xi;
                        Xnew = Ds .* (Fh + rand) - ds;
                    else
                        a = rand(1, dim);
                        b = rand(1, dim);

                        S1 = Ri .* ((a .* Xi) / (2 * pi)) .* cos(Xi);
                        S2 = Ri .* ((b .* Xi) / (2 * pi)) .* sin(Xi);
                        Xspiral = Ri - (S1 + S2);

                        % Late-stage tightening for G1 probability
                        if t >= ceil(p.tightening_start_ratio * Max_iter)
                            Pg1_eff = min(p.P_apply_G1 + p.tightening_delta_Pg1, 1.0);
                        else
                            Pg1_eff = p.P_apply_G1;
                        end

                        sigma_g1 = p.sigma_g1_initial * (1 - t / Max_iter);

                        if p.use_G1 && (rand < Pg1_eff)
                            Xnew = Xspiral + sigma_g1 .* randn(1, dim);
                        else
                            Xnew = Xspiral;
                        end
                    end

                else
                    %% Aggregation
                    if rand < p.P3
                        denom1 = safe_denom(X1s - Xi.^2, p.eps_denom);
                        denom2 = safe_denom(X2s - Xi.^2, p.eps_denom);

                        A1 = X1s - ((X1s .* Xi) ./ denom1) .* Fh;
                        A2 = X2s - ((X2s .* Xi) ./ denom2) .* Fh;

                        Xnew = (A1 + A2) / 2;
                    else
                        L = levy_step(dim, p.beta_levy);
                        ds = Ri - Xi;
                        Xnew = Ri - abs(ds) .* Fh .* L;
                    end
                end

                % Bound handling
                Xnew = min(max(Xnew, lb), ub);

                % Greedy acceptance
                fnew = safe_eval(fobj, Xnew);
                if fnew < fit(i)
                    P(i, :) = Xnew;
                    fit(i) = fnew;
                end
            end

            % Best member of this sub-flock after local updates
            I_s = find(sub_idx == s);
            [best_s_fit, loc_s] = min(fit(I_s));
            subflock_best_fit(s) = best_s_fit;
            subflock_best_idx(s) = I_s(loc_s);
        end

        %% 3.4 Global best update after local search
        [curr_best, curr_idx] = min(fit);
        if curr_best < Best_score
            Best_score = curr_best;
            Best_pos = P(curr_idx, :);
        end

        %% 3.5 Standard G2 around global best
        sigma_g2 = p.sigma_g2_initial * (1 - t / Max_iter)^2;

        if p.use_G2
            if t >= ceil(p.tightening_start_ratio * Max_iter)
                Lg2_eff = p.L_G2 + p.tightening_delta_Lg2;
            else
                Lg2_eff = p.L_G2;
            end

            Xwork = Best_pos;
            Fwork = Best_score;

            for l = 1:Lg2_eff
                Xcand = Xwork + sigma_g2 .* randn(1, dim);
                Xcand = min(max(Xcand, lb), ub);
                Fcand = safe_eval(fobj, Xcand);

                if Fcand < Fwork
                    Xwork = Xcand;
                    Fwork = Fcand;
                end
            end

            if Fwork < Best_score
                Best_score = Fwork;
                Best_pos = Xwork;
            end
        end

        %% 3.6 Reliability-filtered alternative-center boosted G2
        if p.use_G2 && (stagnation_counter >= p.s_boost) && (K_t >= 2)
            [alt_exists, Xalt, Falt] = select_reliable_alt_center( ...
                P, fit, sub_idx, subflock_best_idx, subflock_best_fit, ...
                Best_pos, Best_score, D_flock, p);

            sigma_g2_boost = p.c_sigma * sigma_g2;
            Lg2_boost = max(1, ceil(p.c_L * p.L_G2));

            % Center 1: current global best
            Xwork1 = Best_pos;
            Fwork1 = Best_score;
            for l = 1:Lg2_boost
                Xcand1 = Xwork1 + sigma_g2_boost .* randn(1, dim);
                Xcand1 = min(max(Xcand1, lb), ub);
                Fcand1 = safe_eval(fobj, Xcand1);
                if Fcand1 < Fwork1
                    Xwork1 = Xcand1;
                    Fwork1 = Fcand1;
                end
            end

            best_patch_pos = Xwork1;
            best_patch_fit = Fwork1;

            % Center 2: reliable alternative center
            if alt_exists
                Xwork2 = Xalt;
                Fwork2 = Falt;
                for l = 1:Lg2_boost
                    Xcand2 = Xwork2 + sigma_g2_boost .* randn(1, dim);
                    Xcand2 = min(max(Xcand2, lb), ub);
                    Fcand2 = safe_eval(fobj, Xcand2);
                    if Fcand2 < Fwork2
                        Xwork2 = Xcand2;
                        Fwork2 = Fcand2;
                    end
                end

                if Fwork2 < best_patch_fit
                    best_patch_pos = Xwork2;
                    best_patch_fit = Fwork2;
                end
            end

            if best_patch_fit < Best_score
                Best_score = best_patch_fit;
                Best_pos = best_patch_pos;
            end
        end

        %% 3.7 Directional Elite-guided Tightening + Elite-centroid Contraction
        if p.use_directional_tightening && ...
           (t >= ceil(p.eta_T * Max_iter)) && ...
           (stagnation_counter >= p.s_boost)

            [~, ord_all] = sort(fit, 'ascend');
            Xbest1 = P(ord_all(1), :);

            if N >= 2
                Xbest2 = P(ord_all(2), :);
            else
                Xbest2 = Xbest1;
            end

            if Best_score < fit(ord_all(1))
                Xbest1 = Best_pos;
            end

            u_dir = normalized_direction(Xbest2 - Xbest1, dim, p.eps_denom);
            sigma_par  = p.kappa_parallel * sigma_g2;
            sigma_perp = p.kappa_perp * sigma_g2;

            Xwork = Best_pos;
            Fwork = Best_score;

            % Directional tightening
            for l = 1:p.L_dir
                xi_par  = randn;
                xi_perp = orthogonal_gaussian(u_dir, dim);
                Xcand = Xwork + sigma_par * xi_par * u_dir + sigma_perp * xi_perp;
                Xcand = min(max(Xcand, lb), ub);
                Fcand = safe_eval(fobj, Xcand);

                if Fcand < Fwork
                    Xwork = Xcand;
                    Fwork = Fcand;
                end
            end

            if Fwork < Best_score
                Best_score = Fwork;
                Best_pos = Xwork;
            end

            % Elite-centroid contraction
            Me_eff = min(p.M_e, N);
            elite_ids = ord_all(1:Me_eff);
            C_e = mean(P(elite_ids, :), 1);
            lambda_c = p.lambda_c0 * (1 - t / Max_iter);

            Xwork = Best_pos;
            Fwork = Best_score;

            for l = 1:p.L_contraction
                Xcand = Xwork + lambda_c * (C_e - Xwork) + sigma_perp .* randn(1, dim);
                Xcand = min(max(Xcand, lb), ub);
                Fcand = safe_eval(fobj, Xcand);

                if Fcand < Fwork
                    Xwork = Xcand;
                    Fwork = Fcand;
                end
            end

            if Fwork < Best_score
                Best_score = Fwork;
                Best_pos = Xwork;
            end
        end

        %% 3.8-3.9 Phase 6: elite preservation + selective restart
        if p.enable_restart
            % Elite preservation is treated as part of the SR phase for ablation.
            [P, fit] = elite_reinject(P, fit, Best_pos, Best_score);

            % Re-sync best after reinjection
            [curr_best, curr_idx] = min(fit);
            if curr_best < Best_score
                Best_score = curr_best;
                Best_pos = P(curr_idx, :);
            end

            if stagnation_counter >= p.s_restart
                m_restart = max(1, ceil(p.q_restart * N));
                [~, ord_worst] = sort(fit, 'descend');
                restart_ids = ord_worst(1:m_restart);

                for rr = 1:numel(restart_ids)
                    i = restart_ids(rr);

                    z = rand(1, dim);
                    for j = 1:dim
                        if z(j) < 0.5
                            z(j) = 2 * z(j);
                        else
                            z(j) = 2 * (1 - z(j));
                        end
                    end

                    Xrestart = lb + z .* (ub - lb);
                    Xrestart = min(max(Xrestart, lb), ub);
                    Frestart = safe_eval(fobj, Xrestart);

                    % True overwrite
                    P(i, :) = Xrestart;
                    fit(i) = Frestart;
                end

                % Elite reinjection after restart as well
                [P, fit] = elite_reinject(P, fit, Best_pos, Best_score);

                [curr_best, curr_idx] = min(fit);
                if curr_best < Best_score
                    Best_score = curr_best;
                    Best_pos = P(curr_idx, :);
                end
            end
        end

        %% 3.10 Final stagnation update
        if abs(Best_score - Best_before_iter) <= p.epsilon_stag
            stagnation_counter = stagnation_counter + 1;
        else
            stagnation_counter = 0;
        end

        Convergence_curve(t) = Best_score;
    end
end

%% ============================================================
% LOCAL HELPERS
% ============================================================

function p = close_params(params, N, Max_iter)
    % Ablation controls. Defaults reproduce the complete accepted algorithm.
    p.use_TC_init = logical(get_param(params, 'use_TC_init', true));
    p.use_DFF     = logical(get_param(params, 'use_DFF', true));

    % Backbone
    p.P1 = get_param(params, 'P1', 0.6);
    p.P2 = get_param(params, 'P2', 0.4);
    p.P3 = get_param(params, 'P3', 0.6);
    p.w  = get_param(params, 'w', 2.5);
    p.L1 = get_param(params, 'L1_fixed', 0.8);
    p.beta_levy = get_param(params, 'beta_levy', 1.5);

    % DFF
    p.K_min = max(1, round(get_param(params, 'K_min', 2)));
    p.K_abs_max = max(p.K_min, round(get_param(params, 'K_abs_max', 3)));
    p.alpha = get_param(params, 'alpha', 0.55);
    p.gamma_K = get_param(params, 'gamma_K', 1.0);
    p.n_init = max(1, round(get_param(params, 'n_init', 20)));
    p.kmeans_max_iter = max(10, round(get_param(params, 'kmeans_max_iter', 60)));

    % G1
    p.use_G1 = logical(get_param(params, 'use_G1', true));
    p.P_apply_G1 = get_param(params, 'P_apply_gauss_spiral', 0.15);
    p.sigma_g1_initial = get_param(params, 'sigma_g_spiral_initial', 0.33);

    % G2
    p.use_G2 = logical(get_param(params, 'use_G2', true));
    p.L_G2 = max(1, round(get_param(params, 'L_gauss_iter', 12)));
    p.sigma_g2_initial = get_param(params, 'sigma_g_best_initial', 0.85);

    % Stagnation and patch controls
    p.epsilon_stag = get_param(params, 'epsilon_stag', 1e-12);
    p.s_boost = max(1, round(get_param(params, 's_boost', 8)));
    p.s_restart = max(p.s_boost, round(get_param(params, 's_restart', 10)));
    p.c_L = get_param(params, 'c_L', 2.5);
    p.c_sigma = get_param(params, 'c_sigma', 1.7);

    % Reliability-filtered alternative-center G2
    p.tau_basin = get_param(params, 'tau_basin', 0.40);
    p.omega_f = get_param(params, 'omega_f', 0.75);
    p.omega_d = get_param(params, 'omega_d', 0.25);

    % Directional elite-guided tightening
    p.use_directional_tightening = logical(get_param(params, 'use_directional_tightening', true));
    p.eta_T = min(0.99, max(0.0, get_param(params, 'eta_T', 0.70)));
    p.L_dir = max(1, round(get_param(params, 'L_dir', 8)));
    p.M_e = max(2, round(get_param(params, 'M_e', 3)));
    p.kappa_parallel = max(0.0, get_param(params, 'kappa_parallel', 1.2692));
    p.kappa_perp = max(0.0, get_param(params, 'kappa_perp', 0.25));
    if p.kappa_perp >= p.kappa_parallel
        p.kappa_perp = max(1e-6, 0.5 * p.kappa_parallel);
    end
    p.lambda_c0 = max(0.0, get_param(params, 'lambda_c0', 0.35));
    p.L_contraction = max(1, round(get_param(params, 'L_contraction', 2)));

    % Restart
    p.enable_restart = logical(get_param(params, 'enable_restart', true));
    p.q_restart = min(0.5, max(0.0, get_param(params, 'q_restart', 0.10)));

    % Late-stage tightening
    p.tightening_start_ratio = min(0.99, max(0.0, get_param(params, 'tightening_start_ratio', 0.80)));
    p.tightening_delta_Pg1 = max(0.0, get_param(params, 'tightening_delta_Pg1', 0.05));
    p.tightening_delta_Lg2 = max(0, round(get_param(params, 'tightening_delta_Lg2', 2)));

    % Numerical safety
    p.eps_denom = get_param(params, 'eps_denom', 1e-10);

    % Fixed h if supplied by driver
    if isfield(params, 'h_fixed_for_run') && ~isempty(params.h_fixed_for_run)
        p.use_fixed_h = true;
        p.h_fixed_for_run = params.h_fixed_for_run;
    else
        p.use_fixed_h = false;
        p.h_fixed_for_run = [];
    end

    % Short-budget override if not explicitly set
    if ~isfield(params, 's_boost') && Max_iter <= 30
        p.s_boost = max(3, round(0.2 * Max_iter));
        p.s_restart = p.s_boost + 1;
    end
end

function val = get_param(params, name, default_val)
    if isfield(params, name) && ~isempty(params.(name))
        val = params.(name);
    else
        val = default_val;
    end
end

function b = normalize_bounds(x, dim)
    if isscalar(x)
        b = repmat(x, 1, dim);
    else
        b = reshape(x, 1, []);
        if numel(b) ~= dim
            error('DFFG_AVOA:BoundsLength', 'Bounds must be scalar or length = dim.');
        end
    end
end

function P = random_initialize(N, dim, lb, ub)
    P = lb + rand(N, dim) .* (ub - lb);
end

function P = tent_initialize(N, dim, lb, ub)
    P = zeros(N, dim);
    for j = 1:dim
        z = rand;
        for i = 1:N
            if z < 0.5
                z = 2 * z;
            else
                z = 2 * (1 - z);
            end
            P(i, j) = lb(j) + z * (ub(j) - lb(j));
        end
    end
end

function val = safe_eval(fobj, x)
    val = fobj(x);
    if ~isscalar(val) || ~isfinite(val)
        error('DFFG_AVOA:InvalidObjectiveValue', ...
            'Objective function must return a finite scalar.');
    end
end

function d = safe_mean_pdist(P)
    N = size(P, 1);
    if N <= 1
        d = 0;
        return;
    end

    if exist('pdist', 'file') == 2
        pd = pdist(P);
        if isempty(pd)
            d = 0;
        else
            d = mean(pd);
        end
        return;
    end

    total = 0;
    count = 0;
    for i = 1:N-1
        Pi = P(i, :);
        for j = i+1:N
            total = total + norm(Pi - P(j, :), 2);
            count = count + 1;
        end
    end

    if count == 0
        d = 0;
    else
        d = total / count;
    end
end

function sub_idx = safe_partition(P, K_t, n_init, kmeans_max_iter)
    N = size(P, 1);

    if K_t <= 1 || N <= 1
        sub_idx = ones(N, 1);
        return;
    end

    K_t = min(K_t, N);

    if exist('kmeans', 'file') == 2
        try
            sub_idx = kmeans(P, K_t, ...
                'MaxIter', kmeans_max_iter, ...
                'Replicates', n_init, ...
                'Display', 'off', ...
                'EmptyAction', 'singleton');
            return;
        catch
        end
    end

    % Fallback partition if kmeans is unavailable
    scores = sum(P, 2);
    [~, ord] = sort(scores, 'ascend');
    sub_idx = ones(N, 1);
    edges = round(linspace(0, N, K_t + 1));

    for s = 1:K_t
        ids = ord(edges(s) + 1 : edges(s + 1));
        sub_idx(ids) = s;
    end
end

function denom_safe = safe_denom(denom, eps_denom)
    denom_safe = denom;
    small = abs(denom_safe) < eps_denom;
    signs = sign(denom_safe);
    signs(signs == 0) = 1;
    denom_safe(small) = eps_denom .* signs(small);
end

function L = levy_step(dim, beta_levy)
    sigma = (gamma(1 + beta_levy) * sin(pi * beta_levy / 2) / ...
        (gamma((1 + beta_levy) / 2) * beta_levy * 2^((beta_levy - 1) / 2)))^(1 / beta_levy);

    u = randn(1, dim) * sigma;
    v = randn(1, dim);
    L = 0.01 * (u ./ (abs(v).^(1 / beta_levy)));
end

function [alt_exists, Xalt, Falt] = select_reliable_alt_center( ...
    P, fit, sub_idx, subflock_best_idx, subflock_best_fit, Best_pos, Best_score, D_flock, p)

    K_t = numel(subflock_best_idx);

    [~, best_global_idx] = min(fit);
    best_global_subflock = sub_idx(best_global_idx);

    candidate_subflocks = setdiff(1:K_t, best_global_subflock);

    alt_exists = false;
    Xalt = [];
    Falt = inf;

    if isempty(candidate_subflocks)
        return;
    end

    FworstElite = max(subflock_best_fit(isfinite(subflock_best_fit)));
    if isempty(FworstElite) || ~isfinite(FworstElite)
        return;
    end

    best_R = -inf;
    Dsafe = max(D_flock, p.eps_denom);

    for q = candidate_subflocks
        idxq = subflock_best_idx(q);
        Fq = subflock_best_fit(q);

        if isnan(idxq) || idxq < 1 || idxq > size(P, 1) || ~isfinite(Fq)
            continue;
        end

        Xq = P(idxq, :);

        Delta_q = norm(Xq - Best_pos, 2) / Dsafe;
        if Delta_q < p.tau_basin
            continue;
        end

        Qq = (FworstElite - Fq) / (FworstElite - Best_score + p.eps_denom);
        Qq = max(0, min(1, Qq));

        Rq = p.omega_f * Qq + p.omega_d * min(Delta_q, 1.0);

        if Rq > best_R
            best_R = Rq;
            alt_exists = true;
            Xalt = Xq;
            Falt = Fq;
        end
    end
end

function u = normalized_direction(v, dim, eps_denom)
    nv = norm(v, 2);
    if ~isfinite(nv) || nv <= eps_denom
        u = zeros(1, dim);
        if dim >= 1
            u(1) = 1;
        end
    else
        u = v / nv;
    end
end

function xi_perp = orthogonal_gaussian(u, dim)
    g = randn(1, dim);
    xi_perp = g - (g * u') * u;
end

function [P, fit] = elite_reinject(P, fit, Best_pos, Best_score)
    % If the accepted elite is not present in the live population,
    % replace the current worst agent with the elite.
    tol = 1e-14;

    if isempty(P) || isempty(fit)
        return;
    end

    elite_present = false;
    for i = 1:size(P, 1)
        if norm(P(i, :) - Best_pos, 2) <= tol
            elite_present = true;
            break;
        end
    end

    if ~elite_present
        [~, worst_idx] = max(fit);
        P(worst_idx, :) = Best_pos;
        fit(worst_idx) = Best_score;
    end
end