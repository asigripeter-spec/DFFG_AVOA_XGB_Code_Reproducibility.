Place DFFG_AVOA_Ablation_Recover_RawResults_From_Excel_Log.m in the same
folder as:

    DFFG_AVOA_Ablation_Study_Statistics.xlsx
    DFFG_AVOA_Ablation_Study_Log.txt

Run the MATLAB script.

It will create:

    DFFG_AVOA_Ablation_Study_RawResults.mat
    DFFG_AVOA_Ablation_Study_RawResults_Recovery_Log.txt

and, only if recovery fails:

    DFFG_AVOA_Ablation_Study_RawResults_Recovery_Error.mat

The recovered MAT is the FIRST MAT in the ablation workflow: the recovered
experimental/raw-results authority.

Later, the dedicated manuscript Table 10 workflow will create a SECOND MAT
containing Table 10 analysis/output data. The two MATs therefore have
different roles and should both remain in the ablation study folder.
