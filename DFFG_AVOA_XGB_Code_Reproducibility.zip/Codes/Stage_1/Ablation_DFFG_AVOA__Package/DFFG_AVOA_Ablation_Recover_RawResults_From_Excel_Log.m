%% DFFG_AVOA_Ablation_Recover_RawResults_From_Excel_Log.m
% -------------------------------------------------------------------------
% PURPOSE
%   Reconstruct the raw-results MAT file that the completed DFFG-AVOA
%   ablation driver intended to save as:
%
%       DFFG_AVOA_Ablation_Study_RawResults.mat
%
%   The original optimization itself is NOT rerun.
%
%   Numerical recovery uses BOTH surviving experiment outputs:
%       1) DFFG_AVOA_Ablation_Study_Statistics.xlsx
%       2) DFFG_AVOA_Ablation_Study_Log.txt
%
% RECOVERY PRINCIPLE
%   - Excel is retained as the higher-precision numerical authority wherever
%     a raw score is nonzero in Excel.
%   - The final COMPLETE log session is independently parsed and checked.
%   - If Excel contains 0 but the corresponding final-run log entry contains
%     a nonzero subnormal value, the log value restores that raw score.
%   - Mean, population Std, Best and Rank stored in the workbook are validated
%     against the reconstructed 30-run raw values before the MAT is saved.
%   - Convergence histories, best-position vectors and best-design vectors were
%     not exported to Excel or the log. They therefore remain EMPTY cell
%     placeholders; no values are fabricated.
%
% OUTPUT
%   DFFG_AVOA_Ablation_Study_RawResults.mat      (MATLAB -v7.3)
%   DFFG_AVOA_Ablation_Study_RawResults_Recovery_Log.txt
%   DFFG_AVOA_Ablation_Study_RawResults_Recovery_Error.mat (failure only)
%
% The variable names intentionally follow the save block in the accepted
% DFFG_Main_Ablation_Study.m as closely as the surviving evidence permits.
% -------------------------------------------------------------------------

clear; clc;

%% 0. PATHS AND RECOVERY LOG
script_full = mfilename('fullpath');
if isempty(script_full)
    base_dir = pwd;
else
    base_dir = fileparts(script_full);
end

input_excel = fullfile(base_dir, 'DFFG_AVOA_Ablation_Study_Statistics.xlsx');
input_log   = fullfile(base_dir, 'DFFG_AVOA_Ablation_Study_Log.txt');
output_mat  = fullfile(base_dir, 'DFFG_AVOA_Ablation_Study_RawResults.mat');
recovery_log_filename = fullfile(base_dir, ...
    'DFFG_AVOA_Ablation_Study_RawResults_Recovery_Log.txt');
error_mat = fullfile(base_dir, ...
    'DFFG_AVOA_Ablation_Study_RawResults_Recovery_Error.mat');

try
    diary off;
catch
end
if exist(recovery_log_filename, 'file')
    delete(recovery_log_filename);
end
diary(recovery_log_filename);
diary on;

fprintf('======================================================================\n');
fprintf('DFFG-AVOA ABLATION RAW-RESULTS MAT RECOVERY\n');
fprintf('Started: %s\n', datestr(now));
fprintf('Excel:   %s\n', input_excel);
fprintf('Log:     %s\n', input_log);
fprintf('Output:  %s\n', output_mat);
fprintf('======================================================================\n\n');

try
    %% 1. REQUIRED INPUTS
    assert(exist(input_excel, 'file') == 2, 'Missing Excel input: %s', input_excel);
    assert(exist(input_log, 'file') == 2, 'Missing study log: %s', input_log);

    %% 2. RECREATE FROZEN STUDY METADATA FROM THE ACCEPTED DRIVER
    study_name   = 'DFFG_AVOA_Ablation_Study';
    log_filename = 'DFFG_AVOA_Ablation_Study_Log.txt';
    excel_filename = 'DFFG_AVOA_Ablation_Study_Statistics.xlsx';
    figures_directory = 'DFFG_AVOA_Ablation_Study_Figures';
    composite_plots_directory = 'DFFG_AVOA_Ablation_Study_Composite_Plots';

    problem_family  = 'Math';
    experiment_mode = 'full';

    N        = 30;
    Max_iter = 500;
    num_runs = 30;

    benchmark_functions_names = arrayfun(@(x) sprintf('F%d', x), 1:23, ...
        'UniformOutput', false);

    expected_algorithms = { ...
        'AVOA', ...
        'DFFG-AVOA1', ...
        'DFFG-AVOA2', ...
        'DFFG-AVOA3', ...
        'DFFG-AVOA4', ...
        'DFFG-AVOA5', ...
        'DFFG-AVOA6', ...
        'DFFG-AVOA7'};

    configurations = {
        'AVOA',        {'call_AVOA',          {0}};
        'DFFG-AVOA1',  {'call_DFFG_ABLATION', {1}};
        'DFFG-AVOA2',  {'call_DFFG_ABLATION', {2}};
        'DFFG-AVOA3',  {'call_DFFG_ABLATION', {3}};
        'DFFG-AVOA4',  {'call_DFFG_ABLATION', {4}};
        'DFFG-AVOA5',  {'call_DFFG_ABLATION', {5}};
        'DFFG-AVOA6',  {'call_DFFG_ABLATION', {6}};
        'DFFG-AVOA7',  {'call_DFFG_ABLATION', {7}};
    };

    ablation_definitions = {
        'Variant','Experimental Name','Interpretation','TC','DFF','G1','G2','EGT','SR';
        'V0','AVOA','Original AVOA reference',                         0,0,0,0,0,0;
        'V1','DFFG-AVOA1','TC-AVOA',                                  1,0,0,0,0,0;
        'V2','DFFG-AVOA2','TC-DFF-AVOA',                              1,1,0,0,0,0;
        'V3','DFFG-AVOA3','TC-DFF-G1-AVOA',                           1,1,1,0,0,0;
        'V4','DFFG-AVOA4','TC-DFF-G2-AVOA',                           1,1,0,1,0,0;
        'V5','DFFG-AVOA5','TC-DFF-EGT-AVOA',                          1,1,0,0,1,0;
        'V6','DFFG-AVOA6','TC-DFF-SR-AVOA',                           1,1,0,0,0,1;
        'V7','DFFG-AVOA7','Full proposed DFFG-AVOA',                  1,1,1,1,1,1;
    };

    global_optima_definitions = { ...
        'F1',0; 'F2',0; 'F3',0; 'F4',0; 'F5',0; 'F6',0; 'F7',0; ...
        'F8',-418.9829*30; 'F9',0; 'F10',0; 'F11',0; 'F12',0; 'F13',0; ...
        'F14',1; 'F15',0.0003075; 'F16',-1.031628; 'F17',0.397887; ...
        'F18',3; 'F19',-3.86278; 'F20',-3.32237; 'F21',-10.1532; ...
        'F22',-10.4029; 'F23',-10.5364 };

    param_avoa.P1        = 0.6;
    param_avoa.P2        = 0.4;
    param_avoa.P3        = 0.6;
    param_avoa.w         = 2.5;
    param_avoa.beta_levy = 1.5;
    param_avoa.L1_fixed  = 0.8;

    param_dffg_avoa = param_avoa;
    param_dffg_avoa.K_min     = 2;
    param_dffg_avoa.K_abs_max = 3;
    param_dffg_avoa.alpha     = 0.55;
    param_dffg_avoa.gamma_K   = 1.0;
    param_dffg_avoa.use_TC_init                = true;
    param_dffg_avoa.use_DFF                    = true;
    param_dffg_avoa.n_init                     = 20;
    param_dffg_avoa.kmeans_max_iter            = 60;
    param_dffg_avoa.epsilon_stag               = 1e-12;
    param_dffg_avoa.s_boost                    = 8;
    param_dffg_avoa.s_restart                  = 10;
    param_dffg_avoa.P_apply_gauss_spiral       = 0.15;
    param_dffg_avoa.sigma_g_spiral_initial     = 0.33;
    param_dffg_avoa.L_gauss_iter               = 12;
    param_dffg_avoa.sigma_g_best_initial       = 0.85;
    param_dffg_avoa.tau_basin                  = 0.40;
    param_dffg_avoa.omega_f                    = 0.75;
    param_dffg_avoa.omega_d                    = 0.25;
    param_dffg_avoa.c_L                        = 2.5;
    param_dffg_avoa.c_sigma                    = 1.7;
    param_dffg_avoa.tightening_start_ratio     = 0.80;
    param_dffg_avoa.tightening_delta_Pg1       = 0.05;
    param_dffg_avoa.tightening_delta_Lg2       = 2;
    param_dffg_avoa.eps_denom                  = 1e-10;
    param_dffg_avoa.use_directional_tightening = true;
    param_dffg_avoa.eta_T                      = 0.70;
    param_dffg_avoa.L_dir                      = 8;
    param_dffg_avoa.M_e                        = 3;
    param_dffg_avoa.kappa_parallel             = 1.2692;
    param_dffg_avoa.kappa_perp                 = 0.249;
    param_dffg_avoa.lambda_c0                  = 0.35;
    param_dffg_avoa.L_contraction              = 2;
    param_dffg_avoa.enable_restart             = true;
    param_dffg_avoa.q_restart                  = 0.10;

    num_benchmarks = 23;
    num_algorithms = 8;

    %% 3. READ ALL RAW AND SUMMARY VALUES FROM EXCEL
    fprintf('[1/7] Reading and validating Excel workbook...\n');

    excel_raw  = nan(num_benchmarks, num_algorithms, num_runs);
    excel_mean = nan(num_benchmarks, num_algorithms);
    excel_std  = nan(num_benchmarks, num_algorithms);
    excel_best = nan(num_benchmarks, num_algorithms);
    excel_rank = nan(num_benchmarks, num_algorithms);

    sheet_names = sheetnames(input_excel);
    for f_idx = 1:num_benchmarks
        fname = benchmark_functions_names{f_idx};
        assert(any(strcmp(sheet_names, fname)), 'Missing Excel sheet: %s', fname);

        C = readcell(input_excel, 'Sheet', fname);

        for a_idx = 1:num_algorithms
            row_idx = findFirstColumnLabel(C, expected_algorithms{a_idx});
            assert(~isempty(row_idx), 'Missing %s raw row on sheet %s.', ...
                expected_algorithms{a_idx}, fname);

            for r = 1:num_runs
                excel_raw(f_idx, a_idx, r) = numericCell(C{row_idx, r + 1}, ...
                    sprintf('%s %s Run %d', fname, expected_algorithms{a_idx}, r));
            end
        end

        mean_row = findFirstColumnLabel(C, 'Mean');
        std_row  = findFirstColumnLabel(C, 'Std');
        best_row = findFirstColumnLabel(C, 'Best');
        rank_row = findFirstColumnLabel(C, 'Rank');
        assert(~isempty(mean_row) && ~isempty(std_row) && ...
               ~isempty(best_row) && ~isempty(rank_row), ...
               'Missing summary rows on sheet %s.', fname);

        for a_idx = 1:num_algorithms
            excel_mean(f_idx, a_idx) = numericCell(C{mean_row, a_idx + 1}, ...
                sprintf('%s Mean %s', fname, expected_algorithms{a_idx}));
            excel_std(f_idx, a_idx) = numericCell(C{std_row, a_idx + 1}, ...
                sprintf('%s Std %s', fname, expected_algorithms{a_idx}));
            excel_best(f_idx, a_idx) = numericCell(C{best_row, a_idx + 1}, ...
                sprintf('%s Best %s', fname, expected_algorithms{a_idx}));
            excel_rank(f_idx, a_idx) = numericCell(C{rank_row, a_idx + 1}, ...
                sprintf('%s Rank %s', fname, expected_algorithms{a_idx}));
        end
    end

    assert(all(isfinite(excel_raw(:))), 'Excel raw-score cube contains NaN/Inf.');
    fprintf('      PASS: 23 functions x 8 algorithms x 30 runs recovered from Excel.\n');

    %% 4. PARSE THE FINAL COMPLETE STUDY SESSION FROM THE LOG
    fprintf('[2/7] Parsing the final complete study session from the log...\n');

    log_text = fileread(input_log);
    start_marker = 'DFFG-AVOA ablation study started at';
    end_marker   = 'Experiment complete at';
    starts = strfind(log_text, start_marker);
    ends_  = strfind(log_text, end_marker);
    assert(~isempty(starts), 'No study-start marker found in the log.');
    assert(~isempty(ends_), 'No completed experiment marker found in the log.');

    last_complete_pos = ends_(end);
    eligible_starts = starts(starts < last_complete_pos);
    assert(~isempty(eligible_starts), 'No complete run start precedes the final completion marker.');
    final_start_pos = eligible_starts(end);
    final_log = log_text(final_start_pos:end);

    function_tokens = regexp(final_log, ...
        'Processing Function:\s+(F\d+)', 'tokens');
    assert(numel(function_tokens) == num_benchmarks, ...
        'Expected 23 function blocks in final log; found %d.', numel(function_tokens));
    for f_idx = 1:num_benchmarks
        assert(strcmp(function_tokens{f_idx}{1}, benchmark_functions_names{f_idx}), ...
            'Function sequence mismatch in final log at position %d.', f_idx);
    end

    run_tokens = regexp(final_log, ...
        'Run\s+(\d+)/30\s+Best\s+\(([^)]+)\):\s+([-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)', ...
        'tokens');

    expected_count = num_benchmarks * num_algorithms * num_runs;
    assert(numel(run_tokens) == expected_count, ...
        'Expected %d run records in final log; found %d.', ...
        expected_count, numel(run_tokens));

    log_raw = nan(num_benchmarks, num_algorithms, num_runs);
    t = 0;
    for f_idx = 1:num_benchmarks
        for a_idx = 1:num_algorithms
            for r = 1:num_runs
                t = t + 1;
                token = run_tokens{t};
                parsed_run = str2double(token{1});
                parsed_algorithm = strtrim(token{2});
                parsed_value = str2double(token{3});

                assert(parsed_run == r, ...
                    'Run-order mismatch in final log at function %d, algorithm %s.', ...
                    f_idx, expected_algorithms{a_idx});
                assert(strcmp(parsed_algorithm, expected_algorithms{a_idx}), ...
                    'Algorithm-order mismatch in final log at function %d: expected %s, found %s.', ...
                    f_idx, expected_algorithms{a_idx}, parsed_algorithm);
                assert(isfinite(parsed_value), 'Nonfinite raw value parsed from final log.');

                log_raw(f_idx, a_idx, r) = parsed_value;
            end
        end
    end

    start_time_token = regexp(final_log, ...
        'DFFG-AVOA ablation study started at\s+([^\r\n]+)', 'tokens', 'once');
    end_time_token = regexp(final_log, ...
        'Experiment complete at\s+([^\r\n]+)', 'tokens', 'once');
    if isempty(start_time_token), final_session_start = ''; else, final_session_start = strtrim(start_time_token{1}); end
    if isempty(end_time_token), final_session_end = ''; else, final_session_end = strtrim(end_time_token{1}); end

    fprintf('      PASS: %d raw run values parsed from final complete log session.\n', expected_count);
    fprintf('      Session: %s -> %s\n', final_session_start, final_session_end);

    %% 5. CROSS-VALIDATE EXCEL AGAINST LOG AND RESTORE LOST SUBNORMAL VALUES
    fprintf('[3/7] Cross-validating Excel raw values against the final log...\n');

    both_nonzero = (excel_raw ~= 0) & (log_raw ~= 0);
    denominator = max(abs(excel_raw(both_nonzero)), abs(log_raw(both_nonzero)));
    rel_diffs = abs(excel_raw(both_nonzero) - log_raw(both_nonzero)) ./ denominator;
    if isempty(rel_diffs)
        max_excel_log_relative_difference = 0;
    else
        max_excel_log_relative_difference = max(rel_diffs);
    end
    assert(max_excel_log_relative_difference <= 1e-8, ...
        'Excel/log disagreement exceeds tolerance. Maximum relative difference = %.3e', ...
        max_excel_log_relative_difference);

    recovered_raw_score_cube = excel_raw;
    log_restore_mask = (excel_raw == 0) & (log_raw ~= 0);
    recovered_raw_score_cube(log_restore_mask) = log_raw(log_restore_mask);
    recovered_subnormal_count = nnz(log_restore_mask);

    raw_score_source_map = ones(size(recovered_raw_score_cube), 'uint8');
    raw_score_source_map(log_restore_mask) = uint8(2);

    fprintf('      PASS: nonzero Excel/log values agree (max relative difference %.3e).\n', ...
        max_excel_log_relative_difference);
    fprintf('      Restored %d nonzero raw value(s) from the log where Excel contained zero.\n', ...
        recovered_subnormal_count);

    %% 6. RECOMPUTE STATISTICS FROM RECOVERED RAW SCORES AND VALIDATE EXCEL SUMMARY
    fprintf('[4/7] Recomputing statistics and validating workbook summary rows...\n');

    recomputed_mean = mean(recovered_raw_score_cube, 3);
    centered = recovered_raw_score_cube - recomputed_mean;
    recomputed_std_population = sqrt(sum(centered.^2, 3) / num_runs);
    recomputed_best = min(recovered_raw_score_cube, [], 3);
    recomputed_max  = max(recovered_raw_score_cube, [], 3);

    optimum_vector = nan(num_benchmarks, 1);
    for f_idx = 1:num_benchmarks
        optimum_vector(f_idx) = global_optima_definitions{f_idx, 2};
    end
    recomputed_mae = nan(num_benchmarks, num_algorithms);
    for f_idx = 1:num_benchmarks
        for a_idx = 1:num_algorithms
            scores = squeeze(recovered_raw_score_cube(f_idx, a_idx, :));
            recomputed_mae(f_idx, a_idx) = mean(abs(scores - optimum_vector(f_idx)));
        end
    end

    recomputed_rank = strictLexicographicRanks(recomputed_mean, ...
        recomputed_std_population, recomputed_best);

    practical_zero = 1e-300;
    [max_mean_relative_difference, max_mean_abs_practical_zero] = ...
        validationDifference(recomputed_mean, excel_mean, practical_zero);
    [max_std_relative_difference, max_std_abs_practical_zero] = ...
        validationDifference(recomputed_std_population, excel_std, practical_zero);
    [max_best_relative_difference, max_best_abs_practical_zero] = ...
        validationDifference(recomputed_best, excel_best, practical_zero);
    rank_mismatch_count = nnz(recomputed_rank ~= excel_rank);

    assert(max_mean_relative_difference <= 1e-8 && ...
           max_mean_abs_practical_zero <= practical_zero, ...
        ['Recovered raw means do not validate against Excel summary. ' ...
         'Max rel diff %.3e; practical-zero max abs diff %.3e.'], ...
        max_mean_relative_difference, max_mean_abs_practical_zero);
    assert(max_std_relative_difference <= 1e-8 && ...
           max_std_abs_practical_zero <= practical_zero, ...
        ['Recovered raw population Std values do not validate against Excel summary. ' ...
         'Max rel diff %.3e; practical-zero max abs diff %.3e.'], ...
        max_std_relative_difference, max_std_abs_practical_zero);
    assert(max_best_relative_difference <= 1e-8 && ...
           max_best_abs_practical_zero <= practical_zero, ...
        ['Recovered raw Best values do not validate against Excel summary. ' ...
         'Max rel diff %.3e; practical-zero max abs diff %.3e.'], ...
        max_best_relative_difference, max_best_abs_practical_zero);
    assert(rank_mismatch_count == 0, ...
        'Recovered strict lexicographic ranks differ from Excel in %d cell(s).', ...
        rank_mismatch_count);

    fprintf('      PASS: Mean validation, max rel diff = %.3e; practical-zero abs = %.3e\n', ...
        max_mean_relative_difference, max_mean_abs_practical_zero);
    fprintf('      PASS: Std validation,  max rel diff = %.3e; practical-zero abs = %.3e\n', ...
        max_std_relative_difference, max_std_abs_practical_zero);
    fprintf('      PASS: Best validation, max rel diff = %.3e; practical-zero abs = %.3e\n', ...
        max_best_relative_difference, max_best_abs_practical_zero);
    fprintf('      PASS: Rank validation, mismatch count = %d\n', rank_mismatch_count);

    %% 7. REBUILD THE ORIGINAL RAW-RESULTS VARIABLE SCHEMA
    fprintf('[5/7] Rebuilding raw-results MAT variable schema...\n');

    all_best_scores_raw = cell(num_algorithms, 1);
    all_convergence_curves_cell = cell(num_algorithms, 1);
    all_best_positions_cell = cell(num_algorithms, 1);

    for a_idx = 1:num_algorithms
        all_best_scores_raw{a_idx} = squeeze(recovered_raw_score_cube(:, a_idx, :));
        all_convergence_curves_cell{a_idx} = cell(num_benchmarks, num_runs);
        all_best_positions_cell{a_idx} = cell(num_benchmarks, num_runs);
    end

    % Recreate the same statistics that the original driver computed in memory.
    % The hybrid raw cube retains full Excel precision wherever available and
    % restores only Excel-collapsed nonzero subnormal values from the final log.
    % This also restores tiny nonzero means that Excel itself may display/store as 0.
    all_mean_results = recomputed_mean;
    all_std_results  = recomputed_std_population;
    all_min_results  = recomputed_best;
    all_max_results  = recomputed_max;
    all_mae_results  = recomputed_mae;
    all_rank_results = recomputed_rank;

    % Position-dependent outputs cannot be recovered from Excel/log.
    all_best_designs = cell(num_benchmarks, num_algorithms);

    recovery_provenance = struct();
    recovery_provenance.is_reconstructed = true;
    recovery_provenance.reason = ...
        'Original ablation optimization completed, but final MAT save failed because ablation_definitions was not found at save time.';
    recovery_provenance.source_excel = excel_filename;
    recovery_provenance.source_log = log_filename;
    recovery_provenance.source_driver = 'DFFG_Main_Ablation_Study.m';
    recovery_provenance.final_complete_log_session_start = final_session_start;
    recovery_provenance.final_complete_log_session_end = final_session_end;
    recovery_provenance.expected_raw_values = expected_count;
    recovery_provenance.parsed_log_raw_values = numel(run_tokens);
    recovery_provenance.log_restored_excel_zero_nonzero_cells = recovered_subnormal_count;
    recovery_provenance.raw_source_code = ...
        'raw_score_source_map: 1=Excel retained; 2=final study log used because Excel was zero and log was nonzero.';
    recovery_provenance.numeric_rule = ...
        'Excel retained wherever nonzero; final complete log used only to restore nonzero values collapsed to zero by Excel.';
    recovery_provenance.unavailable_fields = { ...
        'all_convergence_curves_cell contains empty placeholders', ...
        'all_best_positions_cell contains empty placeholders', ...
        'all_best_designs contains empty placeholders'};

    recovery_validation = struct();
    recovery_validation.all_23_functions_present = true;
    recovery_validation.all_8_algorithms_present = true;
    recovery_validation.all_30_runs_present = true;
    recovery_validation.log_sequence_pass = true;
    recovery_validation.excel_log_nonzero_agreement_pass = true;
    recovery_validation.max_excel_log_relative_difference_nonzero = ...
        max_excel_log_relative_difference;
    recovery_validation.mean_validation_pass = true;
    recovery_validation.std_validation_pass = true;
    recovery_validation.best_validation_pass = true;
    recovery_validation.rank_validation_pass = true;
    recovery_validation.practical_zero_threshold = practical_zero;
    recovery_validation.max_mean_relative_difference = max_mean_relative_difference;
    recovery_validation.max_mean_abs_practical_zero = max_mean_abs_practical_zero;
    recovery_validation.max_std_relative_difference = max_std_relative_difference;
    recovery_validation.max_std_abs_practical_zero = max_std_abs_practical_zero;
    recovery_validation.max_best_relative_difference = max_best_relative_difference;
    recovery_validation.max_best_abs_practical_zero = max_best_abs_practical_zero;
    recovery_validation.rank_mismatch_count = rank_mismatch_count;

    %% 8. SAVE AS THE ORIGINAL INTENDED MAT FILENAME
    fprintf('[6/7] Saving recovered raw-results MAT (-v7.3)...\n');

    temp_mat = [output_mat, '.tmp.mat'];
    if exist(temp_mat, 'file'), delete(temp_mat); end

    save(temp_mat, ...
        'study_name', ...
        'log_filename', ...
        'excel_filename', ...
        'figures_directory', ...
        'composite_plots_directory', ...
        'benchmark_functions_names', ...
        'configurations', ...
        'ablation_definitions', ...
        'param_avoa', ...
        'param_dffg_avoa', ...
        'problem_family', ...
        'experiment_mode', ...
        'N', ...
        'Max_iter', ...
        'num_runs', ...
        'all_best_scores_raw', ...
        'all_convergence_curves_cell', ...
        'all_best_positions_cell', ...
        'all_mean_results', ...
        'all_std_results', ...
        'all_mae_results', ...
        'all_min_results', ...
        'all_max_results', ...
        'all_rank_results', ...
        'all_best_designs', ...
        'global_optima_definitions', ...
        'recovery_provenance', ...
        'recovery_validation', ...
        'raw_score_source_map', ...
        'recovered_raw_score_cube', ...
        '-v7.3');

    if exist(output_mat, 'file')
        delete(output_mat);
    end
    movefile(temp_mat, output_mat, 'f');
    assert(exist(output_mat, 'file') == 2, 'Recovered MAT was not created.');

    %% 9. LOAD-BACK VALIDATION
    fprintf('[7/7] Load-back validation of recovered MAT...\n');
    S = load(output_mat, 'N', 'Max_iter', 'num_runs', ...
        'benchmark_functions_names', 'configurations', ...
        'all_best_scores_raw', 'all_mean_results', 'all_std_results', ...
        'all_min_results', 'all_rank_results', 'recovery_validation');

    assert(S.N == 30 && S.Max_iter == 500 && S.num_runs == 30, ...
        'Load-back parameter validation failed.');
    assert(numel(S.benchmark_functions_names) == 23, ...
        'Load-back benchmark count validation failed.');
    assert(size(S.configurations, 1) == 8, ...
        'Load-back configuration count validation failed.');
    assert(numel(S.all_best_scores_raw) == 8, ...
        'Load-back raw-score cell count validation failed.');
    assert(isequal(size(S.all_mean_results), [23 8]), ...
        'Load-back mean matrix dimensions are incorrect.');
    assert(isequal(size(S.all_std_results), [23 8]), ...
        'Load-back Std matrix dimensions are incorrect.');
    assert(isequal(size(S.all_min_results), [23 8]), ...
        'Load-back Best matrix dimensions are incorrect.');
    assert(isequal(size(S.all_rank_results), [23 8]), ...
        'Load-back Rank matrix dimensions are incorrect.');

    fprintf('\n======================================================================\n');
    fprintf('RECOVERY STATUS: PASS\n');
    fprintf('Recovered MAT: %s\n', output_mat);
    fprintf('Functions:      23\n');
    fprintf('Algorithms:     8\n');
    fprintf('Runs/algorithm: 30 per function\n');
    fprintf('Raw values:     %d\n', expected_count);
    fprintf('Log-restored Excel-zero values: %d\n', recovered_subnormal_count);
    fprintf('Convergence curves / positions / designs: unavailable; empty placeholders only.\n');
    fprintf('Completed: %s\n', datestr(now));
    fprintf('======================================================================\n');

    diary off;

catch ME
    fprintf('\n======================================================================\n');
    fprintf('RECOVERY STATUS: FAIL\n');
    fprintf('Error: %s\n', ME.message);
    fprintf('======================================================================\n');

    error_identifier = ME.identifier;
    error_message = ME.message;
    error_stack = ME.stack;
    recovery_failed_at = datestr(now);

    try
        save(error_mat, 'error_identifier', 'error_message', ...
            'error_stack', 'recovery_failed_at');
    catch
    end

    diary off;
    rethrow(ME);
end

%% LOCAL FUNCTIONS

function row_idx = findFirstColumnLabel(C, target)
    row_idx = [];
    if isempty(C), return; end
    for r = 1:size(C, 1)
        v = C{r, 1};
        if ischar(v) || (isstring(v) && isscalar(v))
            if strcmp(strtrim(char(string(v))), target)
                row_idx = r;
                return;
            end
        end
    end
end

function value = numericCell(v, context)
    if isnumeric(v) && isscalar(v)
        value = double(v);
    elseif islogical(v) && isscalar(v)
        value = double(v);
    elseif ischar(v) || (isstring(v) && isscalar(v))
        value = str2double(string(v));
    else
        value = NaN;
    end
    assert(isfinite(value), 'Expected finite numeric value at %s.', context);
end

function [max_rel_large, max_abs_small] = validationDifference(A, B, practical_zero)
    assert(isequal(size(A), size(B)), 'validationDifference size mismatch.');
    scale = max(abs(A), abs(B));
    large = scale > practical_zero;
    small = ~large;

    if any(large(:))
        rel = abs(A(large) - B(large)) ./ scale(large);
        max_rel_large = max(rel);
    else
        max_rel_large = 0;
    end

    if any(small(:))
        max_abs_small = max(abs(A(small) - B(small)));
    else
        max_abs_small = 0;
    end
end

function ranks = strictLexicographicRanks(mean_values, std_values, best_values)
    [num_functions, num_algorithms] = size(mean_values);
    ranks = nan(num_functions, num_algorithms);

    for f = 1:num_functions
        rank_matrix = [mean_values(f, :)', std_values(f, :)', best_values(f, :)'];
        valid_algorithms = all(~isnan(rank_matrix), 2);
        valid_idx = find(valid_algorithms);

        if isempty(valid_idx)
            continue;
        end

        temp = rank_matrix(valid_idx, :);
        [~, sorted_local] = sortrows(temp, [1 2 3]);
        sorted_idx = valid_idx(sorted_local);

        current_rank = 1;
        ranks(f, sorted_idx(1)) = current_rank;

        for k = 2:numel(sorted_idx)
            prev = rank_matrix(sorted_idx(k - 1), :);
            curr = rank_matrix(sorted_idx(k), :);
            if isequal(prev, curr)
                ranks(f, sorted_idx(k)) = current_rank;
            else
                current_rank = k;
                ranks(f, sorted_idx(k)) = current_rank;
            end
        end
    end
end
