%% DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4.m
% Manuscript-facing Table 10 production and validation for the completed
% DFFG-AVOA mechanism-level ablation study.
%
% PURPOSE
%   1. Load the recovered authoritative ablation raw-results MAT.
%   2. Audit the complete F1-F23 x 8-variant x 30-run experiment.
%   3. Recompute and validate Mean, population Std, Best, and descriptive Rank.
%   4. Perform Friedman analysis across all eight ablation variants using
%      the 23 x 8 matrix of 30-run mean objective values.
%   5. Perform pairwise two-sided Wilcoxon rank-sum tests using the full
%      DFFG-AVOA7 configuration as the reference sample against V0-V6.
%   6. Construct ONE manuscript-facing Table 10 using the established
%      benchmark-table presentation convention:
%          Functions | Metric | AVOA | DFFG-AVOA1 | ... | DFFG-AVOA7
%      with Mean / Std / Best / Rank for every F1-F23 function.
%   7. Use the established manuscript numerical display:
%          Mean / Std / Best -> sprintf('%.2E', value)
%          Rank              -> integer
%      Thus scientific notation uses uppercase E and two digits after the
%      decimal point in the mantissa (e.g., 1.33E+00, 2.02E-06).
%   8. Export:
%          - manuscript/audit Excel workbook
%          - machine-readable Results MAT (the SECOND MAT in the ablation workflow)
%          - persistent text log
%          - ONE native Microsoft Word table: manuscript Table 10
%          - separate native Word statistical-support document containing
%            the Friedman and Wilcoxon tables as actual outputs
%          - emergency Error MAT on failure only
%
% FINAL4 CORRECTION
%   Final3 stopped at EXPERIMENT_IDENTITY_AUDIT because it validated the
%   9x9 ablation_definitions cell array with the wrong orientation.
%   Final4 validates the actual recovered row-oriented schema and changes
%   no scientific data, statistics, Table 10 design, or output policy.
%
% IMPORTANT SCOPE CONTROL
%   - This script produces ONLY the new ablation Table 10.
%   - It does NOT regenerate or renumber the manuscript's existing later tables.
%   - It DOES compute Friedman and Wilcoxon rank-sum analyses as validated
%     supporting statistical evidence, following the accepted V4.4.1
%     benchmark methodology.
%   - Friedman and Wilcoxon are produced as explicit outputs in Excel, MAT,
%     log, and a separate native Word statistical-support document.
%   - They are NOT assigned manuscript table numbers and are NOT inserted
%     into the manuscript Table 10 Word file by default. The manuscript
%     Word file still contains only Table 10.
%   - It does NOT alter the recovered raw-results MAT.
%
% AUTHORITATIVE INPUT
%   DFFG_AVOA_Ablation_Study_RawResults.mat
%
% OUTPUT FILES
%   DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4.xlsx
%   DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4_Results.mat
%   DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4_Log.txt
%   DFFG_AVOA_Ablation_Table10_Word_Final4.docx
%   DFFG_AVOA_Ablation_Statistical_Support_Word_Final4.docx
%   DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4_Error.mat   (failure only)
%
% STATISTICAL REQUIREMENT
%   Statistics and Machine Learning Toolbox: friedman, tiedrank, ranksum.
%
% WORD REQUIREMENT
%   Native Word-table generation requires Windows + Microsoft Word COM.
%
% MATLAB TARGET
%   MATLAB R2022b-compatible script with local functions.

clear; clc;

analysis_version = "DFFG_AVOA_ABLATION_TABLE10_FRIEDMAN_WILCOXON_FINAL4";

fprintf('\n============================================================\n');
fprintf('RUNNING: DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4.m\n');
fprintf('VERSION: %s\n', analysis_version);
fprintf('FILE: %s.m\n', mfilename('fullpath'));
fprintf('============================================================\n\n');

%% 1. USER-FACING SETTINGS

input_mat_name = 'DFFG_AVOA_Ablation_Study_RawResults.mat';

output_xlsx_name = 'DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4.xlsx';
output_mat_name  = 'DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4_Results.mat';
output_log_name  = 'DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4_Log.txt';
output_docx_name = 'DFFG_AVOA_Ablation_Table10_Word_Final4.docx';
output_stats_docx_name = 'DFFG_AVOA_Ablation_Statistical_Support_Word_Final4.docx';
output_error_mat_name = 'DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4_Error.mat';

alpha = 0.05;
expected_num_runs = 30;
expected_N = 30;
expected_Max_iter = 500;

expected_functions = arrayfun(@(k) sprintf('F%d', k), 1:23, ...
    'UniformOutput', false)';

expected_algorithms = [ ...
    "AVOA"; ...
    "DFFG-AVOA1"; ...
    "DFFG-AVOA2"; ...
    "DFFG-AVOA3"; ...
    "DFFG-AVOA4"; ...
    "DFFG-AVOA5"; ...
    "DFFG-AVOA6"; ...
    "DFFG-AVOA7"];

function_display_names = { ...
    'F1 (Sphere)'; ...
    'F2 (Schwefel 2.22)'; ...
    'F3 (Schwefel 1.2)'; ...
    'F4 (Schwefel 2.21)'; ...
    'F5 (Rosenbrock)'; ...
    'F6 (Step)'; ...
    'F7 (Quartic with noise)'; ...
    'F8 (Schwefel 2.26)'; ...
    'F9 (Rastrigin)'; ...
    'F10 (Ackley)'; ...
    'F11 (Griewank)'; ...
    'F12 (Penalized 1)'; ...
    'F13 (Penalized 2)'; ...
    'F14 (Foxholes)'; ...
    'F15 (Kowalik)'; ...
    'F16 (Six-Hump Camel)'; ...
    'F17 (Branin RCOS)'; ...
    'F18 (Goldstein-Price)'; ...
    'F19 (Hartmann 3D)'; ...
    'F20 (Hartmann 6D)'; ...
    'F21 (Shekel 5)'; ...
    'F22 (Shekel 7)'; ...
    'F23 (Shekel 10)'};

table10_caption = ...
    'Comparative Ablation Results for DFFG-AVOA Variants Across Benchmark Functions (F1-F23)';

%% 2. RESOLVE INPUT / OUTPUT PATHS AND START PERSISTENT LOG

script_full_path = mfilename('fullpath');
if isempty(script_full_path)
    script_dir = pwd;
else
    script_dir = fileparts(script_full_path);
end

output_xlsx = fullfile(script_dir, output_xlsx_name);
output_mat  = fullfile(script_dir, output_mat_name);
output_log  = fullfile(script_dir, output_log_name);
output_docx = fullfile(script_dir, output_docx_name);
output_stats_docx = fullfile(script_dir, output_stats_docx_name);
output_error_mat = fullfile(script_dir, output_error_mat_name);

% Clean only this script's previous outputs. Never alter the input raw MAT.
output_files_to_replace = { ...
    output_xlsx, output_mat, output_log, output_docx, output_stats_docx, output_error_mat};

for k = 1:numel(output_files_to_replace)
    if exist(output_files_to_replace{k}, 'file') == 2
        delete(output_files_to_replace{k});
    end
end

current_stage = "INITIALISATION";
raw_data_validation_pass = false;
variant_validation_pass = false;
descriptive_validation_pass = false;
friedman_validation_pass = false;
wilcoxon_validation_pass = false;
statistical_validation_pass = false;
table10_validation_pass = false;
excel_export_pass = false;
excel_format_pass = false;
mat_save_pass = false;
word_export_pass = false;
statistical_word_export_pass = false;

input_mat = '';
table10 = {};
word_validation = struct();
statistical_word_validation = struct();
table10_display_validation = struct();
recovery_metadata = struct();
friedman_support_table = {};
wilcoxon_support_table = {};
friedman_summary = table();
friedman_rank_table = table();
friedman_mean_rank_table = table();
friedman_input_table = table();
wilcoxon_audit = table();
wlt_table = table();
edge_case_summary = table();

diary off;
diary(output_log);
diary on;
diary_cleanup = onCleanup(@() diary('off')); %#ok<NASGU>

fprintf('\n============================================================\n');
fprintf('LOG-ENABLED RUN STARTED\n');
fprintf('VERSION: %s\n', analysis_version);
fprintf('SCRIPT: %s.m\n', mfilename('fullpath'));
fprintf('LOG: %s\n', output_log);
fprintf('START TIME: %s\n', datestr(now, 31));
fprintf('============================================================\n\n');

try
    %% 3. RESOLVE AND LOAD THE RECOVERED AUTHORITATIVE RAW-RESULTS MAT

    current_stage = "INPUT_RESOLUTION";
    input_mat = resolveInputFile(input_mat_name, script_dir);

    fprintf('======================================================================\n');
    fprintf('DFFG-AVOA ABLATION TABLE 10 + SUPPORTING STATISTICAL ANALYSIS\n');
    fprintf('Input raw MAT : %s\n', input_mat);
    fprintf('Output Excel  : %s\n', output_xlsx);
    fprintf('Output MAT    : %s\n', output_mat);
    fprintf('Output Log    : %s\n', output_log);
    fprintf('Output Word   : %s\n', output_docx);
    fprintf('Stats Word    : %s\n', output_stats_docx);
    fprintf('======================================================================\n\n');

    current_stage = "RAW_DATA_LOAD";

    required_vars = { ...
        'study_name', ...
        'problem_family', ...
        'experiment_mode', ...
        'benchmark_functions_names', ...
        'configurations', ...
        'ablation_definitions', ...
        'N', ...
        'Max_iter', ...
        'num_runs', ...
        'all_best_scores_raw', ...
        'all_mean_results', ...
        'all_std_results', ...
        'all_min_results', ...
        'all_rank_results'};

    S = load(input_mat, required_vars{:});

    for k = 1:numel(required_vars)
        assert(isfield(S, required_vars{k}), ...
            'Required variable "%s" is missing from the recovered raw MAT.', ...
            required_vars{k});
    end

    % Recovery provenance/validation is retained when present. It is not
    % required for the numerical calculations below, but it is propagated
    % into the second Results MAT for auditability.
    optional_recovery_vars = {'recovery_provenance', 'recovery_validation', ...
        'excel_filename', 'log_filename', 'raw_score_source_map'};

    for k = 1:numel(optional_recovery_vars)
        var_name = optional_recovery_vars{k};
        T = load(input_mat, var_name);
        if isfield(T, var_name)
            recovery_metadata.(var_name) = T.(var_name);
        end
    end

    %% 4. VALIDATE EXPERIMENT IDENTITY, ORIENTATION, AND ABLATION DEFINITIONS

    current_stage = "EXPERIMENT_IDENTITY_AUDIT";

    assert(S.num_runs == expected_num_runs, ...
        'Expected %d runs, but MAT reports %g.', expected_num_runs, S.num_runs);
    assert(S.N == expected_N, ...
        'Expected N = %d, but MAT reports %g.', expected_N, S.N);
    assert(S.Max_iter == expected_Max_iter, ...
        'Expected Max_iter = %d, but MAT reports %g.', ...
        expected_Max_iter, S.Max_iter);

    loaded_functions = string(S.benchmark_functions_names(:));
    assert(isequal(loaded_functions, string(expected_functions(:))), ...
        'Benchmark function order must be exactly F1-F23.');

    loaded_algorithms = string(S.configurations(:, 1));
    assert(isequal(loaded_algorithms, expected_algorithms), ...
        ['Algorithm/variant order must be exactly: AVOA, DFFG-AVOA1, ' ...
         'DFFG-AVOA2, DFFG-AVOA3, DFFG-AVOA4, DFFG-AVOA5, ' ...
         'DFFG-AVOA6, DFFG-AVOA7.']);

    num_functions = numel(expected_functions);
    num_algorithms = numel(expected_algorithms);

    assert(num_functions == 23, 'Expected 23 benchmark functions.');
    assert(num_algorithms == 8, 'Expected 8 ablation variants.');

    assert(numel(S.all_best_scores_raw) == num_algorithms, ...
        'Expected %d raw-score matrices, found %d.', ...
        num_algorithms, numel(S.all_best_scores_raw));

    expected_result_size = [num_functions, num_algorithms];
    assert(isequal(size(S.all_mean_results), expected_result_size), ...
        'all_mean_results must be 23 x 8.');
    assert(isequal(size(S.all_std_results), expected_result_size), ...
        'all_std_results must be 23 x 8.');
    assert(isequal(size(S.all_min_results), expected_result_size), ...
        'all_min_results must be 23 x 8.');
    assert(isequal(size(S.all_rank_results), expected_result_size), ...
        'all_rank_results must be 23 x 8.');

    validateAblationDefinitions(S.ablation_definitions, expected_algorithms);
    variant_validation_pass = true;

    fprintf('Experiment identity audit: PASS\n');
    fprintf('Ablation-definition audit: PASS\n');
    fprintf('  Functions: 23 (F1-F23)\n');
    fprintf('  Variants : 8 (V0-V7)\n');
    fprintf('  Runs     : 30 per function/variant\n');
    fprintf('  N        : 30\n');
    fprintf('  Iterations: 500\n\n');

    %% 5. RAW-DATA AUDIT AND RECOMPUTATION

    current_stage = "RAW_DATA_AUDIT";

    raw_cube = nan(num_functions, num_algorithms, expected_num_runs);
    recomputed_mean = nan(num_functions, num_algorithms);
    recomputed_std_population = nan(num_functions, num_algorithms);
    recomputed_best = nan(num_functions, num_algorithms);

    for a = 1:num_algorithms
        A = S.all_best_scores_raw{a};

        assert(isequal(size(A), [num_functions, expected_num_runs]), ...
            'Raw-score matrix for %s must be 23 x 30; found %s.', ...
            expected_algorithms(a), mat2str(size(A)));
        assert(~any(isnan(A), 'all'), ...
            'Unexpected NaN in raw results for %s.', expected_algorithms(a));
        assert(~any(isinf(A), 'all'), ...
            'Unexpected Inf in raw results for %s.', expected_algorithms(a));

        raw_cube(:, a, :) = reshape(A, ...
            [num_functions, 1, expected_num_runs]);

        for f = 1:num_functions
            x = A(f, :);
            mu = mean(x);
            recomputed_mean(f, a) = mu;

            % Match the study driver/recovery convention: population Std,
            % denominator R, not sample denominator R-1.
            recomputed_std_population(f, a) = ...
                sqrt(sum((x - mu).^2) / numel(x));

            recomputed_best(f, a) = min(x);
        end
    end

    assertMatrixMatch(recomputed_mean, S.all_mean_results, ...
        '30-run Mean');
    assertMatrixMatch(recomputed_std_population, S.all_std_results, ...
        'population Std');
    assertMatrixMatch(recomputed_best, S.all_min_results, ...
        'Best');

    raw_data_validation_pass = true;

    %% 6. RECOMPUTE AND VALIDATE DESCRIPTIVE FUNCTION-LEVEL RANKS

    current_stage = "DESCRIPTIVE_RANK_AUDIT";

    recomputed_rank = strictLexicographicRanks( ...
        recomputed_mean, recomputed_std_population, recomputed_best);

    assert(isequal(recomputed_rank, S.all_rank_results), ...
        ['Stored descriptive Rank matrix does not reproduce from the ' ...
         'validated Mean -> Std -> Best lexicographic ranking rule.']);

    descriptive_validation_pass = true;

    fprintf('Raw-data audit: PASS\n');
    fprintf('Stored Mean/Std/Best reproduce from the 30-run raw data: PASS\n');
    fprintf('Stored descriptive Rank matrix reproduces: PASS\n\n');

    %% 7. FRIEDMAN ANALYSIS — SUPPORTING STATISTICAL EVIDENCE

    current_stage = "FRIEDMAN_ANALYSIS";

    assert(exist('friedman', 'file') == 2, ...
        'MATLAB function friedman is unavailable. Statistics and Machine Learning Toolbox is required.');
    assert(exist('tiedrank', 'file') == 2, ...
        'MATLAB function tiedrank is unavailable. Statistics and Machine Learning Toolbox is required.');
    assert(exist('ranksum', 'file') == 2, ...
        'MATLAB function ranksum is unavailable. Statistics and Machine Learning Toolbox is required.');

    % Accepted V4.4.1 architecture:
    %   blocks     = benchmark functions F1-F23
    %   treatments = the eight ablation configurations
    %   input      = 30-run mean objective value for each function/variant
    %   lower objective value = better rank
    %   exact ties use tiedrank average ranks.
    friedman_input_means = recomputed_mean;

    [friedman_p, friedman_anova_table, friedman_stats] = ...
        friedman(friedman_input_means, 1, 'off');

    friedman_h = double(friedman_p < alpha);

    friedman_function_ranks = nan(num_functions, num_algorithms);
    for f = 1:num_functions
        friedman_function_ranks(f, :) = tiedrank(friedman_input_means(f, :));
    end

    friedman_mean_rank = mean(friedman_function_ranks, 1);
    friedman_final_ranking = tiedrank(friedman_mean_rank);

    friedman_df = friedman_anova_table{2, 3};
    friedman_chi_square = friedman_anova_table{2, 5};

    if isfield(friedman_stats, 'meanranks')
        matlab_mean_ranks = friedman_stats.meanranks(:)';
        assert(max(abs(matlab_mean_ranks - friedman_mean_rank)) <= 1e-12, ...
            'Explicit Friedman mean ranks do not match friedman() stats.meanranks.');
    end

    % Support table only — not automatically inserted into the manuscript.
    friedman_support_table = cell(num_functions + 3, num_algorithms + 1);
    friedman_support_table(1, :) = [{'F'}, cellstr(expected_algorithms)'];

    for f = 1:num_functions
        friedman_support_table{f + 1, 1} = expected_functions{f};
        for a = 1:num_algorithms
            friedman_support_table{f + 1, a + 1} = ...
                friedman_function_ranks(f, a);
        end
    end

    friedman_support_table{num_functions + 2, 1} = 'Mean Rank';
    friedman_support_table{num_functions + 3, 1} = 'Final Ranking';

    for a = 1:num_algorithms
        friedman_support_table{num_functions + 2, a + 1} = ...
            sprintf('%.2f', friedman_mean_rank(a));
        friedman_support_table{num_functions + 3, a + 1} = ...
            friedman_final_ranking(a);
    end

    friedman_summary = table( ...
        alpha, friedman_p, friedman_h, friedman_chi_square, friedman_df, ...
        num_functions, num_algorithms, ...
        'VariableNames', { ...
        'Alpha', 'PValue', 'H', 'ChiSquare', 'DF', ...
        'BenchmarkBlocks', 'Variants'});

    friedman_rank_table = array2table(friedman_function_ranks, ...
        'VariableNames', cellstr(expected_algorithms));
    friedman_rank_table = addvars(friedman_rank_table, ...
        string(expected_functions), 'Before', 1, ...
        'NewVariableNames', 'Function');

    friedman_mean_rank_table = table( ...
        expected_algorithms, friedman_mean_rank(:), ...
        friedman_final_ranking(:), ...
        'VariableNames', {'Variant', 'MeanRank', 'FinalRanking'});

    friedman_input_table = array2table(friedman_input_means, ...
        'VariableNames', cellstr(expected_algorithms));
    friedman_input_table = addvars(friedman_input_table, ...
        string(expected_functions), 'Before', 1, ...
        'NewVariableNames', 'Function');

    friedman_validation_pass = true;

    fprintf('Friedman supporting analysis: PASS\n');
    fprintf('  p-value     = %.16g\n', friedman_p);
    fprintf('  H           = %d\n', friedman_h);
    fprintf('  Chi-square  = %.16g\n', friedman_chi_square);
    fprintf('  df          = %g\n\n', friedman_df);

    %% 8. WILCOXON RANK-SUM — SUPPORTING STATISTICAL EVIDENCE

    current_stage = "WILCOXON_ANALYSIS";

    % Direct analogue of the accepted benchmark analysis:
    % full proposed DFFG-AVOA7 is always sample x, compared independently
    % against each reduced configuration V0-V6.
    reference_idx = 8;            % DFFG-AVOA7, full proposed configuration
    comparator_indices = 1:7;     % V0-V6
    num_comparators = numel(comparator_indices);

    wilcoxon_p = nan(num_functions, num_comparators);
    wilcoxon_h = nan(num_functions, num_comparators);
    wilcoxon_ranksum = nan(num_functions, num_comparators);
    wilcoxon_z = nan(num_functions, num_comparators);
    wilcoxon_S = strings(num_functions, num_comparators);

    x_constant = false(num_functions, num_comparators);
    y_constant = false(num_functions, num_comparators);
    identical_samples = false(num_functions, num_comparators);
    edge_flag = strings(num_functions, num_comparators);

    num_tests = num_functions * num_comparators;
    audit_function_w = strings(num_tests, 1);
    audit_reference_w = strings(num_tests, 1);
    audit_comparator_w = strings(num_tests, 1);
    audit_p_w = nan(num_tests, 1);
    audit_h_w = nan(num_tests, 1);
    audit_ranksum_w = nan(num_tests, 1);
    audit_z_w = nan(num_tests, 1);
    audit_S_w = strings(num_tests, 1);
    audit_reference_mean_w = nan(num_tests, 1);
    audit_comparator_mean_w = nan(num_tests, 1);
    audit_reference_median_w = nan(num_tests, 1);
    audit_comparator_median_w = nan(num_tests, 1);
    audit_flag_w = strings(num_tests, 1);

    row_w = 0;

    for f = 1:num_functions
        x = squeeze(raw_cube(f, reference_idx, :));
        x = x(:);

        for c = 1:num_comparators
            a = comparator_indices(c);
            y = squeeze(raw_cube(f, a, :));
            y = y(:);

            row_w = row_w + 1;

            assert(numel(x) == expected_num_runs && ...
                   numel(y) == expected_num_runs, ...
                'Unexpected Wilcoxon sample size at %s versus %s.', ...
                expected_functions{f}, expected_algorithms(a));

            assert(all(isfinite(x)) && all(isfinite(y)), ...
                'Non-finite value encountered at %s versus %s.', ...
                expected_functions{f}, expected_algorithms(a));

            x_constant(f, c) = all(x == x(1));
            y_constant(f, c) = all(y == y(1));
            identical_samples(f, c) = isequal(x, y);

            flags = strings(0, 1);
            if x_constant(f, c)
                flags(end + 1) = "Reference constant"; %#ok<SAGROW>
            end
            if y_constant(f, c)
                flags(end + 1) = "Comparator constant"; %#ok<SAGROW>
            end
            if identical_samples(f, c)
                flags(end + 1) = "Identical samples"; %#ok<SAGROW>
            end

            if identical_samples(f, c)
                pooled_ranks = tiedrank([x; y]);
                p_value = 1;
                h_value = false;
                rank_sum_value = sum(pooled_ranks(1:numel(x)));
                z_value = 0;
                flags(end + 1) = ...
                    "Identical-sample neutral rank-sum result"; %#ok<SAGROW>
            else
                [p_value, h_value, test_stats] = ranksum( ...
                    x, y, ...
                    'alpha', alpha, ...
                    'tail', 'both', ...
                    'method', 'approximate');

                rank_sum_value = test_stats.ranksum;
                z_value = test_stats.zval;
            end

            wilcoxon_p(f, c) = p_value;
            wilcoxon_h(f, c) = double(h_value);
            wilcoxon_ranksum(f, c) = rank_sum_value;
            wilcoxon_z(f, c) = z_value;

            % V7 is sample x. With minimisation data, z < 0 means the rank
            % direction favours the full DFFG-AVOA7 configuration.
            if z_value < 0
                symbol = "+";
            elseif z_value > 0
                symbol = "-";
            else
                symbol = "=";
            end

            wilcoxon_S(f, c) = symbol;

            if isempty(flags)
                edge_flag(f, c) = "";
            else
                edge_flag(f, c) = strjoin(flags, '; ');
            end

            audit_function_w(row_w) = string(expected_functions{f});
            audit_reference_w(row_w) = expected_algorithms(reference_idx);
            audit_comparator_w(row_w) = expected_algorithms(a);
            audit_p_w(row_w) = p_value;
            audit_h_w(row_w) = double(h_value);
            audit_ranksum_w(row_w) = rank_sum_value;
            audit_z_w(row_w) = z_value;
            audit_S_w(row_w) = symbol;
            audit_reference_mean_w(row_w) = mean(x);
            audit_comparator_mean_w(row_w) = mean(y);
            audit_reference_median_w(row_w) = median(x);
            audit_comparator_median_w(row_w) = median(y);
            audit_flag_w(row_w) = edge_flag(f, c);
        end
    end

    assert(row_w == 161, ...
        'Wilcoxon test-count audit failed: expected 161 tests.');
    assert(all(isfinite(wilcoxon_p), 'all') && ...
           all(isfinite(wilcoxon_ranksum), 'all') && ...
           all(isfinite(wilcoxon_z), 'all'), ...
        'At least one Wilcoxon rank-sum result is non-finite.');

    wins = sum(wilcoxon_S == "+", 1);
    losses = sum(wilcoxon_S == "-", 1);
    ties = sum(wilcoxon_S == "=", 1);

    assert(all(wins + losses + ties == num_functions), ...
        'Every Wilcoxon W/L/T total must equal 23.');

    wlt_summary = strings(1, num_comparators);
    for c = 1:num_comparators
        wlt_summary(c) = sprintf('(%d|%d|%d)', ...
            wins(c), losses(c), ties(c));
    end

    expected_S_from_z = strings(size(wilcoxon_S));
    expected_S_from_z(wilcoxon_z < 0) = "+";
    expected_S_from_z(wilcoxon_z > 0) = "-";
    expected_S_from_z(wilcoxon_z == 0) = "=";

    assert(isequal(wilcoxon_S, expected_S_from_z), ...
        'Wilcoxon S-direction validation failed.');

    non_sig_plus = sum((wilcoxon_h == 0) & ...
        (wilcoxon_S == "+"), 'all');
    non_sig_minus = sum((wilcoxon_h == 0) & ...
        (wilcoxon_S == "-"), 'all');
    non_sig_equal = sum((wilcoxon_h == 0) & ...
        (wilcoxon_S == "="), 'all');

    wilcoxon_support_table = cell(num_functions + 3, ...
        1 + 3*num_comparators);

    wilcoxon_support_table{1,1} = 'F';
    wilcoxon_support_table{2,1} = '';

    for c = 1:num_comparators
        start_col = 2 + (c-1)*3;
        wilcoxon_support_table{1,start_col} = ...
            char(expected_algorithms(comparator_indices(c)));
        wilcoxon_support_table{1,start_col+1} = '';
        wilcoxon_support_table{1,start_col+2} = '';

        wilcoxon_support_table{2,start_col} = 'p-value';
        wilcoxon_support_table{2,start_col+1} = 'H';
        wilcoxon_support_table{2,start_col+2} = 'S';
    end

    for f = 1:num_functions
        out_row = f + 2;
        wilcoxon_support_table{out_row,1} = expected_functions{f};

        for c = 1:num_comparators
            start_col = 2 + (c-1)*3;
            wilcoxon_support_table{out_row,start_col} = ...
                formatPValue(wilcoxon_p(f,c));
            wilcoxon_support_table{out_row,start_col+1} = ...
                wilcoxon_h(f,c);
            wilcoxon_support_table{out_row,start_col+2} = ...
                char(wilcoxon_S(f,c));
        end
    end

    summary_row_w = num_functions + 3;
    wilcoxon_support_table{summary_row_w,1} = '(W|L|T)';

    for c = 1:num_comparators
        start_col = 2 + (c-1)*3;
        wilcoxon_support_table{summary_row_w,start_col} = ...
            char(wlt_summary(c));
        wilcoxon_support_table{summary_row_w,start_col+1} = '';
        wilcoxon_support_table{summary_row_w,start_col+2} = '';
    end

    wilcoxon_audit = table( ...
        audit_function_w, audit_reference_w, audit_comparator_w, ...
        audit_p_w, audit_h_w, audit_ranksum_w, audit_z_w, audit_S_w, ...
        audit_reference_mean_w, audit_comparator_mean_w, ...
        audit_reference_median_w, audit_comparator_median_w, ...
        audit_flag_w, ...
        'VariableNames', { ...
        'Function', 'Reference', 'Comparator', 'PValue', 'H', ...
        'RankSum', 'ZValue', 'S', ...
        'ReferenceMean', 'ComparatorMean', ...
        'ReferenceMedian', 'ComparatorMedian', 'AuditFlag'});

    wlt_table = table( ...
        expected_algorithms(comparator_indices), ...
        wins(:), losses(:), ties(:), wlt_summary(:), ...
        'VariableNames', {'Comparator', 'W', 'L', 'T', 'W_L_T'});

    edge_case_summary = table( ...
        sum(x_constant, 'all'), ...
        sum(y_constant, 'all'), ...
        sum(identical_samples, 'all'), ...
        sum((x_constant | y_constant), 'all'), ...
        non_sig_plus, non_sig_minus, non_sig_equal, ...
        'VariableNames', { ...
        'ReferenceConstantComparisons', ...
        'ComparatorConstantComparisons', ...
        'IdenticalSampleComparisons', ...
        'AnyConstantSampleComparisons', ...
        'NonSignificantPlus', ...
        'NonSignificantMinus', ...
        'NonSignificantEqual'});

    wilcoxon_validation_pass = true;
    statistical_validation_pass = ...
        friedman_validation_pass && wilcoxon_validation_pass;

    fprintf('Wilcoxon rank-sum supporting analysis: PASS\n');
    fprintf('  Reference: %s (full proposed configuration)\n', ...
        expected_algorithms(reference_idx));
    fprintf('  Comparators: V0-V6\n');
    fprintf('  Tests: %d\n', num_tests);
    fprintf('  Tail: two-sided\n');
    fprintf('  Method: approximate\n');
    fprintf('  Alpha: %.2f\n', alpha);
    fprintf('  S direction independent of H: PASS\n\n');

    %% 9. CONSTRUCT THE SINGLE MANUSCRIPT-FACING TABLE 10

    current_stage = "TABLE10_CONSTRUCTION";

    % 1 header + 23 functions x 4 metrics = 93 rows; 2 label columns
    % + 8 variant columns = 10 columns.
    table10 = cell(1 + 4*num_functions, 2 + num_algorithms);

    table10(1, :) = [ ...
        {'Functions', 'Metric'}, ...
        cellstr(expected_algorithms')];

    metric_names = {'Mean', 'Std', 'Best', 'Rank'};

    row = 2;
    for f = 1:num_functions
        metric_values = { ...
            recomputed_mean(f, :), ...
            recomputed_std_population(f, :), ...
            recomputed_best(f, :), ...
            recomputed_rank(f, :)};

        for m = 1:4
            table10{row, 1} = function_display_names{f};
            table10{row, 2} = metric_names{m};

            for a = 1:num_algorithms
                if m <= 3
                    table10{row, a + 2} = ...
                        formatBenchmarkDisplay(metric_values{m}(a));
                else
                    table10{row, a + 2} = ...
                        sprintf('%d', metric_values{m}(a));
                end
            end

            row = row + 1;
        end
    end

    assert(row == 94, 'Table 10 row-construction count is invalid.');
    assert(isequal(size(table10), [93, 10]), ...
        'Manuscript Table 10 must be exactly 93 x 10.');

    table10_display_validation = validateTable10Display( ...
        table10, function_display_names, expected_algorithms, ...
        recomputed_mean, recomputed_std_population, ...
        recomputed_best, recomputed_rank);

    table10_validation_pass = true;

    fprintf('Manuscript-facing Table 10 construction: PASS\n');
    fprintf('  Table dimensions: 93 rows x 10 columns\n');
    fprintf('  Display cells validated: %d\n', ...
        table10_display_validation.DisplayCellsChecked);
    fprintf('  Scientific notation rule: %% .2E equivalent -> %.2E example\n', 1.33);
    fprintf('  Uppercase E validation: PASS\n');
    fprintf('  Rank integer validation: PASS\n\n');

    %% 10. CREATE AUDIT TABLES FOR EXCEL/MAT PROVENANCE

    current_stage = "AUDIT_TABLE_CONSTRUCTION";

    audit_rows = num_functions * num_algorithms;
    audit_function = strings(audit_rows, 1);
    audit_algorithm = strings(audit_rows, 1);
    audit_mean = nan(audit_rows, 1);
    audit_std = nan(audit_rows, 1);
    audit_best = nan(audit_rows, 1);
    audit_rank = nan(audit_rows, 1);
    audit_mean_display = strings(audit_rows, 1);
    audit_std_display = strings(audit_rows, 1);
    audit_best_display = strings(audit_rows, 1);

    rr = 0;
    for f = 1:num_functions
        for a = 1:num_algorithms
            rr = rr + 1;
            audit_function(rr) = string(function_display_names{f});
            audit_algorithm(rr) = expected_algorithms(a);
            audit_mean(rr) = recomputed_mean(f, a);
            audit_std(rr) = recomputed_std_population(f, a);
            audit_best(rr) = recomputed_best(f, a);
            audit_rank(rr) = recomputed_rank(f, a);
            audit_mean_display(rr) = string(formatBenchmarkDisplay(audit_mean(rr)));
            audit_std_display(rr) = string(formatBenchmarkDisplay(audit_std(rr)));
            audit_best_display(rr) = string(formatBenchmarkDisplay(audit_best(rr)));
        end
    end

    descriptive_audit = table( ...
        audit_function, audit_algorithm, audit_mean, audit_std, ...
        audit_best, audit_rank, audit_mean_display, ...
        audit_std_display, audit_best_display, ...
        'VariableNames', { ...
        'Function', 'Algorithm', 'MeanFullPrecision', ...
        'StdPopulationFullPrecision', 'BestFullPrecision', ...
        'Rank', 'MeanDisplay', 'StdDisplay', 'BestDisplay'});

    validation_item = [ ...
        "Recovered raw MAT resolved"; ...
        "Functions are exactly F1-F23"; ...
        "Variant order is exactly AVOA then DFFG-AVOA1 through DFFG-AVOA7"; ...
        "Ablation definitions V0-V7 reproduce"; ...
        "N equals 30"; ...
        "Max_iter equals 500"; ...
        "num_runs equals 30"; ...
        "All eight raw-score matrices are 23 x 30"; ...
        "All raw scores are finite"; ...
        "Stored Mean reproduces from raw data"; ...
        "Stored population Std reproduces from raw data"; ...
        "Stored Best reproduces from raw data"; ...
        "Stored descriptive Rank reproduces"; ...
        "Friedman input is 23 x 8 function-level mean matrix"; ...
        "Friedman exact ties use tiedrank average ranks"; ...
        "Wilcoxon reference is full DFFG-AVOA7"; ...
        "Wilcoxon compares DFFG-AVOA7 against V0-V6"; ...
        "Wilcoxon test count is 161"; ...
        "Wilcoxon tail is two-sided"; ...
        "Wilcoxon method is approximate"; ...
        "Wilcoxon alpha is 0.05"; ...
        "Wilcoxon S direction follows z independently of H"; ...
        "Every Wilcoxon comparator W+L+T total equals 23"; ...
        "Table 10 is 93 x 10"; ...
        "Mean/Std/Best use uppercase E scientific notation with %.2E"; ...
        "Rank values are integer strings"; ...
        "Only one manuscript Word table is in scope: Table 10"; ...
        "Friedman/Wilcoxon are produced as supporting statistical outputs"; ...
        "Separate Word statistical-support document contains exactly two native tables"];

    validation_status = repmat("PASS", size(validation_item));

    validation_table = table(validation_item, validation_status, ...
        'VariableNames', {'ValidationItem', 'Status'});

    provenance_item = [ ...
        "AnalysisVersion"; ...
        "InputRawMAT"; ...
        "StudyName"; ...
        "ProblemFamily"; ...
        "ExperimentMode"; ...
        "PopulationSizeN"; ...
        "MaxIterations"; ...
        "IndependentRuns"; ...
        "Functions"; ...
        "Variants"; ...
        "Table10Rows"; ...
        "Table10Columns"; ...
        "DisplayFormat"; ...
        "FriedmanBlocks"; ...
        "FriedmanTreatments"; ...
        "WilcoxonReference"; ...
        "WilcoxonComparators"; ...
        "WilcoxonTests"; ...
        "WilcoxonAlpha"; ...
        "WilcoxonTail"; ...
        "WilcoxonMethod"; ...
        "Table10Caption"];

    provenance_value = [ ...
        analysis_version; ...
        string(input_mat); ...
        string(S.study_name); ...
        string(S.problem_family); ...
        string(S.experiment_mode); ...
        string(S.N); ...
        string(S.Max_iter); ...
        string(S.num_runs); ...
        "F1-F23"; ...
        "AVOA + DFFG-AVOA1 through DFFG-AVOA7"; ...
        "93"; ...
        "10"; ...
        "%.2E for Mean/Std/Best; integer Rank"; ...
        "23 benchmark functions"; ...
        "8 ablation variants"; ...
        "DFFG-AVOA7 (full proposed configuration)"; ...
        "AVOA and DFFG-AVOA1 through DFFG-AVOA6"; ...
        "161"; ...
        string(alpha); ...
        "two-sided"; ...
        "approximate ranksum"; ...
        string(table10_caption)];

    provenance_table = table(provenance_item, provenance_value, ...
        'VariableNames', {'Item', 'Value'});

    %% 11. EXPORT EXCEL WORKBOOK

    current_stage = "EXCEL_EXPORT";

    if exist(output_xlsx, 'file') == 2
        delete(output_xlsx);
    end

    writecell({'Manuscript Table 10'; table10_caption}, ...
        output_xlsx, 'Sheet', 'Table 10', 'Range', 'A1');
    writecell(table10, output_xlsx, ...
        'Sheet', 'Table 10', 'Range', 'A4');

    writetable(descriptive_audit, output_xlsx, ...
        'Sheet', 'Descriptive_Audit');
    writecell({'Supporting Friedman analysis'; ...
        'Not inserted into the manuscript by default.'}, ...
        output_xlsx, 'Sheet', 'Friedman_Support', 'Range', 'A1');
    writecell(friedman_support_table, output_xlsx, ...
        'Sheet', 'Friedman_Support', 'Range', 'A4');
    writetable(friedman_summary, output_xlsx, ...
        'Sheet', 'Friedman_Summary');
    writetable(friedman_input_table, output_xlsx, ...
        'Sheet', 'Friedman_Input_Means');
    writetable(friedman_rank_table, output_xlsx, ...
        'Sheet', 'Friedman_Ranks_Audit');
    writetable(friedman_mean_rank_table, output_xlsx, ...
        'Sheet', 'Friedman_Mean_Ranks');

    writecell({'Supporting Wilcoxon rank-sum analysis'; ...
        ['Reference = DFFG-AVOA7; comparators = V0-V6; ' ...
         'not inserted into the manuscript by default.']}, ...
        output_xlsx, 'Sheet', 'Wilcoxon_Support', 'Range', 'A1');
    writecell(wilcoxon_support_table, output_xlsx, ...
        'Sheet', 'Wilcoxon_Support', 'Range', 'A4');
    writetable(wilcoxon_audit, output_xlsx, ...
        'Sheet', 'Wilcoxon_Full_Audit');
    writetable(wlt_table, output_xlsx, ...
        'Sheet', 'Wilcoxon_WLT');
    writetable(edge_case_summary, output_xlsx, ...
        'Sheet', 'Edge_Case_Summary');
    writecell(S.ablation_definitions, output_xlsx, ...
        'Sheet', 'Variant_Definitions', 'Range', 'A1');
    writetable(validation_table, output_xlsx, ...
        'Sheet', 'Validation');
    writetable(provenance_table, output_xlsx, ...
        'Sheet', 'Provenance');

    assert(exist(output_xlsx, 'file') == 2, ...
        'Excel workbook was not created.');
    xlsx_info = dir(output_xlsx);
    assert(~isempty(xlsx_info) && xlsx_info.bytes > 0, ...
        'Excel workbook exists but is empty.');

    excel_export_pass = true;

    % Presentation-only Excel formatting. Numerical content is already
    % validated and is not recalculated here.
    try
        formatTable10Workbook(output_xlsx, size(table10,1), size(table10,2));
        excel_format_pass = true;
        fprintf('Excel manuscript/audit workbook export: PASS\n');
        fprintf('Excel Table 10 presentation formatting: PASS\n\n');
    catch ME_excel_format
        excel_format_pass = false;
        fprintf(['WARNING: Excel content export passed, but presentation-only ' ...
            'COM formatting was not completed.\n']);
        fprintf('Excel formatting warning: %s\n\n', ME_excel_format.message);
    end

    %% 12. SAVE SECOND, MACHINE-READABLE RESULTS MAT

    current_stage = "MAT_SAVE";

    table10_scope = "Single new manuscript Table 10; Friedman/Wilcoxon produced as separate supporting outputs";
    table10_numeric_display_format = "%.2E for Mean/Std/Best; integer Rank";
    results_created_at = datestr(now, 31);

    save(output_mat, ...
        'analysis_version', ...
        'results_created_at', ...
        'input_mat', ...
        'expected_functions', ...
        'function_display_names', ...
        'expected_algorithms', ...
        'expected_num_runs', ...
        'expected_N', ...
        'expected_Max_iter', ...
        'table10_scope', ...
        'table10_caption', ...
        'table10_numeric_display_format', ...
        'raw_cube', ...
        'recomputed_mean', ...
        'recomputed_std_population', ...
        'recomputed_best', ...
        'recomputed_rank', ...
        'alpha', ...
        'friedman_input_means', ...
        'friedman_function_ranks', ...
        'friedman_mean_rank', ...
        'friedman_final_ranking', ...
        'friedman_p', ...
        'friedman_h', ...
        'friedman_chi_square', ...
        'friedman_df', ...
        'friedman_support_table', ...
        'friedman_summary', ...
        'friedman_rank_table', ...
        'friedman_mean_rank_table', ...
        'friedman_input_table', ...
        'reference_idx', ...
        'comparator_indices', ...
        'wilcoxon_p', ...
        'wilcoxon_h', ...
        'wilcoxon_ranksum', ...
        'wilcoxon_z', ...
        'wilcoxon_S', ...
        'wins', ...
        'losses', ...
        'ties', ...
        'wlt_summary', ...
        'wilcoxon_support_table', ...
        'wilcoxon_audit', ...
        'wlt_table', ...
        'edge_case_summary', ...
        'table10', ...
        'table10_display_validation', ...
        'descriptive_audit', ...
        'validation_table', ...
        'provenance_table', ...
        'recovery_metadata', ...
        'raw_data_validation_pass', ...
        'variant_validation_pass', ...
        'descriptive_validation_pass', ...
        'friedman_validation_pass', ...
        'wilcoxon_validation_pass', ...
        'statistical_validation_pass', ...
        'table10_validation_pass', ...
        'excel_export_pass', ...
        'excel_format_pass', ...
        'mat_save_pass', ...
        'word_export_pass', ...
        'statistical_word_export_pass', ...
        '-v7.3');

    mat_save_pass = true;

    save(output_mat, ...
        'mat_save_pass', ...
        'excel_export_pass', ...
        'excel_format_pass', ...
        'word_export_pass', ...
        'statistical_word_export_pass', ...
        '-append');

    % Load-back validation of the second MAT.
    Mcheck = load(output_mat, ...
        'table10', 'recomputed_mean', 'recomputed_std_population', ...
        'recomputed_best', 'recomputed_rank', 'table10_validation_pass', ...
        'friedman_p', 'friedman_mean_rank', 'wilcoxon_p', ...
        'wilcoxon_S', 'statistical_validation_pass');

    assert(isequal(Mcheck.table10, table10), ...
        'Results MAT load-back Table 10 mismatch.');
    assert(isequaln(Mcheck.recomputed_mean, recomputed_mean), ...
        'Results MAT load-back Mean mismatch.');
    assert(isequaln(Mcheck.recomputed_std_population, ...
        recomputed_std_population), ...
        'Results MAT load-back Std mismatch.');
    assert(isequaln(Mcheck.recomputed_best, recomputed_best), ...
        'Results MAT load-back Best mismatch.');
    assert(isequaln(Mcheck.recomputed_rank, recomputed_rank), ...
        'Results MAT load-back Rank mismatch.');
    assert(Mcheck.table10_validation_pass, ...
        'Results MAT did not preserve Table 10 validation status.');
    assert(Mcheck.statistical_validation_pass, ...
        'Results MAT did not preserve statistical validation status.');
    assert(isequaln(Mcheck.friedman_p, friedman_p), ...
        'Results MAT Friedman p-value load-back mismatch.');
    assert(isequaln(Mcheck.friedman_mean_rank, friedman_mean_rank), ...
        'Results MAT Friedman mean-rank load-back mismatch.');
    assert(isequaln(Mcheck.wilcoxon_p, wilcoxon_p), ...
        'Results MAT Wilcoxon p-value load-back mismatch.');
    assert(isequal(Mcheck.wilcoxon_S, wilcoxon_S), ...
        'Results MAT Wilcoxon direction load-back mismatch.');

    fprintf('Second Results MAT save/load-back validation: PASS\n');
    fprintf('Friedman/Wilcoxon supporting results preserved in MAT: PASS\n\n');

    %% 13. CREATE ONE NATIVE WORD MANUSCRIPT TABLE 10

    current_stage = "WORD_EXPORT";

    fprintf('WORD TABLE GENERATION\n');
    fprintf('  Word Table 10 creation...\n');

    word_validation = generateNativeWordTable10( ...
        output_docx, table10, table10_caption, ...
        function_display_names, expected_algorithms);

    word_export_pass = true;

    save(output_mat, ...
        'word_export_pass', ...
        'word_validation', ...
        'excel_format_pass', ...
        '-append');

    fprintf('  Word Table 10 formatting: PASS\n');
    fprintf('Table 10 created: PASS\n');
    fprintf('Word document saved: PASS\n');
    fprintf('Native Word table count = 1: PASS\n\n');

    %% 14. CREATE SEPARATE NATIVE WORD STATISTICAL-SUPPORT TABLES

    current_stage = "STATISTICAL_WORD_EXPORT";

    fprintf('STATISTICAL SUPPORT WORD GENERATION\n');
    fprintf('  Friedman support table creation...\n');
    fprintf('  Wilcoxon support table creation...\n');

    statistical_word_validation = generateNativeWordStatisticalSupport( ...
        output_stats_docx, ...
        friedman_support_table, ...
        wilcoxon_support_table, ...
        expected_algorithms);

    statistical_word_export_pass = true;

    save(output_mat, ...
        'statistical_word_export_pass', ...
        'statistical_word_validation', ...
        '-append');

    fprintf('  Statistical Word formatting: PASS\n');
    fprintf('Friedman support table created: PASS\n');
    fprintf('Wilcoxon support table created: PASS\n');
    fprintf('Statistical support native-table count = 2: PASS\n\n');

    %% 15. FINAL CONSOLE / LOG REPORT

    current_stage = "COMPLETE";

    fprintf('======================================================================\n');
    fprintf('ABLATION TABLE 10 + FRIEDMAN/WILCOXON BUILD COMPLETE\n');
    fprintf('VERSION: %s\n', analysis_version);
    fprintf('======================================================================\n');
    fprintf('Raw-data validation:          PASS\n');
    fprintf('Variant-definition validation: PASS\n');
    fprintf('Descriptive-stat validation:  PASS\n');
    fprintf('Friedman validation:          PASS\n');
    fprintf('Wilcoxon validation:          PASS\n');
    fprintf('Statistical support:          PASS\n');
    fprintf('Table 10 display validation:  PASS\n');
    fprintf('Excel export:                 PASS\n');
    if excel_format_pass
        fprintf('Excel presentation formatting: PASS\n');
    else
        fprintf('Excel presentation formatting: WARNING (content remains valid)\n');
    end
    fprintf('Second Results MAT:           PASS\n');
    fprintf('Native Word Table 10:         PASS\n');
    fprintf('Word native-table count:      %d\n', word_validation.TableCount);
    fprintf('Statistical support Word:     PASS\n');
    fprintf('Statistical native tables:    %d\n', statistical_word_validation.TableCount);
    fprintf('Completed: %s\n', datestr(now, 31));
    fprintf('======================================================================\n\n');

    fprintf('Files written:\n');
    fprintf('  %s\n', output_xlsx);
    fprintf('  %s\n', output_mat);
    fprintf('  %s\n', output_log);
    fprintf('  %s\n', output_docx);
    fprintf('  %s\n', output_stats_docx);

catch ME
    %% FAILURE HANDLER / EMERGENCY ERROR MAT

    fprintf('\n============================================================\n');
    fprintf('RUN FAILED\n');
    fprintf('VERSION: %s\n', analysis_version);
    fprintf('FAILED STAGE: %s\n', current_stage);
    fprintf('RAW DATA VALIDATION PASS: %d\n', raw_data_validation_pass);
    fprintf('VARIANT VALIDATION PASS: %d\n', variant_validation_pass);
    fprintf('DESCRIPTIVE VALIDATION PASS: %d\n', descriptive_validation_pass);
    fprintf('FRIEDMAN VALIDATION PASS: %d\n', friedman_validation_pass);
    fprintf('WILCOXON VALIDATION PASS: %d\n', wilcoxon_validation_pass);
    fprintf('STATISTICAL VALIDATION PASS: %d\n', statistical_validation_pass);
    fprintf('TABLE10 VALIDATION PASS: %d\n', table10_validation_pass);
    fprintf('EXCEL EXPORT PASS: %d\n', excel_export_pass);
    fprintf('EXCEL FORMAT PASS: %d\n', excel_format_pass);
    fprintf('MAT SAVE PASS: %d\n', mat_save_pass);
    fprintf('WORD EXPORT PASS: %d\n', word_export_pass);
    fprintf('STATISTICAL WORD EXPORT PASS: %d\n', statistical_word_export_pass);
    fprintf('TIME: %s\n', datestr(now, 31));
    fprintf('ERROR IDENTIFIER: %s\n', ME.identifier);
    fprintf('ERROR MESSAGE: %s\n', ME.message);

    for s = 1:numel(ME.stack)
        fprintf('STACK %d: %s | line %d | %s\n', ...
            s, ME.stack(s).file, ME.stack(s).line, ME.stack(s).name);
    end
    fprintf('============================================================\n');

    error_identifier = ME.identifier;
    error_message = ME.message;
    error_stack = ME.stack;
    failure_time = datestr(now, 31);

    try
        save(output_error_mat, ...
            'analysis_version', ...
            'current_stage', ...
            'failure_time', ...
            'error_identifier', ...
            'error_message', ...
            'error_stack', ...
            'input_mat', ...
            'output_xlsx', ...
            'output_mat', ...
            'output_log', ...
            'output_docx', ...
            'output_stats_docx', ...
            'raw_data_validation_pass', ...
            'variant_validation_pass', ...
            'descriptive_validation_pass', ...
            'friedman_validation_pass', ...
            'wilcoxon_validation_pass', ...
            'statistical_validation_pass', ...
            'table10_validation_pass', ...
            'excel_export_pass', ...
            'excel_format_pass', ...
            'mat_save_pass', ...
            'word_export_pass', ...
            'statistical_word_export_pass', ...
            '-v7.3');
        fprintf('Emergency Error MAT written: %s\n', output_error_mat);
    catch ME_save_error
        fprintf('WARNING: Emergency Error MAT could not be written: %s\n', ...
            ME_save_error.message);
    end

    rethrow(ME);
end


%% LOCAL FUNCTIONS

function input_file = resolveInputFile(input_name, script_dir)
% Resolve the required input first beside the script, then from pwd.

    candidates = { ...
        fullfile(script_dir, input_name), ...
        fullfile(pwd, input_name)};

    input_file = '';

    for k = 1:numel(candidates)
        if exist(candidates{k}, 'file') == 2
            input_file = candidates{k};
            break;
        end
    end

    if isempty(input_file)
        error('Required input MAT not found: %s', input_name);
    end
end


function validateAblationDefinitions(definitions, expected_algorithms)
% Validate the recovered V0-V7 experimental definitions exactly.
%
% Authoritative recovered schema is ROW-ORIENTED:
%
%   Row 1: Variant | Experimental Name | Interpretation | TC | DFF | G1 | G2 | EGT | SR
%   Row 2: V0      | AVOA              | ...            | ...
%   ...
%   Row 9: V7      | DFFG-AVOA7        | ...            | ...
%
% Final3 incorrectly treated these row headers as if they occupied the first
% column. Final4 validates the actual recovered MAT schema.

    assert(iscell(definitions) && isequal(size(definitions), [9, 9]), ...
        'ablation_definitions must be a 9 x 9 cell array.');

    expected_header = { ...
        'Variant', 'Experimental Name', 'Interpretation', ...
        'TC', 'DFF', 'G1', 'G2', 'EGT', 'SR'};

    for c = 1:9
        assert(strcmp(char(string(definitions{1,c})), expected_header{c}), ...
            'Ablation-definition header mismatch at column %d.', c);
    end

    expected_variants = ["V0";"V1";"V2";"V3";"V4";"V5";"V6";"V7"];

    expected_interpretations = [ ...
        "Original AVOA reference"; ...
        "TC-AVOA"; ...
        "TC-DFF-AVOA"; ...
        "TC-DFF-G1-AVOA"; ...
        "TC-DFF-G2-AVOA"; ...
        "TC-DFF-EGT-AVOA"; ...
        "TC-DFF-SR-AVOA"; ...
        "Full proposed DFFG-AVOA"];

    % Rows V0-V7; mechanism columns TC,DFF,G1,G2,EGT,SR.
    expected_flags = [ ...
        0 0 0 0 0 0; ... % V0
        1 0 0 0 0 0; ... % V1
        1 1 0 0 0 0; ... % V2
        1 1 1 0 0 0; ... % V3
        1 1 0 1 0 0; ... % V4
        1 1 0 0 1 0; ... % V5
        1 1 0 0 0 1; ... % V6
        1 1 1 1 1 1];    % V7

    for r = 1:8
        rr = r + 1;

        assert(string(definitions{rr,1}) == expected_variants(r), ...
            'Variant label mismatch at row %d.', rr);

        assert(string(definitions{rr,2}) == expected_algorithms(r), ...
            'Experimental name mismatch for %s.', expected_variants(r));

        assert(string(definitions{rr,3}) == expected_interpretations(r), ...
            'Interpretation mismatch for %s.', expected_variants(r));

        for m = 1:6
            observed = definitions{rr, m+3};

            assert(isnumeric(observed) && isscalar(observed) && isfinite(observed), ...
                'Mechanism flag must be one finite numeric scalar at row %d col %d.', ...
                rr, m+3);

            assert(double(observed) == expected_flags(r,m), ...
                'Mechanism flag mismatch for %s at mechanism column %d.', ...
                expected_variants(r), m);
        end
    end
end


function assertMatrixMatch(A, B, label)
% Strict numerical comparison with special handling for subnormal-scale values.

    assert(isequal(size(A), size(B)), ...
        '%s size mismatch.', label);
    assert(all(isfinite(A), 'all') && all(isfinite(B), 'all'), ...
        '%s contains non-finite values.', label);

    scale = max(abs(A), abs(B));
    normal_mask = scale > 1e-300;
    tiny_mask = ~normal_mask;

    if any(normal_mask, 'all')
        rel = abs(A(normal_mask) - B(normal_mask)) ./ ...
            max(scale(normal_mask), realmin);
        max_rel = max(rel);
    else
        max_rel = 0;
    end

    if any(tiny_mask, 'all')
        max_tiny_abs = max(abs(A(tiny_mask) - B(tiny_mask)));
    else
        max_tiny_abs = 0;
    end

    assert(max_rel <= 1e-10, ...
        '%s relative mismatch exceeds tolerance: %.3e.', ...
        label, max_rel);

    % The recovered study contains legitimate subnormal-scale values.
    % The tolerance below is many orders smaller than any manuscript-scale
    % reported value while avoiding false failure from subnormal arithmetic.
    assert(max_tiny_abs <= 1e-300, ...
        '%s practical-zero absolute mismatch exceeds tolerance: %.3e.', ...
        label, max_tiny_abs);
end


function ranks = strictLexicographicRanks(mean_values, std_values, best_values)
% Reproduce the rank rule validated during recovery:
% lower Mean is better; exact Mean ties are resolved by lower Std;
% exact Mean+Std ties are resolved by lower Best; exact triples share rank.

    [num_functions, num_algorithms] = size(mean_values);
    ranks = nan(num_functions, num_algorithms);

    for f = 1:num_functions
        rank_matrix = [ ...
            mean_values(f, :)', ...
            std_values(f, :)', ...
            best_values(f, :)'];

        valid_algorithms = all(~isnan(rank_matrix), 2);
        valid_idx = find(valid_algorithms);

        if isempty(valid_idx)
            continue;
        end

        temp = rank_matrix(valid_idx, :);
        [~, sorted_local] = sortrows(temp, [1 2 3]);
        sorted_idx = valid_idx(sorted_local);

        current_rank = 1;
        ranks(f, sorted_idx(1)) = current_rank;

        for k = 2:numel(sorted_idx)
            prev = rank_matrix(sorted_idx(k-1), :);
            curr = rank_matrix(sorted_idx(k), :);

            if isequal(prev, curr)
                ranks(f, sorted_idx(k)) = current_rank;
            else
                current_rank = k;
                ranks(f, sorted_idx(k)) = current_rank;
            end
        end
    end
end


function txt = formatPValue(p)
% Match the accepted V4.4.1 manuscript-style Wilcoxon p-value display.
% Full precision remains in the audit tables and Results MAT.

    if ~isfinite(p)
        txt = 'NaN';
        return;
    end

    txt = sprintf('%.3E', p);
end


function text_value = formatBenchmarkDisplay(value)
% Established manuscript descriptive-table display:
% uppercase E, two digits after decimal in mantissa.

    assert(isnumeric(value) && isscalar(value) && isfinite(value), ...
        'Display value must be one finite numeric scalar.');

    text_value = sprintf('%.2E', value);

    assert(~isempty(regexp(text_value, ...
        '^-?\d\.\d{2}E[+-]\d{2,3}$', 'once')), ...
        'Unexpected scientific-notation display string: %s', text_value);
end


function validation = validateTable10Display( ...
        table10, function_display_names, expected_algorithms, ...
        mean_values, std_values, best_values, rank_values)
% Validate every manuscript-facing Table 10 cell against the validated arrays.

    assert(isequal(size(table10), [93, 10]), ...
        'Table 10 dimensions must be 93 x 10.');

    expected_header = [ ...
        {'Functions', 'Metric'}, ...
        cellstr(expected_algorithms')];

    assert(isequal(table10(1,:), expected_header), ...
        'Table 10 header does not match the frozen variant order.');

    metric_names = {'Mean', 'Std', 'Best', 'Rank'};
    source_arrays = {mean_values, std_values, best_values, rank_values};

    checked = 0;
    scientific_cells = 0;
    rank_cells = 0;

    for f = 1:23
        start_row = 2 + (f-1)*4;

        for m = 1:4
            r = start_row + m - 1;

            assert(strcmp(char(string(table10{r,1})), ...
                function_display_names{f}), ...
                'Function label mismatch at F%d metric row %d.', f, m);

            assert(strcmp(char(string(table10{r,2})), metric_names{m}), ...
                'Metric label mismatch at F%d.', f);

            for a = 1:8
                observed = char(string(table10{r,a+2}));
                source_value = source_arrays{m}(f,a);

                if m <= 3
                    expected = sprintf('%.2E', source_value);
                    assert(strcmp(observed, expected), ...
                        ['Display mismatch at F%d %s %s: ' ...
                         'observed=%s expected=%s'], ...
                        f, metric_names{m}, expected_algorithms(a), ...
                        observed, expected);

                    assert(~isempty(regexp(observed, ...
                        '^-?\d\.\d{2}E[+-]\d{2,3}$', 'once')), ...
                        'Scientific notation format mismatch: %s', observed);
                    scientific_cells = scientific_cells + 1;
                else
                    expected = sprintf('%d', source_value);
                    assert(strcmp(observed, expected), ...
                        'Rank display mismatch at F%d %s.', ...
                        f, expected_algorithms(a));
                    rank_cells = rank_cells + 1;
                end

                checked = checked + 1;
            end
        end
    end

    assert(checked == 23*4*8, ...
        'Unexpected Table 10 display validation count.');
    assert(scientific_cells == 23*3*8, ...
        'Unexpected scientific-display validation count.');
    assert(rank_cells == 23*8, ...
        'Unexpected Rank-display validation count.');

    validation = struct();
    validation.DisplayCellsChecked = checked;
    validation.ScientificCellsChecked = scientific_cells;
    validation.RankCellsChecked = rank_cells;
    validation.DisplayFormat = '%.2E';
    validation.UppercaseE = true;
    validation.TwoMantissaDecimalPlaces = true;
    validation.RankIntegerDisplay = true;
end


function formatTable10Workbook(output_xlsx, table_rows, table_cols)
% Presentation-only Excel formatting for the manuscript-facing Table 10 sheet.
% If Excel COM is unavailable, the caller retains the already-valid workbook.

    if ~ispc
        error('Excel COM formatting requires Windows.');
    end

    excel = [];
    workbook = [];

    try
        excel = actxserver('Excel.Application');
        excel.Visible = false;
        excel.DisplayAlerts = false;

        workbook = excel.Workbooks.Open(output_xlsx);
        sheet = workbook.Worksheets.Item('Table 10');

        % Table begins at A4 and is table_rows x table_cols.
        last_row = 3 + table_rows;
        last_col = table_cols;
        table_range = sheet.Range(sheet.Cells(4,1), ...
            sheet.Cells(last_row,last_col));

        table_range.Font.Name = 'Times New Roman';
        table_range.Font.Size = 8;
        table_range.HorizontalAlignment = -4108; % xlCenter
        table_range.VerticalAlignment = -4108;   % xlCenter
        table_range.WrapText = true;
        table_range.Borders.LineStyle = 1;

        header_range = sheet.Range(sheet.Cells(4,1), ...
            sheet.Cells(4,last_col));
        header_range.Font.Bold = true;

        sheet.Range('A1:J2').Font.Name = 'Times New Roman';
        sheet.Range('A1:J2').Font.Size = 10;
        sheet.Range('A1:A2').Font.Bold = true;

        % Approximate Excel widths chosen to mirror the Word table hierarchy.
        sheet.Columns.Item(1).ColumnWidth = 24;
        sheet.Columns.Item(2).ColumnWidth = 10;
        for c = 3:10
            sheet.Columns.Item(c).ColumnWidth = 15;
        end

        % Merge each function label over its Mean/Std/Best/Rank block.
        % Table header is on row 4; first function begins row 5.
        for f = 23:-1:1
            start_row = 5 + (f-1)*4;
            end_row = start_row + 3;
            merge_range = sheet.Range( ...
                sheet.Cells(start_row,1), sheet.Cells(end_row,1));
            merge_range.Merge;
            merge_range.HorizontalAlignment = -4108;
            merge_range.VerticalAlignment = -4108;
        end

        % A4 portrait / 1 cm margins / one page wide.
        page = sheet.PageSetup;
        page.Orientation = 1; % xlPortrait
        page.PaperSize = 9;   % xlPaperA4
        one_cm = excel.CentimetersToPoints(1.0);
        page.LeftMargin = one_cm;
        page.RightMargin = one_cm;
        page.TopMargin = one_cm;
        page.BottomMargin = one_cm;
        page.PrintTitleRows = '$4:$4';
        page.Zoom = false;
        page.FitToPagesWide = 1;
        page.FitToPagesTall = false;

        workbook.Save;
        workbook.Close(false);
        excel.Quit;
        delete(excel);

    catch ME
        try
            if ~isempty(workbook)
                workbook.Close(false);
            end
        catch
        end
        try
            if ~isempty(excel)
                excel.Quit;
                delete(excel);
            end
        catch
        end
        rethrow(ME);
    end
end


function validation = generateNativeWordTable10( ...
        output_docx, table10, table10_caption, ...
        function_display_names, expected_algorithms)
% Create exactly ONE native Microsoft Word manuscript table.
% Layout follows the established descriptive benchmark Tables 10-12:
% A4 portrait, 1 cm margins, Times New Roman, 8 pt table text,
% fixed widths 3.40 / 1.20 / eight x 1.80 cm, no AutoFit,
% repeated header row, and function labels vertically merged across
% Mean/Std/Best/Rank.

    if ~ispc
        error(['Native Word-table generation requires Windows and ' ...
               'Microsoft Word COM automation.']);
    end

    assert(isequal(size(table10), [93, 10]), ...
        'Word Table 10 input must be exactly 93 x 10.');

    if exist(output_docx, 'file') == 2
        delete(output_docx);
    end

    word = [];
    doc = [];
    current_word_substage = "WORD_INITIALISATION";

    % Word constants.
    wdAlignParagraphCenter = 1;
    wdCellAlignVerticalCenter = 1;
    wdAutoFitFixed = 0;
    wdAdjustNone = 0;
    wdPaperA4 = 7;
    wdOrientPortrait = 0;
    wdFormatDocumentDefault = 16;
    points_per_cm = 28.3464567;

    try
        word = actxserver('Word.Application');
        word.Visible = false;
        word.DisplayAlerts = 0;

        doc = word.Documents.Add;
        doc.PageSetup.PaperSize = wdPaperA4;
        doc.PageSetup.Orientation = wdOrientPortrait;

        margin_points = 1.0 * points_per_cm;
        doc.PageSetup.TopMargin = margin_points;
        doc.PageSetup.BottomMargin = margin_points;
        doc.PageSetup.LeftMargin = margin_points;
        doc.PageSetup.RightMargin = margin_points;

        selection = word.Selection;

        current_word_substage = "TABLE10_CAPTION";
        addWordCaption(selection, 10, table10_caption);

        current_word_substage = "TABLE10_CREATION";
        w10 = doc.Tables.Add(selection.Range, ...
            size(table10,1), size(table10,2));

        populateWordTable(w10, table10);

        formatCommonWordTable(w10, 8, wdAlignParagraphCenter, ...
            wdCellAlignVerticalCenter, wdAutoFitFixed);

        % Fixed total width = 19.00 cm, matching the accepted descriptive
        % benchmark-table architecture.
        w10.Columns.Item(1).SetWidth(3.40 * points_per_cm, wdAdjustNone);
        w10.Columns.Item(2).SetWidth(1.20 * points_per_cm, wdAdjustNone);
        for c = 3:10
            w10.Columns.Item(c).SetWidth(1.80 * points_per_cm, wdAdjustNone);
        end

        w10.AllowAutoFit = 0;
        w10.AutoFitBehavior(wdAutoFitFixed);

        % Perform all row-level operations before vertical merges.
        w10.Rows.Item(1).Range.Font.Bold = true;
        w10.Rows.Item(1).HeadingFormat = -1;
        w10.Rows.AllowBreakAcrossPages = 0;

        current_word_substage = "TABLE10_FUNCTION_MERGE";

        % Merge bottom-to-top for stable Word COM addressing.
        for f = 23:-1:1
            start_row = 2 + (f-1)*4;
            end_row = start_row + 3;

            label = function_display_names{f};
            top_cell = w10.Cell(start_row,1);
            bottom_cell = w10.Cell(end_row,1);

            top_cell.Merge(bottom_cell);
            top_cell.Range.Text = label;
            top_cell.Range.ParagraphFormat.Alignment = ...
                wdAlignParagraphCenter;
            top_cell.VerticalAlignment = wdCellAlignVerticalCenter;
        end

        w10.AllowAutoFit = 0;
        w10.AutoFitBehavior(wdAutoFitFixed);

        assert(doc.Tables.Count == 1, ...
            'Expected exactly one native Word table.');

        current_word_substage = "DOCX_SAVE";

        try
            doc.SaveAs2(output_docx, wdFormatDocumentDefault);
        catch
            doc.SaveAs(output_docx, wdFormatDocumentDefault);
        end

        doc.Close(false);
        word.Quit;
        delete(word);
        word = [];
        doc = [];

    catch ME
        fprintf('  WORD SUBSTAGE FAILED: %s\n', current_word_substage);

        try
            if ~isempty(doc)
                doc.Close(false);
            end
        catch
        end

        try
            if ~isempty(word)
                word.Quit;
                delete(word);
            end
        catch
        end

        rethrow(ME);
    end

    assert(exist(output_docx, 'file') == 2, ...
        'Word document was not created: %s', output_docx);

    info = dir(output_docx);
    assert(~isempty(info) && info.bytes > 0, ...
        'Word document exists but is empty: %s', output_docx);

    % Re-open the saved document and verify it remains one native table and
    % contains essential manuscript-transfer text.
    current_word_substage = "DOCX_REOPEN_VALIDATION"; %#ok<NASGU>
    word2 = [];
    doc2 = [];

    try
        word2 = actxserver('Word.Application');
        word2.Visible = false;
        word2.DisplayAlerts = 0;
        doc2 = word2.Documents.Open(output_docx, false, true);

        assert(doc2.Tables.Count == 1, ...
            'Saved DOCX does not contain exactly one native Word table.');

        doc_text = string(doc2.Content.Text);

        required_text = [ ...
            "Table 10."; ...
            string(table10_caption); ...
            "AVOA"; ...
            expected_algorithms(end); ...
            "F1 (Sphere)"; ...
            "F23 (Shekel 10)"; ...
            "Mean"; ...
            "Std"; ...
            "Best"; ...
            "Rank"];

        for k = 1:numel(required_text)
            assert(contains(doc_text, required_text(k)), ...
                'Saved DOCX is missing required text: %s', required_text(k));
        end

        doc2.Close(false);
        word2.Quit;
        delete(word2);
        word2 = [];
        doc2 = [];

    catch ME
        try
            if ~isempty(doc2)
                doc2.Close(false);
            end
        catch
        end
        try
            if ~isempty(word2)
                word2.Quit;
                delete(word2);
            end
        catch
        end
        rethrow(ME);
    end

    validation = struct();
    validation.OutputFile = output_docx;
    validation.FileBytes = info.bytes;
    validation.TableCount = 1;
    validation.Table10RowsBeforeMerge = 93;
    validation.Table10Columns = 10;
    validation.FunctionBlocks = 23;
    validation.MetricsPerFunction = 4;
    validation.NativeWordTable = true;
    validation.A4Portrait = true;
    validation.MarginCm = 1.0;
    validation.FixedWidths = true;
    validation.TotalWidthCm = 19.0;
    validation.FontName = 'Times New Roman';
    validation.TableFontSizePt = 8;
    validation.CaptionFontSizePt = 10;
    validation.HeaderRepeats = true;
    validation.RowsDoNotSplit = true;
    validation.FunctionCellsVerticallyMerged = true;
    validation.ReopenValidation = true;
end


function validation = generateNativeWordStatisticalSupport( ...
        output_docx, friedman_table, wilcoxon_table, expected_algorithms)
% Create two actual native Word statistical-support tables.
% These are intentionally NOT assigned manuscript Table 11/12 numbers.
% They are ready for supervisor review and later manuscript insertion if requested.

    if ~ispc
        error(['Native Word statistical-support generation requires Windows ' ...
               'and Microsoft Word COM automation.']);
    end

    if exist(output_docx, 'file') == 2
        delete(output_docx);
    end

    word = [];
    doc = [];

    wdAlignParagraphCenter = 1;
    wdCellAlignVerticalCenter = 1;
    wdAutoFitFixed = 0;
    wdAdjustNone = 0;
    wdPaperA4 = 7;
    wdOrientLandscape = 1;
    wdPageBreak = 7;
    wdFormatDocumentDefault = 16;
    points_per_cm = 28.3464567;

    try
        word = actxserver('Word.Application');
        word.Visible = false;
        word.DisplayAlerts = 0;

        doc = word.Documents.Add;
        doc.PageSetup.PaperSize = wdPaperA4;
        doc.PageSetup.Orientation = wdOrientLandscape;

        margin_points = 1.0 * points_per_cm;
        doc.PageSetup.TopMargin = margin_points;
        doc.PageSetup.BottomMargin = margin_points;
        doc.PageSetup.LeftMargin = margin_points;
        doc.PageSetup.RightMargin = margin_points;

        selection = word.Selection;

        % ---------------- Friedman support table ----------------
        selection.Font.Name = 'Times New Roman';
        selection.Font.Size = 10;
        selection.Font.Bold = true;
        selection.TypeText(['Supporting Statistical Table - Friedman Ranking ' ...
            'of the DFFG-AVOA Ablation Variants Across F1-F23']);
        selection.TypeParagraph;
        selection.Font.Bold = false;

        wf = doc.Tables.Add(selection.Range, ...
            size(friedman_table,1), size(friedman_table,2));

        populateWordTable(wf, friedman_table);
        formatCommonWordTable(wf, 8, wdAlignParagraphCenter, ...
            wdCellAlignVerticalCenter, wdAutoFitFixed);

        wf.Columns.Item(1).SetWidth(2.40 * points_per_cm, wdAdjustNone);
        for c = 2:size(friedman_table,2)
            wf.Columns.Item(c).SetWidth(2.75 * points_per_cm, wdAdjustNone);
        end
        wf.Rows.Item(1).Range.Font.Bold = true;
        wf.Rows.Item(1).HeadingFormat = -1;
        wf.Rows.AllowBreakAcrossPages = 0;

        % Move insertion point after the table and add a page break.
        selection.SetRange(doc.Content.End - 1, doc.Content.End - 1);
        selection.TypeParagraph;
        selection.InsertBreak(wdPageBreak);

        % ---------------- Wilcoxon support table ----------------
        selection.SetRange(doc.Content.End - 1, doc.Content.End - 1);
        selection.Font.Name = 'Times New Roman';
        selection.Font.Size = 10;
        selection.Font.Bold = true;
        selection.TypeText(['Supporting Statistical Table - Pairwise Two-Sided ' ...
            'Wilcoxon Rank-Sum Tests: DFFG-AVOA7 Versus V0-V6']);
        selection.TypeParagraph;
        selection.Font.Bold = false;

        ww = doc.Tables.Add(selection.Range, ...
            size(wilcoxon_table,1), size(wilcoxon_table,2));

        populateWordTable(ww, wilcoxon_table);
        formatCommonWordTable(ww, 7, wdAlignParagraphCenter, ...
            wdCellAlignVerticalCenter, wdAutoFitFixed);

        ww.Columns.Item(1).SetWidth(1.25 * points_per_cm, wdAdjustNone);
        for c = 2:size(wilcoxon_table,2)
            within_group = mod(c-2, 3);
            if within_group == 0
                width_cm = 1.35; % p-value
            elseif within_group == 1
                width_cm = 0.65; % H
            else
                width_cm = 0.65; % S
            end
            ww.Columns.Item(c).SetWidth(width_cm * points_per_cm, wdAdjustNone);
        end

        ww.Rows.Item(1).Range.Font.Bold = true;
        ww.Rows.Item(2).Range.Font.Bold = true;
        ww.Rows.Item(1).HeadingFormat = -1;
        ww.Rows.Item(2).HeadingFormat = -1;
        ww.Rows.AllowBreakAcrossPages = 0;

        % Merge the first-row comparator labels over p/H/S triplets.
        % Bottom-to-top / right-to-left stabilizes COM addressing.
        for g = 7:-1:1
            start_col = 2 + (g-1)*3;
            comparator_label = char(expected_algorithms(g));
            top_cell = ww.Cell(1,start_col);
            end_cell = ww.Cell(1,start_col+2);
            top_cell.Merge(end_cell);
            top_cell.Range.Text = comparator_label;
            top_cell.Range.ParagraphFormat.Alignment = wdAlignParagraphCenter;
            top_cell.VerticalAlignment = wdCellAlignVerticalCenter;
        end

        assert(doc.Tables.Count == 2, ...
            'Expected exactly two native statistical-support Word tables.');

        try
            doc.SaveAs2(output_docx, wdFormatDocumentDefault);
        catch
            doc.SaveAs(output_docx, wdFormatDocumentDefault);
        end

        doc.Close(false);
        word.Quit;
        delete(word);
        word = [];
        doc = [];

    catch ME
        try
            if ~isempty(doc)
                doc.Close(false);
            end
        catch
        end
        try
            if ~isempty(word)
                word.Quit;
                delete(word);
            end
        catch
        end
        rethrow(ME);
    end

    assert(exist(output_docx, 'file') == 2, ...
        'Statistical-support Word document was not created.');
    info = dir(output_docx);
    assert(~isempty(info) && info.bytes > 0, ...
        'Statistical-support Word document exists but is empty.');

    word2 = [];
    doc2 = [];
    try
        word2 = actxserver('Word.Application');
        word2.Visible = false;
        word2.DisplayAlerts = 0;
        doc2 = word2.Documents.Open(output_docx, false, true);

        assert(doc2.Tables.Count == 2, ...
            'Saved statistical-support DOCX must contain exactly two native tables.');

        body_text = string(doc2.Content.Text);
        assert(contains(body_text, "Friedman"), ...
            'Saved statistical-support DOCX is missing Friedman text.');
        assert(contains(body_text, "Wilcoxon"), ...
            'Saved statistical-support DOCX is missing Wilcoxon text.');
        assert(contains(body_text, "DFFG-AVOA7"), ...
            'Saved statistical-support DOCX is missing the full-reference label.');
        assert(contains(body_text, "(W|L|T)"), ...
            'Saved statistical-support DOCX is missing W|L|T summary.');

        doc2.Close(false);
        word2.Quit;
        delete(word2);

    catch ME
        try
            if ~isempty(doc2)
                doc2.Close(false);
            end
        catch
        end
        try
            if ~isempty(word2)
                word2.Quit;
                delete(word2);
            end
        catch
        end
        rethrow(ME);
    end

    validation = struct();
    validation.OutputFile = output_docx;
    validation.FileBytes = info.bytes;
    validation.TableCount = 2;
    validation.FriedmanTableProduced = true;
    validation.WilcoxonTableProduced = true;
    validation.ManuscriptNumbersAssigned = false;
    validation.A4Landscape = true;
    validation.MarginCm = 1.0;
    validation.FontName = 'Times New Roman';
    validation.ReopenValidation = true;
end


function addWordCaption(selection, table_number, caption_text)
    selection.Font.Name = 'Times New Roman';
    selection.Font.Size = 10;
    selection.Font.Bold = true;
    selection.TypeText(sprintf('Table %d. %s', table_number, caption_text));
    selection.TypeParagraph;
    selection.Font.Bold = false;
end


function populateWordTable(word_table, cell_matrix)
    for r = 1:size(cell_matrix,1)
        for c = 1:size(cell_matrix,2)
            setWordCellText(word_table.Cell(r,c), cell_matrix{r,c});
        end
    end
end


function setWordCellText(cell_object, value)
    if isstring(value)
        text_value = char(value);
    elseif ischar(value)
        text_value = value;
    elseif isnumeric(value) && isscalar(value)
        text_value = num2str(value);
    else
        text_value = char(string(value));
    end

    cell_object.Range.Text = text_value;
end


function formatCommonWordTable(word_table, font_size, align_center, ...
        vertical_center, wdAutoFitFixed)

    word_table.Borders.Enable = 1;
    word_table.Rows.Alignment = align_center;
    word_table.Range.Font.Name = 'Times New Roman';
    word_table.Range.Font.Size = font_size;
    word_table.Range.ParagraphFormat.Alignment = align_center;
    word_table.Range.ParagraphFormat.SpaceBefore = 0;
    word_table.Range.ParagraphFormat.SpaceAfter = 0;
    word_table.Range.Cells.VerticalAlignment = vertical_center;
    word_table.TopPadding = 0;
    word_table.BottomPadding = 0;
    word_table.LeftPadding = 0.5;
    word_table.RightPadding = 0.5;
    word_table.AllowAutoFit = 0;
    word_table.AutoFitBehavior(wdAutoFitFixed);
end
