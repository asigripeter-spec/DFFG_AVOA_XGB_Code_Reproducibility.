# DFFG-AVOA Ablation Study

## Purpose

This folder contains the MATLAB code, archived experimental outputs, recovery materials, statistical-analysis files, and manuscript-facing outputs for the controlled DFFG-AVOA mechanism-level ablation study.

The reported ablation experiment evaluates the original AVOA reference and seven controlled DFFG-AVOA variants on the 23 mathematical benchmark functions `F1–F23`.

The files in this folder form an integrated workflow. Generated files should not be removed merely because they appear to be intermediate outputs: several archived outputs are direct inputs to later analysis, while others preserve the audit trail of the reported experiment.

---

## Reported Experimental Configuration

The supplied main driver is currently configured as:

```matlab
problem_family  = 'Math';
experiment_mode = 'full';

N        = 30;
Max_iter = 500;
num_runs = 30;
```

Therefore, the reported packaged ablation study consists of:

- 23 mathematical benchmark functions: `F1–F23`;
- 8 configurations: `V0–V7`;
- population size: `30`;
- maximum iterations: `500`;
- independent runs per function/configuration: `30`.

The driver also contains routing for engineering and MLP problems, but the present ablation package contains the support files required for the reported mathematical `F1–F23` study. The documentation below therefore addresses that packaged study.

---

## Ablation Variants

The locked variant definitions are recorded in:

`DFFG_AVOA_Ablation_Variant_Specification.txt`

The configurations are:

| Variant | Experimental name | Interpretation | TC | DFF | G1 | G2 | EGT | SR |
|---|---|---|---:|---:|---:|---:|---:|---:|
| V0 | AVOA | Original AVOA reference | 0 | 0 | 0 | 0 | 0 | 0 |
| V1 | DFFG-AVOA1 | TC-AVOA | 1 | 0 | 0 | 0 | 0 | 0 |
| V2 | DFFG-AVOA2 | TC-DFF-AVOA | 1 | 1 | 0 | 0 | 0 | 0 |
| V3 | DFFG-AVOA3 | TC-DFF-G1-AVOA | 1 | 1 | 1 | 0 | 0 | 0 |
| V4 | DFFG-AVOA4 | TC-DFF-G2-AVOA | 1 | 1 | 0 | 1 | 0 | 0 |
| V5 | DFFG-AVOA5 | TC-DFF-EGT-AVOA | 1 | 1 | 0 | 0 | 1 | 0 |
| V6 | DFFG-AVOA6 | TC-DFF-SR-AVOA | 1 | 1 | 0 | 0 | 0 | 1 |
| V7 | DFFG-AVOA7 | Full proposed DFFG-AVOA | 1 | 1 | 1 | 1 | 1 | 1 |

Mechanism abbreviations:

- `TC` — tent-chaotic initialization;
- `DFF` — Dynamic Flock Fragmentation and localized sub-flock AVOA search;
- `G1` — Gaussian-assisted rotational-flight perturbation;
- `G2` — Gaussian refinement, including the reliability-filtered alternative-center boosted G2 logic where its activation conditions are satisfied;
- `EGT` — directional elite-guided tightening plus elite-centroid contraction;
- `SR` — elite preservation plus stagnation-triggered selective restart.

`V0` is deliberately external to `DFFG_AVOA_Ablation.m` and calls the supplied `AVOA.m`. Variants `V1–V7` are controlled through `DFFG_AVOA_Ablation.m`.

---

## Principal Source Files

### `DFFG_Main_Ablation_Study.m`

Main experiment driver.

For the packaged reported configuration, it runs all eight variants across `F1–F23`, 30 times per function/configuration, and generates the experiment workbook, log, raw-results MAT file, individual convergence figures, and composite convergence figures.

### `DFFG_AVOA_Ablation.m`

Controlled ablation implementation of DFFG-AVOA.

The mechanism switches determine which accepted DFFG-AVOA components are active for `V1–V7`.

### `AVOA.m`

Original AVOA reference implementation used for `V0`.

### `benchmark_functions.m`

Definitions of the 23 mathematical benchmark functions.

### `fun_info.m`

Routing wrapper used by the main driver to obtain the benchmark bounds, dimensionality, and objective function from `benchmark_functions.m`.

### `levy.m`

Supporting Lévy-flight function used by the optimization implementation.

---

# Workflow A — Full Ablation Rerun from Source

## 1. Keep the required MATLAB files together

For the reported mathematical study, keep at least the following files available in the same working folder or on the MATLAB path:

```text
DFFG_Main_Ablation_Study.m
DFFG_AVOA_Ablation.m
AVOA.m
benchmark_functions.m
fun_info.m
levy.m
```

Do not rename the files unless the corresponding MATLAB calls are also changed.

## 2. Use the debug mode first

The locked variant specification recommends first changing:

```matlab
experiment_mode = 'debug';
```

For the mathematical family, debug mode runs `F5`.

This permits confirmation that the required files are visible to MATLAB and that the expected outputs can be created before the complete experiment is started.

After the debug check, restore:

```matlab
experiment_mode = 'full';
```

for the complete `F1–F23` experiment.

## 3. Run the main driver

Run:

```text
DFFG_Main_Ablation_Study.m
```

The full reported configuration performs:

```text
23 functions × 8 configurations × 30 independent runs
```

and records the resulting final objective values and summary statistics.

## 4. Important overwrite warning

The main driver uses fixed output names:

```text
DFFG_AVOA_Ablation_Study_Statistics.xlsx
DFFG_AVOA_Ablation_Study_RawResults.mat
DFFG_AVOA_Ablation_Study_Log.txt
DFFG_AVOA_Ablation_Study_Figures/
DFFG_AVOA_Ablation_Study_Composite_Plots/
```

At startup, the driver deletes an existing workbook and raw-results MAT file with those names before creating new ones.

**Do not run a new experiment directly over the archived reference package unless overwriting the supplied reference files is intentional.**

For an independent rerun, use a copy of this folder or change the output naming/location in the driver.

## 5. Stochastic reproducibility

The supplied main driver does not set a fixed MATLAB random-number seed.

Consequently, a complete rerun should be treated as reproduction of the experimental procedure, not as a guarantee that every numerical value will be bit-for-bit identical to the archived reference run.

This is particularly relevant because the optimization algorithms are stochastic and benchmark `F7` also contains a random-noise term in its supplied definition.

---

# Outputs from the Main Ablation Experiment

## `DFFG_AVOA_Ablation_Study_Statistics.xlsx`

Primary experiment workbook.

The supplied workbook contains:

- one sheet for each benchmark function `F1–F23`;
- raw 30-run final objective values for all eight variants;
- the per-function descriptive statistics;
- `Journal_Summary`.

This workbook is also an input to the raw-results recovery workflow described below.

## `DFFG_AVOA_Ablation_Study_Log.txt`

Persistent console/diary record from the ablation experiment.

The supplied final complete run recorded all `5520` expected run records:

```text
23 functions × 8 configurations × 30 runs = 5520
```

The log is also an input to the raw-results recovery workflow.

## `DFFG_AVOA_Ablation_Study_RawResults.mat`

Authoritative raw-results MAT used by the current manuscript-facing Final4 statistical workflow.

The supplied copy contains explicit recovery provenance because it was reconstructed from the surviving experiment workbook and final complete study log after the originally intended raw MAT required recovery.

The recovery audit confirms that the optimization itself was **not rerun** during that reconstruction.

The recovered MAT preserves the raw 30-run score cube and validated descriptive results required for the downstream Table 10/statistical workflow.

Original in-memory convergence histories, best-position vectors, and best-design vectors were not present in the surviving workbook/log and therefore were not fabricated during recovery. Their corresponding recovered MAT fields remain empty placeholders.

## `DFFG_AVOA_Ablation_Study_Figures/`

Contains the saved per-function convergence figures in both:

```text
.fig
.png
```

for `F1–F23`.

The folder also contains:

`DFFG_Ablation_Friedman_Wilcoxon_Final1.m`

which is a separate supporting statistical-analysis script based on the completed experiment workbook. It has its own input/output workflow and is distinct from the current manuscript-facing Final4 Table 10 workflow.

## `DFFG_AVOA_Ablation_Study_Composite_Plots/`

Contains the saved composite convergence plots:

```text
Composite_F1_to_F8.fig
Composite_F1_to_F8.png

Composite_F9_to_F16.fig
Composite_F9_to_F16.png

Composite_F17_to_F23.fig
Composite_F17_to_F23.png
```

---

# Workflow B — Reproduce the Current Table 10 and Supporting Statistics

The current manuscript-facing downstream workflow is:

```text
DFFG_AVOA_Ablation_Study_RawResults.mat
        │
        ▼
DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4.m
        │
        ├── DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4.xlsx
        ├── DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4_Results.mat
        ├── DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4_Log.txt
        ├── DFFG_AVOA_Ablation_Table10_Word_Final4.docx
        └── DFFG_AVOA_Ablation_Statistical_Support_Word_Final4.docx
```

## Required input

Keep:

```text
DFFG_AVOA_Ablation_Study_RawResults.mat
DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4.m
```

in the same folder, or otherwise modify the input-resolution logic deliberately.

Then run:

```text
DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4.m
```

The script validates that the input corresponds to:

- 23 functions (`F1–F23`);
- 8 variants (`V0–V7`);
- 30 runs;
- `N = 30`;
- `Max_iter = 500`.

It recomputes and validates the stored descriptive quantities from the raw 30-run values and performs the supporting Friedman and pairwise Wilcoxon rank-sum analyses.

## Current Final4 outputs

### `DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4.xlsx`

Contains the manuscript-facing Table 10 together with supporting statistical and audit sheets.

The supplied workbook includes:

```text
Table 10
Descriptive_Audit
Friedman_Support
Friedman_Summary
Friedman_Input_Means
Friedman_Ranks_Audit
Friedman_Mean_Ranks
Wilcoxon_Support
Wilcoxon_Full_Audit
Wilcoxon_WLT
Edge_Case_Summary
Variant_Definitions
Validation
Provenance
```

### `DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4_Results.mat`

The **second MAT** in the ablation workflow.

It contains the downstream Table 10/statistical-analysis results and is distinct from the first/raw-results MAT:

```text
DFFG_AVOA_Ablation_Study_RawResults.mat
```

Both MAT files have different roles and should remain in the package.

### `DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4_Log.txt`

Persistent execution and validation log for the Final4 statistical/Table 10 workflow.

The supplied log records successful validation of the raw data, ablation definitions, descriptive statistics, Friedman analysis, Wilcoxon analysis, Table 10, Results MAT, and Word outputs.

The log also records a warning concerning presentation-only Excel COM formatting; the Excel content export itself passed.

### `DFFG_AVOA_Ablation_Table10_Word_Final4.docx`

Native Microsoft Word document containing the manuscript-facing Table 10.

### `DFFG_AVOA_Ablation_Statistical_Support_Word_Final4.docx`

Separate native Microsoft Word document containing the Friedman and Wilcoxon supporting statistical tables.

The Final4 script deliberately keeps these supporting statistical tables separate from the manuscript Table 10 Word file.

---

# Workflow C — Recover the Raw-Results MAT Without Rerunning the Optimization

This recovery pathway is included so that the raw-results MAT can be reconstructed from the surviving experiment evidence if necessary.

Read first:

`DFFG_AVOA_Ablation_RawResults_Recovery_README.txt`

The recovery workflow is:

```text
DFFG_AVOA_Ablation_Study_Statistics.xlsx
                    +
DFFG_AVOA_Ablation_Study_Log.txt
                    │
                    ▼
DFFG_AVOA_Ablation_Recover_RawResults_From_Excel_Log.m
                    │
                    ▼
DFFG_AVOA_Ablation_Study_RawResults.mat
```

Place the recovery script beside:

```text
DFFG_AVOA_Ablation_Study_Statistics.xlsx
DFFG_AVOA_Ablation_Study_Log.txt
```

and run:

```text
DFFG_AVOA_Ablation_Recover_RawResults_From_Excel_Log.m
```

The recovery script does **not** rerun the optimization.

Its documented recovery rule is:

- retain the Excel raw value wherever Excel contains a nonzero value because the workbook preserves greater numerical precision than the printed log;
- where Excel contains zero but the final complete log records a nonzero subnormal value, use the log value;
- recompute and validate Mean, population Std, Best, Worst/Max, MAE, and the descriptive ranks from the recovered raw-score cube;
- do not fabricate convergence histories, best-position vectors, or best-design vectors that were not exported to the surviving workbook/log.

The supplied recovery audit records:

- functions recovered: `23`;
- algorithms recovered: `8`;
- runs per function/algorithm: `30`;
- expected raw run records: `5520`;
- parsed raw run records: `5520`;
- rank mismatches: `0`.

## Recovery-support files

### `DFFG_AVOA_Ablation_Study_RawResults_Recovery_Audit.txt`

Human-readable audit describing the recovery basis, validation checks, unavailable original in-memory fields, and role of the recovered MAT.

### `DFFG_AVOA_Ablation_Study_RawResults_Recovery_Log.txt`

Execution log from the successful recovery run.

### `DFFG_AVOA_Ablation_RawResults_Recovery_README.txt`

Short original recovery instruction file supplied with the recovery workflow.

---

# Historical/Audit Files Retained in the Package

## `DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final3_Error.mat`

Failure-state MAT from the earlier Final3 Table 10/statistical workflow.

## `DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final3_Log.txt`

Log from that earlier Final3 attempt.

The Final4 script documents that Final3 stopped during experiment-identity validation because the ablation-definition cell array was validated with the wrong orientation. Final4 corrects that validation issue without changing the scientific data, statistical method, Table 10 design, or output policy.

These files are retained as part of the computational audit trail. They are not the inputs to the current Final4 workflow.

---

# MATLAB and Software Requirements

The package targets MATLAB R2022b-compatible execution.

The current statistical workflow explicitly requires the **Statistics and Machine Learning Toolbox** for:

```text
friedman
tiedrank
ranksum
```

The supplied optimization code also uses statistical functions where available, including `pdist` and `kmeans`, and `AVOA.m` uses `unifrnd`.

The DFFG-AVOA ablation implementation contains fallback logic for some unavailable clustering/distance functions, but users seeking to reproduce the supplied environment should use the required MATLAB toolboxes rather than rely on altered execution conditions.

Native Word document generation in the Final4 script requires:

- Windows;
- Microsoft Word;
- Microsoft Office COM automation.

Excel numerical content can be generated independently of successful presentation-only COM formatting. The supplied Final4 log records that the content export passed even though one presentation-formatting COM step produced a warning.

---

# Recommended Use Cases

## To verify the published/archived downstream ablation results

Use the supplied:

```text
DFFG_AVOA_Ablation_Study_RawResults.mat
```

with:

```text
DFFG_AVOA_Ablation_Table10_Friedman_Wilcoxon_Final4.m
```

This is the shortest route to reproducing the current Table 10 and its supporting statistical outputs.

## To reproduce the complete ablation experiment independently

Work from a copy of the folder, run:

```text
DFFG_Main_Ablation_Study.m
```

with the reported configuration, and then use the newly generated raw-results MAT as the input to the Final4 statistical workflow.

## To rebuild the raw-results MAT from the archived workbook and log

Run:

```text
DFFG_AVOA_Ablation_Recover_RawResults_From_Excel_Log.m
```

using the supplied experiment workbook and log.

---

# File-Retention Rule

All files currently supplied in this ablation package should be preserved in the public reproducibility package unless a later dependency audit demonstrates that a file can be removed without affecting:

- rerunning the experiment;
- reproducing downstream statistics;
- reproducing manuscript-facing outputs;
- recovering the raw-results authority;
- or preserving the computational audit trail.

In particular, do not remove the experiment workbook, experiment log, raw-results MAT, Final4 Results MAT, recovery files, saved figures, or manuscript/statistical output documents merely because they were generated by earlier code. Their roles differ, and several are explicit inputs to later stages.
