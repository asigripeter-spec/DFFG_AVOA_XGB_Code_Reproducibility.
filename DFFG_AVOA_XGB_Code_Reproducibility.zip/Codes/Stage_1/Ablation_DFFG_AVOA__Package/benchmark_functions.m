function [lb, ub, dim, fobj] = benchmark_functions(F)
% This function provides the definitions for the 23 benchmark functions.
% FINAL CORRECTED version: The helper function u_func is fixed to prevent
% array dimension mismatch errors in F12 and F13.

switch F
    case 'F1' % Sphere
        fobj = @(x) sum(x.^2);
        lb = -100; ub = 100; dim = 30;
    case 'F2' % Schwefel 2.22
        fobj = @(x) sum(abs(x)) + prod(abs(x));
        lb = -10; ub = 10; dim = 30;
    case 'F3' % Schwefel 1.2
        fobj = @(x) sum(cumsum(x).^2);
        lb = -100; ub = 100; dim = 30;
    case 'F4' % Schwefel 2.21
        fobj = @(x) max(abs(x));
        lb = -100; ub = 100; dim = 30;
    case 'F5' % Rosenbrock
        fobj = @(x) sum(100*(x(2:end) - x(1:end-1).^2).^2 + (x(1:end-1)-1).^2);
        lb = -30; ub = 30; dim = 30;
    case 'F6' % Step
        fobj = @(x) sum(floor(x+0.5).^2);
        lb = -100; ub = 100; dim = 30;
    case 'F7' % Quartic with noise
        fobj = @(x) sum((1:length(x)).*(x.^4)) + rand;
        lb = -1.28; ub = 1.28; dim = 30;
    case 'F8' % Schwefel 2.26
        fobj = @(x) -sum(x.*sin(sqrt(abs(x))));
        lb = -500; ub = 500; dim = 30;
    case 'F9' % Rastrigin
        fobj = @(x) sum(x.^2 - 10*cos(2*pi*x) + 10);
        lb = -5.12; ub = 5.12; dim = 30;
    case 'F10' % Ackley
        fobj = @(x) -20*exp(-0.2*sqrt(sum(x.^2)/length(x))) - exp(sum(cos(2*pi*x))/length(x)) + 20 + exp(1);
        lb = -32; ub = 32; dim = 30;
    case 'F11' % Griewank
        fobj = @(x) sum(x.^2)/4000 - prod(cos(x./sqrt(1:length(x)))) + 1;
        lb = -600; ub = 600; dim = 30;
    case 'F12' % Penalized 1
        dim = 30; lb = -50; ub = 50;
        fobj = @(x) (pi/length(x)) * (10*sin(pi*(1+(x(1)+1)/4)).^2 + ...
            sum(((1+(x(1:end-1)+1)/4)-1).^2 .* (1+10*sin(pi*(1+(x(2:end)+1)/4)).^2)) + ...
            ((1+(x(end)+1)/4)-1)^2) + u_func(x, 10, 100, 4);
    case 'F13' % Penalized 2
        dim = 30; lb = -50; ub = 50;
        fobj = @(x) 0.1 * (sin(3*pi*x(1))^2 + ...
            sum((x(1:end-1)-1).^2 .* (1+sin(3*pi*x(2:end)).^2)) + ...
            (x(end)-1)^2 * (1+sin(2*pi*x(end))^2)) + u_func(x, 5, 100, 4);
    case 'F14' % Foxholes
        dim = 2; lb = -65.536; ub = 65.536;
        fobj = @(x) (1/500 + sum(1./( (1:25) + (x(1) - [-32, -16, 0, 16, 32, -32, -16, 0, 16, 32, -32, -16, 0, 16, 32, -32, -16, 0, 16, 32, -32, -16, 0, 16, 32]).^6 + ...
            (x(2) - [-32, -32, -32, -32, -32, -16, -16, -16, -16, -16, 0, 0, 0, 0, 0, 16, 16, 16, 16, 16, 32, 32, 32, 32, 32]).^6 ))).^-1;
    case 'F15' % Kowalik
        dim = 4; lb = -5; ub = 5;
        a = [0.1957, 0.1947, 0.1735, 0.16, 0.0844, 0.0627, 0.0456, 0.0342, 0.0323, 0.0235, 0.0246];
        b_inv = 1./[0.25, 0.5, 1, 2, 4, 6, 8, 10, 12, 14, 16];
        fobj = @(x) sum((a - (x(1)*(b_inv.^2 + b_inv*x(2)))./(b_inv.^2 + b_inv*x(3) + x(4))).^2);
    case 'F16' % Six-Hump Camel
        dim = 2; lb = -5; ub = 5;
        fobj = @(x) 4*x(1)^2 - 2.1*x(1)^4 + (1/3)*x(1)^6 + x(1)*x(2) - 4*x(2)^2 + 4*x(2)^4;
    case 'F17' % Branin RCOS
        dim = 2; lb = [-5, 0]; ub = [10, 15];
        fobj = @(x) (x(2) - (5.1/(4*pi^2))*x(1)^2 + (5/pi)*x(1) - 6)^2 + 10*(1-(1/(8*pi)))*cos(x(1)) + 10;
    case 'F18' % Goldstein-Price
        dim = 2; lb = -2; ub = 2;
        fobj = @(x) (1 + (x(1)+x(2)+1)^2 * (19-14*x(1)+3*x(1)^2-14*x(2)+6*x(1)*x(2)+3*x(2)^2)) * ...
                    (30 + (2*x(1)-3*x(2))^2 * (18-32*x(1)+12*x(1)^2+48*x(2)-36*x(1)*x(2)+27*x(2)^2));
    case 'F19' % Hartmann 3D
        dim = 3; lb = 0; ub = 1;
        alpha = [1.0, 1.2, 3.0, 3.2]';
        A = [3.0, 10, 30; 0.1, 10, 35; 3.0, 10, 30; 0.1, 10, 35];
        P = 10^-4 * [3689, 1170, 2673; 4699, 4387, 7470; 1091, 8732, 5547; 381, 5743, 8828];
        fobj = @(x) -sum(alpha .* exp(-sum(A .* (repmat(x,4,1) - P).^2, 2)));
    case 'F20' % Hartmann 6D
        dim = 6; lb = 0; ub = 1;
        alpha = [1.0, 1.2, 3.0, 3.2]';
        A = [10, 3, 17, 3.5, 1.7, 8; 0.05, 10, 17, 0.1, 8, 14; 3, 3.5, 1.7, 10, 17, 8; 17, 8, 0.05, 10, 0.1, 14];
        P = 10^-4 * [1312, 1696, 5569, 124, 8283, 5886; 2329, 4135, 8307, 3736, 1004, 9991; 2348, 1451, 3522, 2883, 3047, 6650; 4047, 8828, 8732, 5743, 1091, 381];
        fobj = @(x) -sum(alpha .* exp(-sum(A .* (repmat(x,4,1) - P).^2, 2)));
    case {'F21', 'F22', 'F23'} % Shekel functions
        dim = 4; lb = 0; ub = 10;
        C = [4, 1, 8, 6, 3, 2, 5, 8, 6, 7; 4, 1, 8, 6, 7, 9, 3, 1, 2, 3.6; 4, 1, 8, 6, 3, 2, 5, 8, 6, 7; 4, 1, 8, 6, 7, 9, 3, 1, 2, 3.6]';
        beta = 0.1 * [1, 2, 2, 4, 4, 6, 3, 7, 5, 5]';
        if strcmp(F, 'F21'), m = 5; elseif strcmp(F, 'F22'), m = 7; else, m = 10; end
        fobj = @(x) -sum( (sum((repmat(x,m,1) - C(1:m,:)).^2, 2) + beta(1:m)).^-1 );
    otherwise
        error('Function %s not defined', F);
    end
end

% --- CORRECTED HELPER FUNCTION ---
function val = u_func(x, a, k, m)
    % This function calculates the penalty for values of x outside [-a, a].
    % It is corrected to avoid matrix dimension errors.
    
    % Calculate penalty for values greater than 'a'
    upper_penalty = k * (x - a).^m .* (x > a);
    
    % Calculate penalty for values less than '-a'
    lower_penalty = k * (-x - a).^m .* (x < -a);
    
    % The total penalty is the sum of all individual penalties.
    val = sum(upper_penalty + lower_penalty);
end