function [Best_score, Best_pos, Convergence_curve] = AVOA(N, Max_iter, lb, ub, dim, fobj, params)
% AVOA: The Original African Vulture Optimization Algorithm
% Based on the paper "A Hierarchically Enhanced African Vulture Optimization Algorithm"
% and the original work by Abdollahzadeh et al. (2021).
% This function implements the logic from Section 2 of the provided paper.

% --- Extract Parameters ---
P1 = params.P1;
P2 = params.P2;
P3 = params.P3;
w = params.w;
beta_levy = params.beta_levy;
L1 = params.L1_fixed; % The paper uses L1, the main script provides L1_fixed
h = params.h_fixed_for_run; % h is randomized once per run in the main script

% --- Initialization (Algorithm 1, line 3) ---
Vulture_Positions = rand(N, dim) .* (ub - lb) + lb; % Eq (1)
Vulture_Fitness = zeros(N, 1);

% Calculate initial fitness
for i = 1:N
    Vulture_Fitness(i) = fobj(Vulture_Positions(i, :));
end

% Find initial best and second-best vultures
[sorted_fitness, sort_indices] = sort(Vulture_Fitness);
Best_vulture1_pos = Vulture_Positions(sort_indices(1), :);
Best_vulture1_fit = sorted_fitness(1);
Best_vulture2_pos = Vulture_Positions(sort_indices(2), :);
% Best_vulture2_fit = sorted_fitness(2); % Not explicitly used but good practice

% Initialize convergence curve
Convergence_curve = zeros(1, Max_iter);
Convergence_curve(1) = Best_vulture1_fit;

Best_pos = Best_vulture1_pos;
Best_score = Best_vulture1_fit;

% --- Main Loop (Algorithm 2, line 1) ---
t = 1;
while t < Max_iter
    % For each vulture (Algorithm 2, line 4)
    for i = 1:N
        % --- Phase 1: Determine Best Vulture for Group (Eq 2 & 3) ---
        % Calculate selection probabilities pi based on fitness
        F_vals = 1./(Vulture_Fitness + eps); % Using inverse for minimization
        pi_vals = F_vals / sum(F_vals);
        
        % Roulette wheel to select which of the two best vultures to follow
        if rand() < pi_vals(i) % Simplified roulette logic, more direct is just using L1
            R_i = Best_vulture1_pos;
        else
            R_i = Best_vulture2_pos;
        end
        % The paper's official logic uses parameters L1 and L2. The main
        % script defines L1_fixed = 0.8. We'll use that.
        if rand() < L1
            R_i = Best_vulture1_pos;
        else
            R_i = Best_vulture2_pos;
        end

        % --- Phase 2: Rate of Starvation (Eq 4 & 5) ---
        t_osc = h * (sin((pi /2) * (t / Max_iter))^w + cos((pi/2) * (t / Max_iter)) - 1); % Eq (4)
        z = unifrnd(-1, 1); % As per original AVOA paper, z is a random number in [-1, 1]
        F_hunger = (2 * rand() + 1) * z * (1 - (t / Max_iter)) + t_osc; % Eq (5)
        
        current_pos = Vulture_Positions(i, :);
        new_pos = current_pos;

        % --- Exploration vs. Exploitation ---
        if abs(F_hunger) >= 1 % Phase 3: Exploration (Algorithm 3, line 2)
            if rand() < P1 % Exploration Strategy 1 (Eq 7)
                D_i = abs((2 * rand()) * R_i - current_pos); % Eq (8) with X = 2*rand()
                new_pos = R_i - D_i * F_hunger;
            else % Exploration Strategy 2 (Eq 9)
                new_pos = R_i - F_hunger + rand(1, dim) .* ((ub - lb) * rand() + lb);
            end
            
        else % Phase 4: Exploitation (Algorithm 3, line 11)
            if abs(F_hunger) >= 0.5 % Competition Stage
                if rand() < P2 % Competition Strategy 1 (Eq 11)
                    D_i = abs((2 * rand()) * R_i - current_pos); % Eq (8)
                    d_t = R_i - current_pos; % Eq (12)
                    new_pos = D_i * (F_hunger + rand()) - d_t;
                else % Competition Strategy 2: Spiral Movement (Eq 14)
                    s1 = R_i .* ( (rand(1,dim).*current_pos) / (2*pi) ) .* cos(current_pos); % Eq (13)
                    s2 = R_i .* ( (rand(1,dim).*current_pos) / (2*pi) ) .* sin(current_pos); % Eq (13)
                    new_pos = R_i - (s1 + s2);
                end
            else % Aggregation Stage
                if rand() < P3 % Aggregation Strategy 1 (Eq 17)
                    A1 = Best_vulture1_pos - ( (Best_vulture1_pos .* current_pos) / (Best_vulture1_pos - current_pos.^2) ) * F_hunger; % Eq (16)
                    A2 = Best_vulture2_pos - ( (Best_vulture2_pos .* current_pos) / (Best_vulture2_pos - current_pos.^2) ) * F_hunger; % Eq (16)
                    new_pos = (A1 + A2) / 2;
                else % Aggregation Strategy 2: Levy Flight (Eq 18)
                    d_t = R_i - current_pos; % Eq (12)
                    new_pos = R_i - abs(d_t) .* F_hunger .* levy(dim, beta_levy);
                end
            end
        end
        
        % --- Boundary Checking and Greedy Selection (Algorithm 3, line 37-41) ---
        new_pos = max(new_pos, lb);
        new_pos = min(new_pos, ub);
        
        new_fit = fobj(new_pos);
        
        if new_fit < Vulture_Fitness(i)
            Vulture_Fitness(i) = new_fit;
            Vulture_Positions(i, :) = new_pos;
        end
    end % End of vulture loop
    
    % --- Update Global Best and Convergence Curve ---
    [current_best_fit, best_idx] = min(Vulture_Fitness);
    if current_best_fit < Best_score
        Best_score = current_best_fit;
        Best_pos = Vulture_Positions(best_idx, :);
    end
    
    % Re-identify the top two vultures for the next iteration
    [sorted_fitness, sort_indices] = sort(Vulture_Fitness);
    Best_vulture1_pos = Vulture_Positions(sort_indices(1), :);
    Best_vulture2_pos = Vulture_Positions(sort_indices(2), :);
    
    t = t + 1;
    Convergence_curve(t) = Best_score;
    
end % End of main while loop
end