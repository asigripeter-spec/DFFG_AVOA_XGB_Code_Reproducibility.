# Stage 2 — DFFG-AVOA-XGB Short-Term Load Forecasting

## Purpose

Stage 2 contains the Python/Jupyter computational workflow used to tune Extreme Gradient Boosting (XGB) with the selected metaheuristic optimizers, generate the archived forecasting results, perform the downstream reporting analysis, and reproduce the final manuscript figures and SHAP outputs.

The current Stage 2 package contains the following principal files:

```text
Stage_2/
│
├── README.md
│
├── XGBoost_STLF_Colab_Benchmark3.ipynb
├── report_and_analysis_v4_implementation_ready.ipynb
├── DFFG_AVOA_XGB_Integrated_SHAP_Output8_Fig32_35_Locked_Final_IJEPES.ipynb
├── CHECK POINTS.zip
├── DFFG_AVOA_XGB_Revised_Results.zip
└── DFFG_AVOA_XGB_Corrected_Composite_Output8_Fig32_35_Locked_Final_US_English.zip
```

All files currently supplied in this Stage 2 package are retained intentionally. Some are executable source notebooks, while others are reference computational artifacts or direct inputs to later notebooks.

---

# 1. External Dataset

The original Panama electricity-load dataset is not redistributed in this repository.

Download it from:

[Short-term electricity load forecasting (Panama case study) - Mendeley Data](https://data.mendeley.com/datasets/byx7sztj59/1)

DOI:

```text
10.17632/byx7sztj59.1
```

The Mendeley record provides:

- a continuous CSV dataset containing the merged hourly variables; and
- a CSV containing the weekly pre-dispatch load forecasts.

The Stage 2 workflow uses the continuous dataset as the principal modeling input and also reports comparisons with the Pre-Dispatch forecast.

---

# 2. Dataset Filename and Path Requirements

## Continuous dataset

The principal Benchmark3 and Reporting Analysis v4 notebooks are written to expect the continuous dataset under the local filename:

```text
continuous_dataset.csv
```

For example, the supplied code contains:

```python
DRIVE_BASE = "/content/drive/MyDrive/1jO3C82JWjzIH5MLFe2Jq80vr4Df8Is8G/"
DATA_PATH = os.path.join(DRIVE_BASE, "continuous_dataset.csv")
```

The path above is specific to the original author's Google Drive environment.

**Other users must not reproduce that Google Drive path literally.**

After downloading the Mendeley dataset, use either of the following approaches:

1. rename/copy the continuous-data CSV to:

```text
continuous_dataset.csv
```

and place it in the user's chosen working directory; or

2. modify `DRIVE_BASE`, `DATA_PATH`, or the equivalent input variable in the notebook so that it points to the actual filename and location in the user's own Google Drive or local environment.

The scientific content of the dataset should not be altered merely to satisfy the filename convention.

## Output 8 continuous-dataset filename handling

The final Output 8 notebook is more flexible than the earlier notebooks.

It can resolve the following names in its input directory:

```text
continuous_dataset.csv
continuous dataset.csv
continuous_dataset_public.csv
```

It also provides:

```python
CONTINUOUS_DATASET_FILE_OVERRIDE = None
```

A user may set this variable to the exact path of the valid continuous dataset if automatic detection is not suitable.

For maximum consistency across all Stage 2 notebooks, the recommended local filename remains:

```text
continuous_dataset.csv
```

---

# 3. Weekly Pre-Dispatch Data

The Mendeley dataset also provides a separate CSV containing the weekly pre-dispatch forecasts. Users reproducing the study should download this file together with the continuous dataset and preserve its original provenance.

The current packaged notebooks do not all consume the separate pre-dispatch CSV in the same manner:

- `XGBoost_STLF_Colab_Benchmark3.ipynb` uses `continuous_dataset.csv` as its direct modeling input.
- `report_and_analysis_v4_implementation_ready.ipynb` attempts to identify a pre-dispatch forecast column in the loaded continuous dataframe when such a column is present.
- `DFFG_AVOA_XGB_Integrated_SHAP_Output8_Fig32_35_Locked_Final_IJEPES.ipynb` uses the archived reporting tables for the XGB-based models and contains the 14 weekly Pre-Dispatch values used for Figure 3.3 as a documented source series from the seed-paper Table 5.

Therefore, the separate weekly pre-dispatch CSV should be downloaded and retained as part of the source-data record, but users should follow the input logic of the specific notebook being executed rather than assume that every notebook directly reads that CSV by filename.

If a user modifies the notebooks to read the separate pre-dispatch CSV directly, the corresponding file path and filename variables must be changed to match the downloaded file.

---

# 4. Stage 2 Workflow

The principal dependency chain is:

```text
Mendeley Panama dataset
        │
        │  continuous_dataset.csv
        ▼
XGBoost_STLF_Colab_Benchmark3.ipynb
        │
        ├── generates optimizer checkpoint files
        ├── generates convergence/result support files
        └── permits interrupted runs to resume
        │
        ▼
20 completed archived checkpoints
        │
        └── packaged as CHECK POINTS.zip
        │
        ▼
report_and_analysis_v4_implementation_ready.ipynb
        │
        ├── reads completed checkpoints
        ├── refits/evaluates the selected XGB models
        ├── generates reporting tables
        ├── generates reporting figures
        └── packages the revised reporting outputs
        │
        ▼
DFFG_AVOA_XGB_Revised_Results.zip
        │
        ├───────────────────────────────┐
        │                               │
        │                               │
CHECK POINTS.zip                        │
        │                               │
        └──────────────┬────────────────┘
                       │
                       │ + continuous_dataset.csv
                       ▼
DFFG_AVOA_XGB_Integrated_SHAP_Output8_Fig32_35_Locked_Final_IJEPES.ipynb
                       │
                       ├── Figure 3.2 from checkpoint histories
                       ├── Figure 3.3 from frozen reporting tables
                       ├── Figure 3.4 from best checkpoints + continuous dataset
                       ├── Figure 3.5 from gain importance + SHAP analysis
                       ├── Table 9 and validation/audit tables
                       └── publication-format exports
                       │
                       ▼
DFFG_AVOA_XGB_Corrected_Composite_Output8_Fig32_35_Locked_Final_US_English.zip
```

This dependency chain explains why the checkpoint archive and revised-results archive must remain in the public reproducibility package.

---

# 5. Notebook 1 — Benchmark and Optimization

Use:

```text
XGBoost_STLF_Colab_Benchmark3.ipynb
```

## Purpose

This notebook contains the Stage 2 optimization and forecasting benchmark pipeline.

Its supplied code includes:

- Google Drive mounting and path configuration;
- loading and preprocessing of `continuous_dataset.csv`;
- construction of the 14 chronological evaluation splits;
- a 9-dimensional XGB hyperparameter search space;
- XGB objective evaluation;
- checkpoint save/load utilities;
- implementations of the baseline optimizers;
- the DFFG-AVOA implementation;
- resumable optimizer execution;
- run-level result and convergence recording.

## Reported execution settings

The active supplied execution block uses:

```text
Population size = 40
Maximum iterations = 25
Independent runs = 5
Search dimension = 9
```

and the active target list is:

```python
TARGET_ALGORITHMS = ["AVOA", "DFFG-AVOA", "AOA", "FPA"]
```

The notebook contains additional optimizer implementations and registry entries, but the archived downstream reference package is based on the four optimizers above.

## Chronological evaluation design

The supplied notebook constructs 14 evaluation weeks.

For each evaluation week:

- forecast horizon = `168` hours;
- information gap = `72` hours;
- training window = `149 × 168` hours.

The exact target dates are coded in the notebook.

---

# 6. Google Drive Configuration for Benchmark3

The supplied notebook contains the original author's path:

```python
DRIVE_BASE = "/content/drive/MyDrive/1jO3C82JWjzIH5MLFe2Jq80vr4Df8Is8G/"
```

A new user must change this before execution.

For example, the user may define:

```python
DRIVE_BASE = "/content/drive/MyDrive/DFFG_AVOA_XGB/"
DATA_PATH = os.path.join(DRIVE_BASE, "continuous_dataset.csv")
```

or use another valid directory.

The chosen folder must be writable because the notebook saves checkpoints and supporting outputs there.

Do not modify unrelated scientific settings merely to adapt the storage path.

---

# 7. Benchmark3 Checkpoint Files

During optimization, each run saves its state using the naming convention:

```text
<Algorithm>_run_<RunNumber>_checkpoint.pkl
```

For the archived four-optimizer study, the expected checkpoint set is:

```text
DFFG-AVOA_run_1_checkpoint.pkl
DFFG-AVOA_run_2_checkpoint.pkl
DFFG-AVOA_run_3_checkpoint.pkl
DFFG-AVOA_run_4_checkpoint.pkl
DFFG-AVOA_run_5_checkpoint.pkl

AVOA_run_1_checkpoint.pkl
AVOA_run_2_checkpoint.pkl
AVOA_run_3_checkpoint.pkl
AVOA_run_4_checkpoint.pkl
AVOA_run_5_checkpoint.pkl

AOA_run_1_checkpoint.pkl
AOA_run_2_checkpoint.pkl
AOA_run_3_checkpoint.pkl
AOA_run_4_checkpoint.pkl
AOA_run_5_checkpoint.pkl

FPA_run_1_checkpoint.pkl
FPA_run_2_checkpoint.pkl
FPA_run_3_checkpoint.pkl
FPA_run_4_checkpoint.pkl
FPA_run_5_checkpoint.pkl
```

The current public package groups these 20 files in:

```text
CHECK POINTS.zip
```

These files are **not disposable temporary files**.

They preserve the completed optimizer states and convergence histories used by the downstream reporting and final-figure notebooks.

---

# 8. Why the Checkpoints Must Be Retained

The checkpoints serve two different purposes.

## A. Verification of the archived study

The supplied checkpoints allow a user to reproduce the downstream reporting and final figure/SHAP workflow corresponding to the completed study without repeating the complete optimization stage.

## B. Resumption and fresh rerun

When `XGBoost_STLF_Colab_Benchmark3.ipynb` is run independently, it creates new checkpoint files in the user's own working directory.

These newly generated checkpoints can then replace the archived checkpoints as inputs to the downstream reporting workflow.

Thus:

```text
supplied checkpoints
```

are the reference artifacts for the reported study, while:

```text
newly generated checkpoints
```

are the artifacts created by an independent rerun.

Both use the same checkpoint naming convention.

---

# 9. Other Benchmark3 Support Files

The Benchmark3 notebook also contains logic for support files including:

```text
fair_benchmark_results.csv
convergence_history.json
dffg_avao_behavior_log_patch1.txt
```

These files record complementary run-level, convergence, and DFFG-AVOA behaviour information.

Where such files are generated during a fresh rerun, keep them with the new computational run because later reporting cells may use them when available.

The current Stage 2 package preserves the reference files required by its accepted downstream workflow through the archived checkpoints and revised-results package.

---

# 10. Notebook 2 — Reporting and Analysis

Use:

```text
report_and_analysis_v4_implementation_ready.ipynb
```

## Purpose

This notebook converts the completed optimization artifacts into the reporting tables, figures, and revised-results package used by the final Output 8 notebook.

The supplied reporting scope is:

```text
AOA
FPA
AVOA
DFFG-AVOA
```

with comparison against:

```text
XGB-Baseline
Pre-Dispatch
```

where the required comparison information is available.

## Required environment-specific path change

This notebook also contains the original author's hard-coded Google Drive path:

```python
DRIVE_BASE = "/content/drive/MyDrive/1jO3C82JWjzIH5MLFe2Jq80vr4Df8Is8G/"
```

Users must modify this path to the folder containing their own:

- checkpoint files;
- `continuous_dataset.csv`;
- and any related Benchmark3 outputs used by the reporting notebook.

The notebook constructs the checkpoint paths using:

```text
<Algorithm>_run_<RunNumber>_checkpoint.pkl
```

Therefore, if `CHECK POINTS.zip` is being used, extract its 20 `.pkl` files into the folder assigned to `DRIVE_BASE`, unless the notebook is deliberately modified to read them from another location.

---

# 11. Reporting Analysis v4 Input Logic

The notebook defines checkpoint paths for the registered algorithms and then selects completed runs for the reporting algorithms.

For the current reference workflow, the required completed checkpoint histories contain:

```text
25 convergence values
```

corresponding to the 25 optimization iterations.

The notebook uses the checkpoint states to identify the best completed settings and refit XGB models over the same chronological evaluation splits.

It also loads:

```text
continuous_dataset.csv
```

through `DATA_PATH`.

---

# 12. Reporting Analysis v4 Output Folder

The supplied notebook uses:

```python
MANUAL_EXPORT_FOLDER_NAME = "DFFG_AVOA_XGB_Revised_Results"
```

and creates an export structure containing:

```text
DFFG_AVOA_XGB_Revised_Results/
│
├── tables/
├── figures/
├── logs/
└── notes/
```

The final notebook cell then creates:

```text
DFFG_AVOA_XGB_Revised_Results.zip
```

The current Stage 2 package includes this archived ZIP as a direct downstream input.

---

# 13. Archived Revised-Results Package

The current:

```text
DFFG_AVOA_XGB_Revised_Results.zip
```

contains the accepted reporting tables and figures.

Its `tables/` folder contains:

```text
Table_1_DFFG_AVOA_optimizer_behavior_summary.csv
Table_2_hyperparameter_search_space_and_selected_values.csv
Table_3a_primary_forecasting_accuracy_comparison.csv
Table_3b_operational_error_comparison.csv
Table_3_overall_comparison_of_optimizers.csv
Table_5_run_level_optimization_comparison.csv
Table_6_errors_distribution_by_model_metric.csv
Table_7_weekly_evaluation_metrics_by_model.csv
Table_8_average_feature_importance_by_model.csv
```

Its `figures/` folder contains the archived reporting figures generated by Reporting Analysis v4, including:

```text
Figure_1a_dffg_behavior_run_1.png
...
Figure_1e_dffg_behavior_run_5.png

Figure_2a_convergence_run_1.png
...
Figure_2e_convergence_run_5.png

Figure_3a_weekly_mape_boxplot.png
Figure_3b_weekly_rmse_boxplot.png

Figure_4a_percentage_error_comparison.png
Figure_4b_rmse_comparison.png

Figure_5a_best_case_weekly_forecast.png
Figure_5b_representative_weekly_forecast.png
```

These files should be retained because the revised-results archive is an explicit input to the final Output 8 notebook.

---

# 14. Notebook 3 — Final Output 8 / SHAP / Publication Figures

Use:

```text
DFFG_AVOA_XGB_Integrated_SHAP_Output8_Fig32_35_Locked_Final_IJEPES.ipynb
```

## Required primary input archives

The notebook expects the exact filenames:

```text
CHECK POINTS.zip
DFFG_AVOA_XGB_Revised_Results.zip
```

The configured variables are:

```python
CHECKPOINT_ZIP_FILENAME = "CHECK POINTS.zip"
RESULTS_ZIP_FILENAME = "DFFG_AVOA_XGB_Revised_Results.zip"
```

When run in Google Colab, the notebook can prompt the user to upload either archive if it is missing.

If the archives are renamed, the corresponding filename variables must also be updated.

For the simplest reproduction, keep the supplied archive names unchanged.

---

# 15. Output 8 Input Directory

By default, the final notebook uses:

```python
INPUT_DIR = Path(os.environ.get("COMPOSITE_INPUT_DIR", "/content"))
```

Therefore, in a normal Google Colab run, place/upload:

```text
CHECK POINTS.zip
DFFG_AVOA_XGB_Revised_Results.zip
continuous_dataset.csv
```

into:

```text
/content/
```

unless the environment variables or notebook settings are deliberately changed.

The notebook uses separate work and output directories and protects the input archives from being cleared by the output-reset logic.

---

# 16. Reporting Tables Required by Output 8

After extracting:

```text
DFFG_AVOA_XGB_Revised_Results.zip
```

the final notebook requires the following reporting tables:

```text
Table_2_hyperparameter_search_space_and_selected_values.csv
Table_3a_primary_forecasting_accuracy_comparison.csv
Table_3b_operational_error_comparison.csv
Table_5_run_level_optimization_comparison.csv
Table_6_errors_distribution_by_model_metric.csv
Table_7_weekly_evaluation_metrics_by_model.csv
Table_8_average_feature_importance_by_model.csv
```

The notebook validates that these files exist before continuing.

Therefore, the revised-results archive must not be replaced by a partial subset unless the downstream notebook is also intentionally rewritten.

---

# 17. Figure 3.2 Dependency

Figure 3.2 is reconstructed from the 20 checkpoint histories.

The final notebook expects:

```text
20 checkpoint files
```

and validates that each archived history contains:

```text
25 convergence values
```

It also validates the checkpoint initial and final values against the corresponding rows in:

```text
Table_5_run_level_optimization_comparison.csv
```

The figure is therefore tied jointly to:

```text
CHECK POINTS.zip
```

and:

```text
DFFG_AVOA_XGB_Revised_Results.zip
```

---

# 18. Figure 3.3 Dependency

Figure 3.3 is generated from the frozen reporting tables for the XGB-based models.

The Pre-Dispatch weekly comparison series used by the notebook is explicitly defined from the published 14-week values associated with the seed study's Table 5.

The notebook writes those values to:

```text
Source_Pre_Dispatch_Weekly_Metrics_Seed_Paper_Table_5.csv
```

as part of the final Output 8 audit trail.

The separate Mendeley pre-dispatch CSV remains part of the source-data record, but this final plotting cell does not depend on a local filename for that CSV.

---

# 19. Figure 3.4 Dependency

Figure 3.4 is data-driven.

It requires:

```text
continuous_dataset.csv
CHECK POINTS.zip
```

and reconstructs the XGB forecast curves from the best completed checkpoints.

The notebook reproduces the same 14 chronological evaluation weeks and then uses the locked manuscript weeks for the displayed best and representative panels.

Therefore, a user cannot reproduce Figure 3.4 solely from the revised-results ZIP; the continuous dataset and checkpoint archive are also required.

---

# 20. Figure 3.5 and SHAP Dependency

Figure 3.5 and Table 9 require:

- the continuous dataset;
- the best completed DFFG-AVOA checkpoint;
- the frozen Table 8 gain-importance values;
- the same 14 chronological evaluation splits.

The notebook performs a deterministic post-hoc explanatory XGB refit using:

```text
SHAP_REFIT_SEED = 123
SHAP_REFIT_NTHREAD = 2
```

and creates SHAP contributions across:

```text
14 × 168 = 2352
```

test observations.

The SHAP refit is used for interpretation and does not replace the frozen forecasting-performance results contained in the revised-results package.

---

# 21. Final Output 8 Archive

The final notebook produces:

```text
DFFG_AVOA_XGB_Corrected_Composite_Output8_Fig32_35_Locked_Final_US_English.zip
```

The current Stage 2 package includes the accepted reference version of this archive.

It contains:

```text
figures/
tables/
README_Output8_Presentation_and_Export.txt
```

The tables include validation, manifest, plot-data, SHAP, figure-source, and export-audit files.

The figures include publication-oriented versions of Figures 3.2–3.5 in the relevant:

```text
PNG
TIFF
PDF
EPS
SVG
```

formats according to the output type.

This archive is the accepted downstream output of the Stage 2 computational chain and should be retained.

---

# 22. Two Supported Reproduction Modes

## Mode A — Reproduce/verify the archived downstream manuscript outputs

Use the supplied reference artifacts:

```text
CHECK POINTS.zip
DFFG_AVOA_XGB_Revised_Results.zip
continuous_dataset.csv
```

with:

```text
DFFG_AVOA_XGB_Integrated_SHAP_Output8_Fig32_35_Locked_Final_IJEPES.ipynb
```

This permits the user to reconstruct the final downstream figures, SHAP tables, manifests, and validation outputs using the archived experimental checkpoint states and revised reporting results.

This mode avoids repeating the expensive optimizer training stage.

## Mode B — Reproduce the entire Stage 2 experiment from scratch

1. Download the original Panama dataset from Mendeley Data.
2. Place/rename the continuous dataset as `continuous_dataset.csv`, or change the notebook's input path.
3. Modify the original Google Drive path in `XGBoost_STLF_Colab_Benchmark3.ipynb` to the user's own environment.
4. Run the Benchmark3 notebook to generate a new set of optimizer checkpoints and supporting results.
5. Use those newly generated checkpoints with `report_and_analysis_v4_implementation_ready.ipynb`.
6. Modify the Reporting Analysis v4 paths to the user's own storage directory.
7. Run Reporting Analysis v4 to generate a new:

```text
DFFG_AVOA_XGB_Revised_Results.zip
```

8. Supply the newly generated checkpoint ZIP, newly generated revised-results ZIP, and the continuous dataset to the final Output 8 notebook.
9. Run Output 8 to regenerate the downstream figures, SHAP analysis, tables, manifests, and final archive.

---

# 23. Fresh-Rerun Packaging

After an independent fresh run, users should keep their newly generated artifacts separate from the supplied reference artifacts.

For example:

```text
Fresh_Run/
│
├── continuous_dataset.csv
├── DFFG-AVOA_run_1_checkpoint.pkl
├── ...
├── FPA_run_5_checkpoint.pkl
├── fair_benchmark_results.csv
├── convergence_history.json
├── dffg_avao_behavior_log_patch1.txt
└── DFFG_AVOA_XGB_Revised_Results/
```

The newly generated 20 checkpoints may then be zipped as:

```text
CHECK POINTS.zip
```

if the final Output 8 notebook is to be used without modifying its expected filename.

Alternatively, the Output 8 filename setting may be changed deliberately.

---

# 24. Stochastic Reproduction

The optimization stage is stochastic.

The Benchmark3 notebook contains stochastic optimizer operations, and the archived scientific result should therefore not be interpreted as requiring that an independent rerun produce every numerical value bit-for-bit identically under all Python, package, GPU, and hardware environments.

A fresh rerun should reproduce:

- the same data-processing procedure;
- the same chronological split design;
- the same XGB search-space logic;
- the same optimizer logic;
- the same population size;
- the same maximum iterations;
- the same number of runs;
- and the same downstream analysis procedure.

The supplied archived checkpoints and revised-results package preserve the computational artifacts used for the reported study.

---

# 25. Python/Colab Software Requirements

The Stage 2 notebooks use the following principal Python packages:

```text
numpy
pandas
xgboost
scikit-learn
scipy
matplotlib
seaborn
cairosvg
```

The notebooks also use standard Python modules such as:

```text
os
json
pickle
pathlib
shutil
zipfile
hashlib
gc
re
```

Google Colab-specific cells use:

```text
google.colab.drive
google.colab.files
```

The principal modeling notebooks were developed for execution in Google Colab.

The Benchmark3 implementation uses XGBoost's histogram tree method and GPU-oriented execution where configured.

A user running locally may need to adjust device settings and environment-specific path code while preserving the scientific experiment configuration.

---

# 26. Safe Path Adaptation Rule

When adapting the notebooks to a new computer or Google Drive:

**Change storage paths and filenames only where necessary.**

Do not change:

- optimization settings;
- evaluation weeks;
- train/test chronology;
- 72-hour information gap;
- 149-week training window;
- XGB hyperparameter decoding;
- metric definitions;
- optimizer equations;
- checkpoint completeness criteria;
- or downstream model ordering

unless the purpose is to conduct a deliberately different experiment.

Path adaptation should not become an unintended methodological modification.

---

# 27. Recommended User Procedure

For a new user wishing to inspect the archived study first:

1. Read this README completely.
2. Download both Panama source CSVs from Mendeley Data.
3. Prepare the continuous dataset under the name `continuous_dataset.csv`.
4. Keep the separate weekly pre-dispatch CSV as source/reference data.
5. Extract `CHECK POINTS.zip` only when a notebook requires the individual `.pkl` files.
6. Keep the original ZIP unchanged as the archived checkpoint authority.
7. Inspect `DFFG_AVOA_XGB_Revised_Results.zip`.
8. Run the final Output 8 notebook using the supplied checkpoint and revised-results archives if downstream verification is the immediate goal.
9. Only then begin a fresh Benchmark3 rerun if full independent computational reproduction is required.

---

# 28. File-Retention Rule

All files currently supplied in Stage 2 should be retained in the public reproducibility package.

In particular, do not remove:

```text
CHECK POINTS.zip
DFFG_AVOA_XGB_Revised_Results.zip
DFFG_AVOA_XGB_Corrected_Composite_Output8_Fig32_35_Locked_Final_US_English.zip
```

The first two are direct inputs to the final downstream workflow, and the third preserves the accepted final publication-output result.

Likewise, retain all three notebooks because they represent different computational stages:

```text
Benchmark3
        ↓
Reporting Analysis v4
        ↓
Final Output 8
```

The Stage 2 package should be treated as a complete computational provenance chain rather than as a folder containing only source code.

---

# 29. Dataset Citation

The source dataset should be cited from its original repository:

Ernesto Aguilar Madrid, **Short-term electricity load forecasting (Panama case study)**, Mendeley Data, Version 1, 2021.

DOI:

```text
https://doi.org/10.17632/byx7sztj59.1
```

Dataset page:

```text
https://data.mendeley.com/datasets/byx7sztj59/1
```

Users should obtain the original data from that repository rather than treating the Stage 2 code package as the authoritative source of the Panama dataset.
