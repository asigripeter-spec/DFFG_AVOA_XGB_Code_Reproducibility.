# DFFG-AVOA-XGB Reproducibility Package

This repository contains the computational materials used in the study:

**Short-Term Electricity Load Forecasting Using Extreme Gradient Boosting Tuned by the Dynamic Flock Fragmentation and Gaussian-Enhanced African Vultures Optimization Algorithm**

## Authors

Francis Aduansah Mensah  
Elvis Twumasi  
Peter Asigri  
Abdul-Majid Issah Malori  
Christopher D. Naya

## Overview

The package is organized into two principal stages.

- **Stage 1** contains the MATLAB materials for the DFFG-AVOA ablation study and the comparative mathematical-benchmark and engineering-design studies.
- **Stage 2** contains the Jupyter/Python materials for XGBoost-based short-term electricity-load forecasting, the saved optimization checkpoints, the revised-result package, and the downstream analysis and publication-output workflow.

More detailed instructions are provided in README files inside the relevant stage and subpackage folders. Users should consult those local README files before running or modifying the supplied code.

## Package Structure

```text
DFFG-AVOA-XGB-Reproducibility/
│
├── README.md
│
├── Stage_1/
│   ├── README.md
│   ├── Ablation_DFFG_AVOA__Package/
│   │   ├── README.md
│   │   └── [ablation code, results, statistics, figures, and support files]
│   └── Comparators/
│       ├── README.md
│       └── [comparative benchmark and engineering-design materials]
│
└── Stage_2/
    ├── README.md
    └── [forecasting notebooks, checkpoints, revised results, and final-output materials]
```

## Important Reproducibility Note

The supplied result files, checkpoints, revised-result packages, figures, logs, statistical outputs, and related computational artifacts form part of the documented workflow. Some of these files are used as inputs by later scripts or notebooks. They should therefore not be removed merely because they appear to be intermediate or previously generated outputs.

The package supports both:

1. rerunning the relevant experiments from source code; and
2. using the supplied computational artifacts to reproduce or verify downstream analyses, statistics, tables, and figures associated with the study.

Because some optimization procedures are stochastic and execution environments may differ, a complete rerun may not be bit-for-bit identical to the archived reference artifacts. The stage-specific README files describe the appropriate workflow and dependencies.

## Panama Electricity-Load Dataset

The original Panama electricity-load dataset is not redistributed in this repository. It is publicly available from Mendeley Data:

[Short-term electricity load forecasting (Panama case study) - Mendeley Data](https://data.mendeley.com/datasets/byx7sztj59/1)

DOI: https://doi.org/10.17632/byx7sztj59.1

Stage 2 uses the continuous electricity-load dataset and the weekly pre-dispatch forecast data from this source. The Stage 2 README specifies the expected filenames, input locations, and the path changes required for a user's own environment.

## File Paths and Execution Environments

Some supplied notebooks were developed using file paths specific to the original Google Drive/Google Colab environment. Other users should not reproduce those paths literally. Before execution, users should modify the relevant base-directory, dataset-path, or input-file variables to match their own Google Drive or local environment.

Where a script or notebook expects a particular filename, users should either:

- retain or rename the required input file to the expected filename; or
- modify the corresponding path or filename variable in the code.

Exact instructions are provided in the relevant stage-specific README.

## Documentation

Read the documentation in the following order:

- `Stage_1/README.md` for the overall Stage 1 workflow.
- `Stage_1/Ablation_DFFG_AVOA__Package/README.md` for the ablation study.
- `Stage_1/Comparators/README.md` for the comparative benchmark and engineering-design studies.
- `Stage_2/README.md` for the forecasting, checkpoint, revised-result, and final-output workflow.

## Citation

The bibliographic citation and DOI of the associated journal article will be added after publication.

## Contact

**Corresponding author:** Francis Aduansah Mensah  
Department of Electrical and Electronic Engineering  
Kwame Nkrumah University of Science and Technology  
Kumasi, Ghana  

Email: maduansah@gmail.com

## License

A software license will be specified before the repository is made publicly available.
